import {useContext} from 'react';
import _ from 'lodash';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import Calculator from '/components/misc/Calculator/Calculator';
import ClassicButton from '../../misc/ClassicButton/ClassicButton';

const BecomeTeacher_Head = props => {
	const context = useContext(WebsiteContext);
	let h1 = _.get(context, 'contents.h1.HTMLContent', <span>Donner des cours particuliers en ligne : le meilleur job !</span>);
	let h2 = _.get(context, 'contents[h2_#1].HTMLContent', <span>Voici ce que tu pourrais gagner en étant professeur particulier chez Les Sherpas</span>);
	// let h1 = subject ? 
	// <span>Donner des <span className='cgreen'>cours particuliers en {subject}.</span></span> :
	// <span>Donner des <span className='cgreen'>cours particuliers en ligne</span> : le meilleur job !</span>
	return (
		<div className="bct-head relw90 flex jcse aic padt20 padb50 mob__padb0 bsbb mob__padh20">
			<div className="bct-headImage mob__hide">
				<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/Macbook-Angie.png" className='relh100'/>
			</div>
			<div className="bct-form flex fdc jcse rel marl50 mob__marl0">
				<h1 className='camphor bold fs30 lh39 cblue marb40'>{h1}</h1>
				<h2 className='roboto light fs16 cgrey relw70 mob__relw100'>{h2}</h2>
				<div className="bct-calculator mart30">
					<Calculator/>
				</div>
				<div className="bct-button1 mart35">
					<ClassicButton linkTo='/teacher_inscription' className='padh20 padv10' defaultCss={false}>
						Je deviens Sherpa &nbsp;<FontAwesomeIcon icon={faArrowRight} size='xs'/>
					</ClassicButton>
				</div>
			</div>
		</div>
	)
};
export default BecomeTeacher_Head;