import WebsiteContext from '/components/contexts/WebsiteContext.js';
import BecomeTeacher_Head from './BecomeTeacher_Head.js';
import BecomeTeacher_IconCards from './BecomeTeacher_IconCards.js';
import BecomeTeacher_Community from './BecomeTeacher_Community.js';
import StepsOnlineCourses from '/components/misc/StepsOnlineCourses/StepsOnlineCourses.js';
import WhiteButton from '/components/misc/WhiteButton/WhiteButton.js';
import TeachersCarousel from '/components/misc/TeachersCarousel/TeachersCarousel.js';
import SEOBullshit from '/components/misc/SEOBullshit/SEOBullshit.js';
import Questions from '/components/misc/Questions/Questions.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import _ from 'lodash';
import './BecomeTeacher.scss';
import ClassicButton from '../../misc/ClassicButton/ClassicButton.js';
import {buildBullshit} from '/static/tools/misc.js';

class BecomeTeacher extends React.Component {
	constructor(props) {
		super(props);
	}

	static contextType = WebsiteContext;

	render() {
		let txtAccroche = _.get(this.context, 'contents[txt_accroche].HTMLContent');
		return (
			<div className="BecomeTeacher large_vertical_part">
				<BecomeTeacher_Head/>
				<div className='relw100 bgbeige'>
					<BecomeTeacher_IconCards
						h2={_.get(this.context, 'contents[h2_#2].HTMLContent')}
					/>
					<div className="bct-review relw100 flex fdc jcc padh25vw padv120 bgpastel_blue bsbb marb20 mob__padh50 mob__padv20 mob__marb40">
						<p className='camphor bold fs30 lh40 marb30 mob__fs20 mob__lh30 txtac'>
							Avec Les Sherpas, je donne cours où et quand je le souhaite, ce qui me permet de structurer très facilement mes journées.
						</p>
						<p className='camphor fs30 cblue txtac'>Julie L. - Étudiante à HEC</p>
					</div>
					<BecomeTeacher_Community
						h2={_.get(this.context, 'contents[h2_#3].HTMLContent')}
					/>
					<div className="bct-steps relw100 mart100 mob__mart20 flex fdc aic">
						<div className="flex jcse fdc aic mob__marb100">
							<h2 className='big_h2 marb15 mob__padh10'>
								{_.get(this.context, 'contents[h2_#4].HTMLContent', <span>Comment <span className='cgreen'>devenir prof particulier</span> chez les Sherpas ?</span>)}
							</h2>
							<p className='rl20 cgrey'>C'est super simple !</p>
						</div>
						<div className='relw74 mob__relw100'>
							<StepsOnlineCourses
								step1={{
									h2 : "Inscris-toi",
									p : "Choisis les matières qur tu souhaites enseigner. Ajoute tes justificatifs et passe un rapide entretien vidéo. En 15 min c’est fait !"
								}}
								step2={{
									h2 : "Publie ton annonce",
									p : "Une fois accepté(e), fixe tes prix, publie ton annonce, et diffuse la ! Des élèves ne vont pas tarder à vouloir te rencontrer."
								}}
								step3={{
									h2 : "Donne cours à ton premier élève",
									p: "Tu auras un RDV Pédagogique gratuit de 20min pour le convaincre. Ensuite, tu seras lancé(e) !"
								}}
							/>
						</div>
					</div>
					<div className="bct-whiteButton relw100 flex jcc aic marb80">
						<ClassicButton linkTo='/teacher_inscription' className='padv15 padh30' type='blank_green' defaultCss={false}>
							Devenir Sherpa &nbsp;<FontAwesomeIcon icon={faArrowRight} size='xs'/>
						</ClassicButton>
					</div>
					<div className="bct-carouselTitle flex relw100 jcc aic fdc mob__txtac">
						<h2 className='big_h2'>
							{
								_.get(
									this.context, 'contents[h2_#5].HTMLContent',
									<span>Nos professeurs adorent <span className='cgreen'>enseigner chez nous !</span></span>
								)
							}
						</h2>
						<p className='big_text light cgrey relw45 txtac mob__relw100'>Les cours particuliers en ligne sont pratiques, mieux payés que des cours à domicile classiques, et quelle fierté de voir tes élèves progresser !</p>
					</div>
					<div className="bct-carousel marv90 mob__mart40">
						<TeachersCarousel
							cards={[
								{
									teacher : {
										fname : 'Mathieu',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Mathieu+HEC.png',
										title : "HEC Paris"
									},
									student : {
										fname : "Mathieu",
										review : "C'est d'abord la passion de transmettre qui m'a fait devenir Sherpa, mais aussi la vision de l'éducation que je partage totalement : offrir un enseignement de qualité au plus grand nombre grâce à la tech, c'est formidable !",
										stars : 5
									}
								},
								{
									teacher : {
										fname : 'Antoine',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Antoine+Mines.jpg',
										title : "Mines de Paris"
									},
									student : {
										fname : "Antoine",
										review : "Devenir Sherpa m'a permis de continuer à aider des élèves comme à Paris, aussi bien pendant ma césure en Thaïlande qu'en Afrique du Sud. Un super service !",
										stars : 5
									}
								},
								{
									teacher : {
										fname : 'Gaëlle',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Gae%CC%88lle.png',
										title : "ESCP Europe"
									},
									student : {
										fname : "Gaëlle",
										review : "Professeur depuis deux ans chez les Sherpas, je recommande fortement. Les Sherpas, c'est une équipe dynamique, innovante, cherchant sans cesse à enrichir les services qu'elle propose. (...)",
										stars : 4.5
									}
								},
								{
									teacher : {
										fname : 'Gijs',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Gijs+Centrale+Supe%CC%81lec.png',
										title : "Centrale Paris"
									},
									student : {
										fname : "Gijs",
										review : "Le système mis en place est génial pour donner des cours. Je peux laisser travailler l'élève en suivant son raisonnement et le reprendre à tout moment pour corriger une faute.",
										stars : 5
									}
								},
								{
									teacher : {
										fname : 'Emma',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Emma+Sciences+Po+et+HEC+Paris.jpg',
										title : "Sciences-Po Paris"
									},
									student : {
										fname : "Emma",
										review : "En tant que prof, être Sherpa a deux atouts considérables : la flexibilité des horaires et des tarifs, combiné au fait de ne pas avoir à se déplacer pour donner cours.",
										stars : 5
									}
								},
								{
									teacher : {
										fname : 'Gabriel',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Gabriel+ENS+Ulm.png',
										title : "ENS Ulm"
									},
									student : {
										fname : "Gabriel",
										review : "La flexibilité dans l'organisation des cours et les outils collaboratifs mis à disposition assurent que chacun trouve son rythme.",
										stars : 4.5
									}
								},
								{
									teacher : {
										fname : 'Corentin',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Charles+HEC.jpg',
										title : "Université Paris Dauphine "
									},
									student : {
										fname : "Corentin",
										review : "Les Sherpas a été la découverte de mon année : j'ai décroché un job très flexible qui marche très bien avec mes contraintes de cours !",
										stars : 5
									}
								},
								{
									teacher : {
										fname : 'Lorinne',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Alexandra.png',
										title : "Assas"
									},
									student : {
										fname : "Lorinne",
										review : "Les cours particuliers en ligne sont ultra pratiques, et la récompense de voir son étudiant progresser procure un sentiment inégalable ! ",
										stars : 5
									}
								},
								{
									teacher : {
										fname : 'Juliette',
										picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Alicia.png',
										title : "La Sorbonne"
									},
									student : {
										fname : "Juliette",
										review : "Les cours sont flexibles, bien payés et me permettent d'ajouter une ligne utile sur mon CV. Indispensable pour ceux qui veulent arrondir leurs fin de mois avec un travail qui fait sens !",
										stars : 5
									}
								}
							]}
						/>
					</div>
					<div className="bct-questions relw100 flex fdc jcc aic bsbb padh250 marv100 mob__padh20 mob__marv30">
						<h2 className='classic_h2 marb80 mob__marb30'>Les questions <span className='cgreen'>fréquentes</span></h2>
						<Questions
							questions={[
								{h3 : "Quelles conditions pour devenir Sherpa ?",
								p:<span>Pour devenir professeur sur Les Sherpas,  tu dois avoir au moins 16 ans, être étudiant, professeur de l’éducation nationale ou professionnel et pouvoir justifier de ton expérience dans les matières que tu souhaites enseigner !<br></br><br></br>Pour candidater, tu devras nous fournir un justificatif pertinent pour chaque matière : relevé de notes, diplôme, certificat de scolarité et tout ce qui pourra nous aider dans notre décision !</span>},
								{
									h3 : "Dois-je trouver mes propres élèves ?",
									p:<span>
										<br></br>
										Ce n’est pas obligatoire, mais tu y es incité(e) ! Nous pourrons te proposer des élèves via notre Marketplace : tu paieras 15% de frais de service sur tes cours au titre de la mise en relation. Si tu veux enseigner plus vite et avec seulement 5% de frais de service, tu peux trouver tes propres élèves ! 
										<br></br><br></br>
										Pas d’inquiétude, nous avons prévu de nombreux conseils pour t’aider à développer ta clientèle sur la plateforme.
									</span>
								},
								{
									h3 : "Comment fonctionnent les cours ?",
									p:<span>
										<br></br>
										Les cours ont lieu en visioconférence en direct dans notre salle de classe en ligne. 
										<br></br><br></br>
										Tu y trouveras tout le nécessaire pour enseigner : tableau blanc partagé pour les matières scientifiques et traitement de texte partagé pour les matière littéraires. La plateforme permet l’échange de documents. 
										<br></br><br></br>
										À la fin de ton cours, la plateforme facture l’élève au prorata du temps que tu as passé avec lui. Tu es directement payé par virement bancaire.
									</span>
								},
								{h3 : "Dois-je fournir mon propre contenu pour les cours ?",
								p:<span>
									Si nous te conseillons de fournir ton propre  contenu, car c’est un super plus à proposer à tes élèves, ce n’est pas indispensable pour enseigner sur Les Sherpas.
									<br></br><br></br>
									De nombreuses ressources gratuites sont disponibles en ligne, et tes étudiants viendront souvent avec leurs propres exercices.
								</span>
								},
								{h3 : "Quelles matières puis-je enseigner ?",
								p:<span>
									<br></br>
									Nous proposons toutes les matières académiques disponibles au Collège, Lycée et dans le Supérieur ! 
									<br></br><br></br>
									Dans ta candidature, tu vas choisir les matières et les niveaux auxquels tu souhaites enseigner. Au regard de tes pièces justificatives, notre équipe te certifiera pour toutes les matières et niveaux auxquels tu peux prétendre. 
									<br></br><br></br>
									Une fois devenu(e) Sherpa, tu pourras changer à tout moment les matières, les niveaux et les tarifs auxquels tu enseignes dans tes paramètres.
								</span>
								},
								{h3 : "Dois-je devenir auto-entrepreneur pour enseigner ? ",
								p:<span>
									<br></br>
									Il t’appartient de déclarer tes impôts. À partir de là, tu es libre de choisir le régime fiscal de ton choix. 
									<br></br><br></br>
									Tu peux au choix déclarer tes cours via ton impôt sur le revenu (ou celui de tes parents), ou devenir auto-entrepreneur ce qui est souvent plus avantageux. 
								</span>
								},
							]}
						/>
					</div>
					<div className="bct-whatWait relw100 flex fdc jcc aic padh300 padv100 bgpastel_blue bsbb marb20 mob__padh50 mob__padv20 mob__marb40">
						<h2 className='big_h2 marb15 mob__fs20 mob__lh30'>Qu'attends-tu ? Deviens Sherpa dès demain !</h2>
						<p className='big_text light cgrey txtac marb35'>Candidater prend moins de 15 minutes. Nous répondons sous 24h.</p>
						<ClassicButton linkTo='/teacher_inscription' className='padv15 padh30' type='blank_green' defaultCss={false}>
							Devenir Sherpa &nbsp;<FontAwesomeIcon icon={faArrowRight} size='xs'/>
						</ClassicButton>
					</div>
					{
						txtAccroche && 
						<SEOBullshit className="mart120 mob__mart40"
							h2={_.get(this, 'context.contents[h2_#8].HTMLContent', '')}
							bullshit={buildBullshit(this.context.contents)}
						/>
					}
				</div>
			</div>
		)
	}
};
export default BecomeTeacher;