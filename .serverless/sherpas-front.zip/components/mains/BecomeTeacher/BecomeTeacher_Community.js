import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faStar} from '@fortawesome/free-regular-svg-icons';
import {faArrowRight, faCheck} from '@fortawesome/free-solid-svg-icons';
import Link from 'next/link';

const BecomeTeacher_Community = props => (
	<div className="bct-community relw100 bsbb flex aic jcse fdc mart70">
		<div className="bct-star fs50 cyellow marb30">
			<FontAwesomeIcon icon={faStar}/>
		</div>
		<h2 className='big_h2 padh300 txtac marb90 mob__padh20'>
			{props.h2}
		</h2>
		<div className="bct-communityMain relw100 marb30">
			<div className="bct-communityImage">
				<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/photo_page_sherpa.jpg"/>
			</div>
			<div className="bct-points flex jcse mob__fdc mob__relw100">
				<div className="bct-pointsText relw55 flex fdc big_text light cgrey mob__relw100 mob__marv30">
					<p>
						Étudiant à l’Université ou en Grande École, professeur de l’Éducation Nationale ou Professionnel, grâce aux cours en ligne tu vas rencontrer des élèves formidables !
					</p>
					<p>
						Donne cours où tu le souhaites et quand tu le souhaites, sans avoir besoin de te déplacer. En France ou depuis l ‘étranger, tu as plus de 300 matières à enseigner.
					</p>
					<p>Rejoins la communauté des Sherpas !</p>
					<Link href='/teacher_inscription'><a>Je deviens Sherpa <FontAwesomeIcon icon={faArrowRight} size='xs'/></a></Link>
				</div>
				<div className="bct-pointsChecks flex fdc classic_text cblue mob__relw100">
					<p><span><FontAwesomeIcon icon={faCheck}/></span>&nbsp; En devenant Sherpa tu restes 100% indépendant(e).</p>
					<p><span><FontAwesomeIcon icon={faCheck}/></span>&nbsp; Donne cours où tu veux, quand tu veux, c’est flexible.</p>
					<p><span><FontAwesomeIcon icon={faCheck}/></span>&nbsp; Accepte et refuse les élèves comme bon te semble.</p>
					<p><span><FontAwesomeIcon icon={faCheck}/></span>&nbsp; Fixe tes tarifs comme tu le souhaites.</p>
					<p><span><FontAwesomeIcon icon={faCheck}/></span>&nbsp; 5% de commission si tu trouves tes élèves.</p>
					<p><span><FontAwesomeIcon icon={faCheck}/></span>&nbsp; 15% de commission si nous te proposons un élève.</p>
				</div>
			</div>
		</div>
	</div>
);
BecomeTeacher_Community.defaultProps = {
	h2 : <span>Rejoins <span className='cgreen'>la plus grande communauté de professeurs</span> particuliers en ligne de France</span>
};
export default BecomeTeacher_Community;