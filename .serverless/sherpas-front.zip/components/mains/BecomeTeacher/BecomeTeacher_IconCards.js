import ThreeIconCards from '/components/misc/ThreeIconCards/ThreeIconCards.js';

const BecomeTeacher_IconCards = props => (
	<div className="bct-iconCards relw100 bsbb flex jcse fdc aic marb10 mob__marb0 padv70 mob__padv40 mob__padh5">
		<h2 className="big_h2 marb15">
			{props.h2} 
		</h2>
		<p className="bct-iconsTitle big_text light cgrey marb60">
			{props.p}
		</p>
		<div className="relw75">
			<ThreeIconCards/>
		</div>
	</div>
);
BecomeTeacher_IconCards.defaultProps = {
	h2 : <span>Pourquoi donner des cours particuliers <span className='cgreen'>en ligne ?</span></span>,
	p : <span>Grâce à nos cours en ligne, nous t’aidons à avoir un job régulier, flexible et bien payé.</span>
};
export default BecomeTeacher_IconCards;