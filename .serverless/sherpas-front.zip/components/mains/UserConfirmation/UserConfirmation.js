// import './TeacherContactBox.scss';
// import GreenButton from '/components/misc/GreenButton/GreenButton.js';
// import SmallAlert from '/components/misc/SmallAlert/SmallAlert.js';
// import Bus from '/static/tools/bus.js';
// import {ClassicModal, openModal} from '/components/misc/ClassicModal/ClassicModal.js';
import FormModal from '/components/misc/FormModal/FormModal.js';
import _ from 'lodash';
// import {isMobile} from 'react-device-detect';
import {setCookie} from '/static/tools/tools.js';
import {getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {validateEmail, purgeNonLetters, isPhone} from '/static/tools/misc.js';

class UserConfirmation extends React.Component {
	constructor(props) {
		super(props);
	}

	static contextType = WebsiteContext;

	render() {
		console.log('çontext', this.context);
		const user = _.get(this, 'context.user', {});
		const title = user.type == 'parent' ? "Confirmez votre compte Parent" : "Confirme ton compte Étudiant";
		return (
			<div className="Login relw100 flex aic jcc relh100">
				<FormModal
					title={title}
					inputs={[
						{
							value : 'email',
							label : 'Adresse email',
							type : 'email',
							check : e=>(!validateEmail(e) ? "Mail invalide" : false),
							defaultValue : user.email,
							disabled : true
						},
						[
							{
								value : 'fname',
								label : 'Prénom',
								type : 'text',
								transform : purgeNonLetters,
								defaultValue : user.fname,
								disabled : true
							},
							{
								value : 'lname',
								label : 'Nom',
								type : 'text',
								transform : purgeNonLetters,
								defaultValue : user.lname,
								disabled : true
							}
						],
						{
							value : 'psswd',
							label : 'Mot de passe',
							type : 'password',
							check : v=>(v.length < 6 ? "Au moins 6 caractères" : false)
						},
						{
							value : 'phone',
							label : 'Téléphone',
							check : v=>(!isPhone(v) ? "Numéro invalide" : false),
							transform : v=>(isPhone(v) || v),
							defaultValue : user.phone,
							disabled : true
						}
					]}
					submitUrl='tck_users/confirm_with_slug'
					onSubmitSuccess={suc => {
						setCookie('loginCookie', suc._id);
						setCookie('cookey', _.get(suc, 'devInfos.cookey'));
						getAlert("Votre compte a été activé, vous allez être redirigé dans quelques instants...");
						setTimeout(() => window.location = '/home', 2000);
					}}
					beforeSend={values => {
						return {user, slug : this.context.slug, psswd : values.psswd};
					}}
				/>
			</div>
		)
	}
};
export default UserConfirmation;