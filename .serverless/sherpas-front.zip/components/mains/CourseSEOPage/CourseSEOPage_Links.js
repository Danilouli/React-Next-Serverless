import LinksBoard from '/components/misc/LinksBoard/LinksBoard.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {useContext} from 'react';
import {getLinksFromContext} from '/static/tools/tools.js';
import _ from 'lodash';

const CourseSEOPage_Links = props => {
	const ctx = useContext(WebsiteContext);
	let {subjectLinks, levelLinks} = getLinksFromContext(ctx);
	return (
		<div className='csp-links large_vertical_part'>
			{
				_.get(ctx, 'contents[h2_#8].HTMLContent') &&
				<div className='csp-linksBoard relw55 mart50 mob__relw95'>
					<h2 className='big_h2 marb20 txtac'>
						{ctx.contents['h2_#8'].HTMLContent}
					</h2>
					<LinksBoard
						links={levelLinks}
					/>
				</div>
			}
			{
				_.get(ctx, 'contents[h2_#9].HTMLContent') &&
				<div className='csp-linksBoard relw55 mart50 mob__relw95'>
					<h2 className='big_h2 marb20 txtac'>
						{ctx.contents['h2_#9'].HTMLContent}
					</h2>
					<LinksBoard
						links={subjectLinks}
					/>
				</div>
			}
		</div>
	)
};
export default CourseSEOPage_Links;