import Link from 'next/link';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';

const CourseSEOPage_ReadBlog = props => (
	<div className="csp-readBlog flex jcsb relw100">
		<div className="csp-readBlogText relw50 mob__relw100">
			<p className='roboto fs20 cblack marb15'>Envie de lire plus d'articles?</p>
			<p className='roboto fs12 cblack'>Pleins d'astuces orientation, méthodologie, motivation & productivité.</p>
		</div>
		<div className="csp-blogLink">
			<Link href="#" passHref><a className='roboto light fs24'>Lire notre blog <FontAwesomeIcon size='xs' icon={faArrowRight}/></a></Link>
		</div>
	</div>
);
export default CourseSEOPage_ReadBlog;