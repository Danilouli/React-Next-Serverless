import CourseSEOPage_Head from './CourseSEOPage_Head.js';
import CourseSEOPage_Links from './CourseSEOPage_Links.js';
import CourseSEOPage_Articles from './CourseSEOPage_Articles.js';
import CourseSEOPage_ReadBlog from './CourseSEOPage_ReadBlog.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import TeachersList from '/components/misc/TeachersList/TeachersList.js';
import StepsOnlineCourses from '/components/misc/StepsOnlineCourses/StepsOnlineCourses.js';
import TeachersCarousel from '/components/misc/TeachersCarousel/TeachersCarousel.js';
import {studentReviews} from '/static/data/carousel_cards.js';
import {buildBullshit} from '/static/tools/misc.js';
import SEOBullshit from '/components/misc/SEOBullshit/SEOBullshit.js';
import './CourseSEOPage.scss';
import _ from 'lodash';

class CourseSEOPage extends React.Component {
	constructor(props) {
		super(props);
	}

	static contextType = WebsiteContext;

	render() {
		return (
			<div className='CourseSEOPage'>
				<div className='csp-mainContainer relw100 flex fdc aic'>
					<CourseSEOPage_Head
						h1={this.context.contents.h1.HTMLContent}
						h2={this.context.contents['h2_#1'].HTMLContent}
						inputPlaceholder="Pour quelle matière ? (Maths, Français...)"
					/>
					<div className='csp-teachersList relw100 flex jcc aic mart80 mob__mart50'>
						<div className='csp-teachersListContainer relw60'>
							<div className="csp-teachersListH2 rlw100 flex jcc marb35 mob__padh20">
								<h2 className="camphor bold fs20 cgreen">
									{this.context.contents['h2_#2'].HTMLContent}
								</h2>
							</div>
							<div className="csp-teachersList">
								<TeachersList more={true} teachers={this.context.teachers} filters={{subjects : [_.get(this, 'context.subject', 'maths')], level : _.get(this, 'context.level', 'lycee')}}/>
							</div>
						</div>
					</div>
					<div className="csp-steps relw100 flex jcc aic mart110 mob__mart30">
						<div className="csp-stepsContainer relw75 flex fdc jcc aic">
							<div className="flex jcse fdc aic mob__marb100">
								<h2 className='big_h2 marb15'>{this.context.contents['h2_#3'].HTMLContent}</h2>
								<p className='cr26 cgrey'>Voici comment commencer : c'est très simple !</p>
							</div>
							<StepsOnlineCourses/>
						</div>
					</div>
					<div className="csp-seoBs relw100 flex jcc aic fdc">
						<h2 className='big_h2 marb15 txtac relw100'>
							{this.context.contents['h2_#7'].HTMLContent}
						</h2>
						<p className='camphor classic_text lh35 cgrey txtac relw58'>
							À la fin de chaque cours, les élèves laissent un avis sur la plateforme, <br/> garantissant le sérieux de nos professeurs.
						</p>
					</div>
				</div>
				<div className='csp-carousel mart110 relw100 marb100 mob__mart30 mob__marb40'>
					<TeachersCarousel
						cards={studentReviews}
					/>
				</div>
				<div className="csp-links relw100 flex fdc jcc aic marb130">
					<CourseSEOPage_Links/>
					<div className="csp-bigBs relw100 flex fdc jcse aic mart100">
						{
							_.get(this.context, 'contents[h2_#10].HTMLContent') &&
							<SEOBullshit
								h2={this.context.contents['h2_#10'].HTMLContent}
								bullshit={buildBullshit(this.context.contents)}
							/>
						}		
					</div>
					{/*
						_.get(this.context, 'contents[h2_#11].HTMLContent') &&
						<CourseSEOPage_Articles
							h2={this.context.contents['h2_#11'].HTMLContent}
						/>
					*/}
					{/* <div className="csp-readBlog relw40 mob__relw90 flex jcc aic mart70 mob__mart10 brad_normal boxs_extra-light pad35">
						<CourseSEOPage_ReadBlog/>
					</div> */}
				</div>
			</div>
		)
	}
};
export default CourseSEOPage;