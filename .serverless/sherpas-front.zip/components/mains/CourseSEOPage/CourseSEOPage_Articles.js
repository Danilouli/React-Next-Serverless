import ArticleThumbnail from '/components/misc/ArticleThumbnail/ArticleThumbnail.js';

const CourseSEOPage_Articles = props => (
	<div className="csp-articles flex relw70 mob__relw100 fdc jcse aic mob__mart30">
		<div className="csp-articlesTitle">
			<h2 className='big_h2 txtac marb15 mob__padh10'>{props.h2}</h2>
			<p className='cr26 cgrey mob__padh10'>{props.p}</p>
		</div>
		<div className="csp-articlesList relw100 flex fww jcse aic mart120 mob__mart30">
			<div className="csp-article">
				<ArticleThumbnail/>
			</div>
			<div className="csp-article">
				<ArticleThumbnail/>
			</div>
			<div className="csp-article">
				<ArticleThumbnail/>
			</div>
			<div className="csp-article">
				<ArticleThumbnail/>
			</div>
			<div className="csp-article">
				<ArticleThumbnail/>
			</div>
			<div className="csp-article">
				<ArticleThumbnail/>
			</div>
		</div>
	</div>
);
CourseSEOPage_Articles.defaultProps = {
	h2 : <span>Nos meilleurs articles sur les <span className='cgreen'>Mathématiques</span></span>,
	p : <span>Tous les jours, notre équipe rédige des articles pour aider les étudiants à réussir</span>
};
export default CourseSEOPage_Articles;