import FindTeacherBoard from '/components/misc/FindTeacherBoard/FindTeacherBoard.js';
import Dynamic from 'next/dynamic';
import MediaQuerySSR from 'react-responsive';
const MediaQuery = Dynamic(() => Promise.resolve(MediaQuerySSR), {
	ssr: false
});

const CourseSEOPage_Head = props => (
	<div className="csp-head relw100 flex jcc aic mart60 mob__mart0">
		<div className="csp-headContainer relw82 mob__relw100 brad_light flex boxs_extra-light">
			<div className="csp-findTeacherBoard relw55 mob__relw100 flex jcc aic">
				<FindTeacherBoard {...props} />
			</div>
			<MediaQuery query="(min-width: 1200px)">
				<div className="csp-image relw45 flex jcc aic bradr_light">
					<img className='relh100 relw100 bradr_light' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/bureau_visuel.jpg'></img>
				</div>
			</MediaQuery>
		</div>
	</div>
);
CourseSEOPage_Head.defaultProps = {
	h1 : (
			<span>
				Besoin de cours particuliers <span className='cgreen'>de Mathématiques</span> à Bourg-en-Bresse ? Choisissez plutôt des cours en ligne !
			</span>
		),
	h2 : <span>Choisissez le prof de Mathématiques depuis Paris et programmez un RDV pédagogique gratuit par visioconférence. Réservez ensuite des cours particuliers en ligne adaptés à votre emploi du temps.</span>,
	inputPlaceholder : 'Pour quel Niveau ? (Lycée, Prépa ...)'
}
export default CourseSEOPage_Head;