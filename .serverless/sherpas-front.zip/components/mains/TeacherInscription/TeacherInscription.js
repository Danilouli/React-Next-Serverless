import './TeacherInscription.scss';
import ClassicForm from "/components/misc/ClassicForm/ClassicForm.js"
import SubjectsAdder from "/components/misc/SubjectsAdder/SubjectsAdder.js"
import GreenButton from "/components/misc/GreenButton/GreenButton.js"
import {validateEmail, purgeNonLetters, isPhone} from '/static/tools/misc.js';
import {api} from '/static/tools/network.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';

const required = ['fname', 'lname', 'email', 'psswd', 'birthDate', 'phone', 'hours', 'sex', 'institution', 'certifications'];

const parseCertificationsInSubjects = certifs => {
	let ret = {};
	let subjects = _.uniq(certifs.map(c=>c.subject));
	for (let s of subjects) {
		let corresp = _.uniq(certifs.filter(c=>c.subject == s));
		ret[s] = {};
		for (let c of corresp) {
			ret[s][c.level] = {
				price : c.price,
				document : c.document,
				certified : false,
				wants : true
			}
		}
	}
	console.log('ret', ret);
	return ret;
}

class TeacherInscription extends React.Component {
	constructor(props) {
		super(props);
	}

	static contextType = WebsiteContext;
	
	submitForm() {
		let toSend = {};
		toSend.selfSignedUp = true;
		toSend.teacherInfos = {};
		toSend.type = 'teacher';
		for (let r of required) {
			let inLocStor = localStorage.getItem(`shr_tiform_${r}`);
			if (!inLocStor) {
				console.error('is void', r);
				alert('Merci de bien vouloir remplir chaque champs');
				return;
			}
			if (r == 'certifications') {
				let certifs = JSON.parse(inLocStor);
				for (let c of certifs) {
					if (!c.document)
						return alert('Merci de bien vouloir envoyer tous les documents');
					if (c.price < 1200)
						return alert('Merci de ne pas mettre de prix plus bas que 9 euros');
					if (c.price > 2400)
						return alert('Merci de ne pas mettre de prix plus haut que 24 euros');
				}
				let parsed = parseCertificationsInSubjects(certifs);
				// toSend.teacherInfos.certifications = certifs;
				toSend.teacherInfos.subjectsTaught = parsed;
			}
			else if (r == 'birthDate') {
				toSend[r] = (new Date(inLocStor)).getTime();
			}
			else if (r == 'hours') 
				toSend.teacherInfos.hours = parseInt(inLocStor);
			else if (r == 'institution') 
				toSend.teacherInfos.institution = inLocStor;
			else
				toSend[r] = inLocStor;
		}
		api.post('tck_users/signup', {
			update : toSend
		})
		.then(suc => {
			console.log('Bien inscrit', suc);
			getAlert("Ton inscription a bien été reçue, nous te tenons au courant par mail pour les prochaines étapes ! La page va automatiquement se quitter...");
			setTimeout(() => window.location = '/landing', 3000);
		})
		.catch(err => {
			getAlert("Une erreur est survenue, vérifie que le mail n'est pas déja inscrit et que les informations sont valides");
			console.error('Mal inscrit', err);
		});
	}

	render() {
		const {subjects, levels} = this.context.lang;
		return (
			<div className="relw100 flex fdc aic TeacherInscription">
				<div className="relw80 flex fdc mob__relw95">
					<div className="relw100 flex fdc marb100 mart50">
						<h2 className='classic_h2'>Remplis puis soumets ta candidature</h2>
						<span className='classic_text cgrey'>Nous appliquons des critères rigoureux de sélection pour assurer le sérieux de la communauté.</span>
					</div>
					<div className="relw100 flex fdr jcsb tisc-part mob__fdc">
						<div className="relw28 flex fdc mob__relw100 mob__marb10">
							<p className='tisc-partTitle marb10'>1. Ton Profil</p>
							<p className='tisc-partSubTitle'>Toutes les informations que tu nous transmets ne seront jamais partagées à des tiers. </p>
						</div>
						<div className="relw70 tisc-partForm tisc-profileForm mob__relw100">
							<ClassicForm
								withButton={false}
								localStoragePrefix='tiform'
								cleanLocalStorage={true}
								inputs={[
									{
										value : 'fname',
										label : 'Prénom',
										transform : purgeNonLetters
									},
									{
										value : 'lname',
										label : 'Nom',
										transform : purgeNonLetters
									},
									{
										value : 'email',
										label : 'Adresse email',
										type : 'email',
										check : e=>(!validateEmail(e) ? "Mail invalide" : false),
									},
									{
										value : 'psswd',
										label : 'Mot de passe',
										type : 'password',
										check : v=>(v.length < 6 ? "Au moins 6 caractères" : false)
									},
									{
										value : 'birthDate',
										label : 'Date de naissance',
										type : 'date'
									},
									{
										value : 'phone',
										label : 'Téléphone',
										type : 'text',
										check : v=>(!isPhone(v) ? "Numéro invalide" : false),
										transform : v=>(isPhone(v) || v)
									},
									{
										value : 'hours',
										label : 'Heures de cours que tu peux dispenser / sem',
										type : 'select',
										defaultValue : 1,
										options : [
											{
												name : "1 Heure",
												value : 1
											},
											{
												name : "2 Heures",
												value : 2
											},
											{
												name : "3 Heures",
												value : 3
											},
											{
												name : "4 Heures",
												value : 4
											},
											{
												name : "Plus de 5 heures",
												value : 5
											}
										]
									},
									{
										value : 'sex',
										label : 'Genre',
										type : 'select',
										defaultValue : 'female',
										options : [
											{
												name : "Femme",
												value : 'female'
											},
											{
												name : "Homme",
												value : 'male'
											}
										]
									},
									{
										value : 'institution',
										label : "Université / École",
										type : 'text'
									}
								]}
							/>
						</div>
					</div>
					<div className="relw100 flex fdr jcsb tisc-part mob__fdc">
						<div className="relw28 flex fdc mob__relw100 mob__marb10">
							<p className='tisc-partTitle marb10'>2. Les matières que tu veux enseigner</p>
							<p className='tisc-partSubTitle'>Quelle matière souhaites-tu enseigner ?</p>
							<p className='tisc-partSubTitle marb30'>Pour quel niveau ? À quel prix ?</p>
							<p className='tisc-partSubTitle marb10'>NB : Tu pourras changer tes tarifs plus tard dans tes paramètres.</p>
							<p className='tisc-partSubTitle marb10'>Télécharge autant de justificatifs (relevés de notes, diplôme) que nécessaire pour justifier ton niveau dans chaque matière souhaitée à l’étape 2.</p>
							<p className='tisc-partSubTitle marb10'>NB : Tous les justificatifs doivent faire apparaître ton nom et prénom.</p>
							<p className='tisc-partSubTitle marb10'>NB 2 : Les justificatifs du Supérieur permettent aussi d’enseigner au Lycée et Collège. </p>
						</div>
						<div className="relw70 tisc-partForm tisc-subjectsForm mob__relw100">
							<p className='marb30'>Ajouter une nouvelle Matière et / ou un nouveau Niveau.</p>
							<SubjectsAdder
								{...{subjects, levels}}
								inStorageName='tiform_certifications'
							/>
							<p className='tisc-partSubTitle mart80 lh20'>
								<span className='bold'>En t’inscrivant, tu commenceras au niveau de Nouveau Sherpa : tu pourras fixer tes tarifs entre 12 et 24€/h.</span><br></br> Si tu as déjà une expérience d’enseignement, contacte-nous par mail à support@les-sherpas.co après avoir candidaté, nous pourrons éventuellement te faire atteindre un niveau supérieur qui te permettra de fixer des prix plus élevés dès tes débuts.
								<span className='bold'>(Tarifs au Niveau Sherpa : 12 à 35€/h, Tarifs au niveau Super Sherpa 12 à 300€/h).</span>
							</p>
						</div>
					</div>
					<div className="relw100 flex fdrr marb50 mob__fdc mob__aic">
						<GreenButton className="relw30 mob__relw90"
							onClick={this.submitForm}
						>
							Soumettre ta candidature
						</GreenButton>
					</div>
				</div>
			</div>
		)
	}
};
export default TeacherInscription;