import './HowItWorks.scss';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import HowItWorks_Head from './HowItWorks_Head.js';
import ThreeIconCards from '/components/misc/ThreeIconCards/ThreeIconCards.js';
import FindATeacherSmallCards from '/components/misc/FindATeacherSmallCards/FindATeacherSmallCards.js';
import StepsOnlineCourses from '/components/misc/StepsOnlineCourses/StepsOnlineCourses.js';
import TextAndImageSide from '/components/misc/TextAndImageSide/TextAndImageSide.js';
import SocialProofs from '/components/misc/SocialProofs/SocialProofs.js';
import WhiteButton from '/components/misc/WhiteButton/WhiteButton.js';

class HowItWorks extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div className="HowItWorks large_vertical_part">
				<HowItWorks_Head/>
				<div className="relw70">
					<StepsOnlineCourses
						step1={{
							h2 : "Contactez un Professeur",
							p : "Utilisez notre marketplace pour trouver le professeur de vos rêves. Nous avons forcément la perle rare !"
						}}
						step2={{
							h2 : "Prenez un RDV gratuit de 20min.",
							p : "C'est idéal pour vérifier que le professeur correspond à vos besoins tout en testant les cours en ligne."
						}}
						step3={{
							h2: "Commencez les progrès !",
							p: "Prenez des cours particuliers en ligne où et quand vous voulez, en visioconférence. C'est sans engagement ni frais de dossiers."
						}}
					/>
				</div>
				<div className="relw72 marb120">
					<h2 className="classic_h2 relw100 flex jcc aic marb50">
						Les cours particuliers en ligne, <span className="cgreen">&nbsp;comment ça marche ?</span>
					</h2>
					<FindATeacherSmallCards/>
				</div>
				<TextAndImageSide className='hiw-meeting'/>
				<TextAndImageSide
					className='hiw-humanTextAndImage marb100'
					reverse={true}
					imgUrl='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/group-10.svg'
					h2={<span>… les cours particuliers en ligne sont pratiques et là <span className='cgreen'> pour vous faire gagner du temps ! </span></span>}
					p={<p>Les cours particuliers Les Sherpas s’intègrent sans effort à vos habitudes. Réservez-les un par un, ou prenez un rendez-vous régulier aussi longtemps que vous le souhaitez. Encore mieux, grâce aux cours en ligne vous évitez de vous déplacer, et ne payez pas cela dans le prix des cours. Prenez cours où vous voulez, quand vous voulez !</p>}
					link={false}
				/>
				<div className="relw80">
					<ThreeIconCards
						className='marb100'
						iconCards={[
							{
								color : 'green',
								icon : 'heart',
								title : "Les meilleurs professeurs particuliers !",
								text : "Nous sélectionnons à la main tous les professeurs, seul 1 sur 7 est retenu."
							},
							{
								color : 'yellow',
								icon : 'lock',
								title : "Toutes les communications sont sécurisées.",
								text : "Vos coordonnées personnelles ne sont jamais diffusées aux professeurs."
							},
							{
								color : 'blue',
								icon : 'thumbsUp',
								title : "Où vous voulez, quand vous voulez.",
								text : "Les cours en ligne sont plus pratiques et moins chers que des cours classiques."
							}
						]}
					/>
				</div>
				<div className="hiw-cta relw100 flex txtac fdc jcc aic bsbb padh240 padv120">
					<h2 className="classic_h2 marb15">Parlez à un Sherpa et commencez les cours aujourd’hui !</h2>
					<p className='big_text light padh30 marb40 cgrey'>Réviser, combler des lacunes, solidifier le dossier scolaire,<br></br> viser la tête de classe, tout est possible !</p>
					<WhiteButton linkTo='/gallery' linkToAs='/professeurs'>
						Trouver un Sherpa &nbsp; <FontAwesomeIcon icon={faArrowRight}/>
					</WhiteButton>
				</div>
				<div className="hiw-socialProofs relw100 bsbb padv65 flex aic jcc">
					<div className="relw70">
						<SocialProofs/>
					</div>
				</div>
			</div>
		)
	}
};
export default HowItWorks;