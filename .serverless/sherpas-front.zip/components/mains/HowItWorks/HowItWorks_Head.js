const HowItWorks_Head = props => (
	<div className="hiw-head relw100 flex fdc jcse aic mart80">
		<h1 className="classic_h2 marb15">Des cours particuliers individuels et en ligne <span className="cgreen">qui font vraiment monter les notes</span></h1>
		<h2 className="light cblue fs20">Des leçons flexibles et qui s’adaptent à vos habitudes, où vous voulez, quand vous voulez.</h2>
		<div className="hiw-laptop relw100 bsbb padv70 flex jcc aic">
			<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/Macbook-Angie.png"/>
			<div className="hiw-greenRect"></div>
		</div>
	</div>
);
export default HowItWorks_Head;