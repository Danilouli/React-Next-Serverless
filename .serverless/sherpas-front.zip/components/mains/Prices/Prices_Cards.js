import SmallCard from '/components/misc/SmallCard/SmallCard.js';

const Price_Cards = props => (
	<div className="pric-cards relw58 txtac mob__relw100 flex fdc jcc aic jcse marv100 mob__marb40 mob__marv0">
		<h2 className='classic_h2 marb15 padh8vw mob__padh10'>C’est Gratuit pour commencer !<br/>Prenez un <span className='cgreen'>RDV Pédagogique</span> de 20 min</h2>
		<p className='rl20 cgrey marb60 mob__padh10'>Pas de frais de dossier. Commencez par un Rendez-vous Pédagogique gratuit de 20 min.</p>
		<div className="pric-cardsContainer relw100 flex jcc aic fdr mob__fdc">
			<div className="pric-card marr60 mob__marr0 mob__marb20">
				<SmallCard/>
			</div>
			<div className="pric-card pric-transpCard">
				<p className='classic_h2 marb20'>12 - 50€/h <br/>de cours.</p>
				<p className='fs16 lh20 light cblue'>En fonction du niveau et du professeur choisi</p>
			</div>
		</div>
	</div>
);
export default Price_Cards;