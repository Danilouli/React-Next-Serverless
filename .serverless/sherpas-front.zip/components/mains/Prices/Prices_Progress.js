import StepsOnlineCourses from '/components/misc/StepsOnlineCourses/StepsOnlineCourses.js';
import WhiteButton from '/components/misc/WhiteButton/WhiteButton.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';

const Prices_Progress = props => (
	<div className="pric-progress relw65 flex fdc jcc aic">
		<h2 className='classic_h2 txtac'>Prêt à faire de beaux progrès ? <br/><span className='cgreen'>Voici comment commencer !</span></h2>
		<img className='mart80 pric-progressImage' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/persos-page-tarif.svg'/>
		<StepsOnlineCourses
			step3={{
				h2 : <span>Payez vos cours à la minute</span>,
				p : <span>Vous payez exactement pour ce que vous consommez et n'êtes pas engagé. <br/>&nbsp;</span>
			}}
		/>
		<WhiteButton className='marb120' linkTo='/gallery' linkToAs='/professeurs'>Trouver un Sherpa &nbsp; <FontAwesomeIcon icon={faArrowRight} size='xs'/></WhiteButton>
	</div>
);
export default Prices_Progress;