import './Prices.scss';
import FindTeacherBoardHeader from '/components/misc/FindTeacherBoardHeader/FindTeacherBoardHeader.js';
import Prices_Cards from './Prices_Cards.js';
import Prices_Budgets from './Prices_Budgets.js';
import Prices_Progress from './Prices_Progress.js';
import PaymentBullshit from '/components/misc/PaymentBullshit/PaymentBullshit.js';
import Questions from '/components/misc/Questions/Questions.js';
import WhiteButton from '/components/misc/WhiteButton/WhiteButton.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';

class Prices extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div className="Prices relw100 large_vertical_part">
				<FindTeacherBoardHeader
					h1={ <span>Des cours particuliers en ligne <span className='cgreen'>dès 12€/h</span> et avec le sourire !</span>}
					h2={"Commencez gratuitement, puis payez après chaque cours."}
				/>
				<Prices_Cards/>
				<Prices_Budgets/>
				<Prices_Progress/>
				<div className="relw52 marb100">
					<PaymentBullshit/>
				</div>
				<div className="relw63 marb130 mob__marb30">
					<Questions
						questions={[
							{h3 : "Pourquoi choisir les cours en ligne ?",
							p:<span>Les cours en ligne ont lieu par visioconférence individuelle dans notre salle de classe en ligne : grâce aux cours en ligne, votre enfant a cours où et quand vous le souhaitez, partout en France et avec les meilleurs professeurs. C’est toujours sans engagement ni frais de dossier.</span>},
							{
								h3 : "Qu’est-ce que le  RDV Pédagogique ?",
								p:<span>
									Une fois que vous avez trouvé un professeur qui vous intéresse, ce RDV gratuit de 20 min permet de le rencontrer pour lui expliquer vos attentes et vérifier qu’il vous convient. Contactez un professeur via son annonce, puis discutez sur la plateforme pour convenir ensemble d’un RDV.
								</span>
							},
							{
								h3 : "Quels sont les tarifs ? Comment paye-t-on les cours ? ",
								p:<span>
									Chaque Sherpa fixe ses tarifs en fonction de son expérience et de la matière enseignée : la majorité des professeurs facturent entre 15 et 30€/h. Vous payez par carte à la fin du cours au prorata du temps passé avec le professeur. Des frais de service de quelques dizaines de centimes sont prélevés à la fin de la leçon afin d’assurer le bon fonctionnement de la plateforme.
								</span>
							},
							{h3 : "A t-on besoin de matériel pour prendre cours ?",
							p:<span>
								Il vous suffit d’un ordinateur (PC ou Mac) avec une connexion internet rapide et stable.
								Notre application mobile est disponible gratuitement sur iOS et Android. Dans les matières scientifiques, nous conseillons l’achat d’une tablette graphique à 20€ pour écrire des équations sur le tableau blanc partagé dans la salle de classe en ligne.
							</span>
							},
							{h3 : "Comment sont sélectionnés les professeurs ?",
							p:<span>
								Nos Sherpas sont triés sur le volet ! 	Seulement 1 candidat sur 7 est choisi pour devenir Sherpa. Nous étudions leur dossier (certificat de scolarité, relevé de notes ou diplôme) puis leur faisons passer un entretien afin d’évaluer leur motivation, leur pédagogie et leur écoute. 
							</span>
							},
							{h3 : "Est-il possible de prendre cours dans plusieurs matières ? ",
							p:<span>
								Oui ! Nos professeurs sont très souvent capables d’enseigner plusieurs matières.
								Il est aussi possible de prendre un Sherpa par matière souhaitée. C’est vous qui décidez ! 
							</span>
							},
						]}
					/>
				</div>
				<div className="relw70 flex fdc jcc aic marb110">
					<h2 className="big_h2 marb15">Parlez à un Sherpa et commencez les cours aujourd’hui !</h2>
					<p className='big_text light cgrey marb30'>N’attendez plus : vos progrès sont à un clic !</p>
					<WhiteButton linkTo='/gallery' linkToAs='/professeurs'>Trouver un Sherpa &nbsp; <FontAwesomeIcon icon={faArrowRight} size='xs'/></WhiteButton>
				</div>
			</div>
		)
	}
};
export default Prices;
