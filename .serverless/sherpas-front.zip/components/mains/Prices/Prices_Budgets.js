import Link from 'next/link';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';

const Prices_Budgets = props => (
	<div className="pric-budgets relw100 flex fdc jcc aic bgpastel_blue marb100">
		<h2 className='classic_h2 mart50 marb15 mob__padh10'>Des professeurs extraordinaires pour tous les budgets</h2>
		<p className='big_text light cgrey marb40 mob__padh10'>Prix variables en fonction de la matière et du niveau enseigné. </p>
		<div className="pric-budgetsLine relw100 flex fdr jcse aic marb50 mob__fdc">
			<div className="pric-budget">
				<h3>Nouveau Sherpa</h3>
				<p className='pric-budgetPrice'>12 - 22€/h</p>
				<p className='pric-budgetDescription'>Fraîchement sélectionné par notre équipe : beaucoup de disponibilités et très motivé mais avec encore peu d’avis.</p>
			</div>
			<div className="pric-budget">
				<h3>Sherpa</h3>
				<p className='pric-budgetPrice'>22 - 35€/h</p>
				<p className='pric-budgetDescription'>Sherpa depuis au moins 6 mois, ayant complété nos formations et avec d’excellents avis.</p>
			</div>
			<div className="pric-budget">
				<h3>Super Sherpa</h3>
				<p className='pric-budgetPrice'>35 - 50€/h</p>
				<p className='pric-budgetDescription'>Nos tuteurs les plus expérimentés, experts dans leurs domaines et avec des résultats éprouvés.</p>
			</div>
		</div>
		<Link href='/gallery' as='/professeurs' passHref><a>Trouvez un Sherpa <FontAwesomeIcon icon={faArrowRight} size='xs'/></a></Link>
		<p className="pric-smallText fs12 cgrey light mart40 marb30 relw40 txtac lh14 mob__relw90 mob__fs12">Nous prélevons un frais de service de quelques dizaines de centimes à la fin de votre leçon. Cela nous permet d’assurer le parfait fonctionnement de la plateforme de cours.</p>
	</div>
);
export default Prices_Budgets;