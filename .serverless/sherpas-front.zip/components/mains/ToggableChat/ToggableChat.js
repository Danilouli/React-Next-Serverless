import './ToggableChat.scss';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import _ from 'lodash';
import Bus from '/static/tools/bus.js';
import {faPaperclip, faSmile, faArrowRight, faCaretUp, faCaretDown, faCircleNotch} from '@fortawesome/free-solid-svg-icons';
import Textarea from 'react-textarea-autosize';
import './emoji-mart.scss';
import { Picker } from 'emoji-mart';
import {uploadToS3, api} from '/static/tools/network.js';
import { CellMeasurer, CellMeasurerCache, List } from 'react-virtualized';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {DEFAULTIMG} from '/static/tools/tools.js';

const concatMessages = function(pastMessages, futureMessages) {
	let concatenated = _.uniqBy([...(futureMessages || []), ...(pastMessages || [])], e => e.date);
	concatenated.sort((e1, e2) => (e1.date - e2.date));
	return concatenated;
}

class Message extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		const theDate = (new Date(this.props.message.date)).toLocaleString('fr-FR', {timeZone : 'Europe/Paris'});
		return (
			<div className='Message' id={`${this.props.message.date}_message`}>
				<div className='leftPart'>
					<img src={_.get(this, 'props.message.sender.profile.picture', DEFAULTIMG)}/>
				</div>
				<div className='rightPart'>
					<div className='nameAndTime'>
						<span className='name'>{this.props.message.sender.fname}</span>
						<span className='time'>Le {theDate}</span>
					</div>
					<div className='messageContent' dangerouslySetInnerHTML={{__html : this.props.message.content}}>
					</div>
				</div>
			</div>
		)
	}
};
export { Message };

class WriteMessageBox extends React.Component {
	constructor() {
		super()
		this.state = {
			message: '',
			emojisToggled : false,
			sending : false
		}
	}

	handleMessageChange = e => {
		this.setState({
			message: e.target.value
		})
	}

	handleSendMessage = () => {
		const bredMessage = this.state.message.replace(new RegExp('\r?\n','g'), '</br>');
		if (bredMessage.trim() == '')
			return;
		this.setState({sending : true});
		this.props.socket.emit('cli_new_message', {
			content: bredMessage,
			date : Date.now(),
			conversation : this.props.conversation
		}, ack => {
			if (!!ack)
				this.setState({sending : false, message : ''});
		});
	}

	componentDidMount() {
		Bus.when('emoji_to_add', e => {
			this.setState({
				message : this.state.message + e.detail.native
			});
		});
		Bus.when('toggle_emojis', () => {
			this.setState({
				emojisToggled : !this.state.emojisToggled
			})
		});
	}

	toggleEmojis() {
		Bus.cast('toggle_emojis');
	}

	handleUploadClick(e) {
		this.refs.fileUploader.click(e);
	}

	handleSubmitFile(e) {
		let file = e.target.files[0];
		this.setState({sending : true});
		uploadToS3(file)
		.then(suc => {
			let content = '';
			if (file.type.indexOf('image') >= 0) {
				content = `<a href="${suc.finalUrl}" target=_blank><img src="${suc.finalUrl}"></img></a>`;
			}
			else if (file.type.indexOf('video') >= 0) {
				content = `<video controls><source src="${suc.finalUrl}" type="${file.type}"></video>`;
			}
			else {
				content = `<a href="${suc.finalUrl}" target=_blank>${file.name}</a>`;
			}
			this.props.socket.emit('cli_new_file', {
				date : Date.now(),
				content : content,
				file : {url : suc.finalUrl, name : file.name},
				conversation : this.props.conversation
			}, ack => {
				if (!!ack)
					this.setState({sending : false});
			});
		})
		.catch(err => {
			console.error('err upload', err); //ERROR
		})
	}

	handleKeyPress(e) {
		if (e.key == 'Enter' && !e.shiftKey) {
			e.preventDefault();
			this.handleSendMessage();
		}
	}

	render() {
		return (
			<div className='WriteMessageBox'>
				<div>
					<Textarea maxRows={7} className='writeMessageInput' onKeyPress={this.handleKeyPress.bind(this)} placeholder='Ecrire un message ...' value={this.state.message} type="text" onChange={this.handleMessageChange} />
				</div>
				<input type='file' id='fileUploader' ref='fileUploader' style={{display : 'none'}} onChange={this.handleSubmitFile.bind(this)}></input>
				<div className='writeMessageBar'>
					<div className='chatOptions'>
						<span onClick={this.handleUploadClick.bind(this)}><FontAwesomeIcon icon={faPaperclip}/></span>
						<span active={`${this.state.emojisToggled}`} onClick={this.toggleEmojis}><FontAwesomeIcon icon={faSmile}/></span>
					</div>
					<span className='messageSendButton' onClick={this.handleSendMessage}>
						{
							this.state.sending ?
							<FontAwesomeIcon icon={faCircleNotch} spin/> :
							<FontAwesomeIcon icon={faArrowRight}/>
						}
					</span>
				</div>
			</div>
		)
	}
};
export { WriteMessageBox };

const ChatToggleBar = props => {
	let connectionStat = '';
	if (props.connectionStatus == 'disconnected')
		connectionStat = '(Déconnecté)';
	if (props.connectionStatus == 'reconnecting')
		connectionStat = '(Tentative de reconnection...)';
	return (
		<div onClick={props.onClick} className='ChatToggleBar' connection={props.connectionStatus} toggled={`${props.toggled}`}>
			<div className='chatToggleTitle'>Chat {connectionStat}</div>
			<div className='chatToggleCaretIcon'>
				{
					props.toggled ? 
					<FontAwesomeIcon icon={faCaretUp}/> :
					<FontAwesomeIcon icon={faCaretDown}/>
				}
			</div>
		</div>
	)
};

const cache = new CellMeasurerCache({
	defaultHeight: 50,
	fixedWidth: true
});

class ToggableChat extends React.Component {
	constructor() {
		super()
		this.state = {
			messages: [],
			chatId : null,
			toggled : true,
			emojisToggled : false,
			connectionStatus : 'connected'
		}
	}

	static contextType = WebsiteContext;

	checkForNewMessages = () => {
		if (this.state.chatId) {
			api.post(
				'tck_workspaces/get_messages_between',
				{
					chatId : this.state.chatId, after : _.get(this.state.messages, '0.date', Date.now() - 1) + 1,
					auth : this.context.auth
				})
				.then(messages => {
					this.setState({
						messages : concatMessages(this.state.messages, messages)
				});
			});
		}	
	};

	checkForPastMessages = () => {
		if (this.state.chatId) {
			api.post('tck_workspaces/get_messages_between',
			{
				chatId : this.state.chatId, before : _.get(this.state.messages, `${this.state.messages.length - 1}.date`, Date.now() - 1) + 1,
				auth : this.context.auth
			})
			.then(messages => {
				this.setState({
					messages : concatMessages(messages, this.state.messages)
				});
			});	
		}
	};

	scrollListToBottom() {
		let theList = _.get(this, 'listRef.current');
		if (theList && !this.state.toggled) {
			theList.scrollToRow(this.state.messages.length);
			setTimeout(() => theList.scrollToRow(this.state.messages.length), 100);
			setTimeout(theList.recomputeRowHeights, 150);
		}
	}

	componentDidMount() {
		Bus.whenWksIsReady(({workspace}) => {
			let chatId = `_wks_${workspace._id}_student`;
			api.post('tck_workspaces/get_messages_between', {
				chatId : chatId,
				number : 100,
				before : Date.now(),
				auth : this.context.auth
			})
			.then(messages => {
				this.setState({messages : messages.reverse(), chatId})
			})
			.catch(err => {
				this.setState({messages : [], chatId});
				console.error('errorus', err);
			});
		});
		Bus.when('toggle_emojis', () => {
			this.setState({emojisToggled : !this.state.emojisToggled})
		})
		this.props.socket.on('ser_new_message', newMsg => {
			this.setState({messages : concatMessages(this.state.messages, [newMsg])}, this.scrollListToBottom);
		});
		this.props.socket.on('ser_new_file', newFile => {
			this.setState({messages : concatMessages(this.state.messages, [newFile])}, this.scrollListToBottom);
		});
		this.props.socket.on('disconnect', () => {
			this.setState({connectionStatus : 'disconnected'});
		});
		this.props.socket.on('reconnecting', () => {
			this.setState({connectionStatus : 'reconnecting'});
		});
		this.props.socket.on('reconnect', () => {
			this.setState({connectionStatus : 'connected'});
			this.checkForNewMessages();
		});
		this.props.socket.on('connect', () => {
			this.setState({connectionStatus : 'connected'});
			this.checkForNewMessages();
		});
	}

	emojiSelected(e) {
		Bus.cast('emoji_to_add', e);
	}

	handleScroll = (e) => {
		if (e.scrollTop <= 0) {
			this.checkForPastMessages();
		}
	}

	toggleHandler = () => {
		this.setState({toggled : !this.state.toggled}, this.scrollListToBottom);
	}

	listRef = React.createRef();

	render() {
		function rowRenderer ({ index, isScrolling, key, parent, style }) {		  
			return (
			  <CellMeasurer
				cache={cache}
				columnIndex={0}
				key={key}
				parent={parent}
				rowIndex={index}
			  >
				{({ measure }) => (
				  // 'style' attribute required to position cell (within parent List)
				  	<div key={key} style={style}>
						<div onLoad={measure}>
				  			<Message message={this.state.messages[index]}/>
						</div>
			  		</div>
				)}
			  </CellMeasurer>
			);
		};
		return (
			<div className='ToggableChat'>
				<ChatToggleBar connectionStatus={this.state.connectionStatus} toggled={this.state.toggled}
					onClick={this.toggleHandler.bind(this)}
				>
				</ChatToggleBar>
				<Picker
					style={{
						backgroundColor : 'white',
						zIndex : 199,
						position : 'absolute',
						right : '102%',
						bottom : '10%',
						display : this.state.emojisToggled ? 'block' : 'none'
					}} 
					set='emojione'
					onSelect={this.emojiSelected}
					color='#51c088'
					i18n={{
						categories: {
							search: 'Résultats de recherche',
							recent: 'Les plus utilisés',
							people: 'Smileys',
							nature: 'Animaux',
							foods: 'Aliments',
							activity: 'Activités',
							places: 'Voyage',
							objects: 'Objets',
							symbols: 'Symboles',
							flags: 'Drapeaux'
						  }
					}}
				/>
				{
					!this.state.toggled	?
					<div className='chatContainer' toggled={`${this.state.toggled}`}>
						{/* <div className='messagesContainer' onScroll={this.handleScroll.bind(this)}>
							{this.state.messages.map((message, index) => (
								<Message message={message} key={message.date} />
							))}
						</div> */}
						<div className="toggableChatList">
							<List
								ref={this.listRef}
								width={350}
								height={400}
								rowCount={this.state.messages.length}
								deferredMeasurementCache={cache}
								rowHeight={cache.rowHeight}
								rowRenderer={rowRenderer.bind(this)}
								onScroll={this.handleScroll.bind(this)}
							/>
						</div>
						<WriteMessageBox {...this.props} />
					</div> :
					<div></div>
				}
			</div>
		)
	}
};
export {ToggableChat};
