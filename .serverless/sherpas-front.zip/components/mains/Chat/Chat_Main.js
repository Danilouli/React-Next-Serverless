import {useState} from 'react';
import Textarea from 'react-textarea-autosize';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faPaperclip, faSmile, faCircleNotch, faExchangeAlt} from '@fortawesome/free-solid-svg-icons';
import '/static/stylesheets/vendor/emoji-mart.scss';
import { Picker } from 'emoji-mart';
import _ from 'lodash';
import Bus from '/static/tools/bus.js';
import {buildMessageJsx, datify} from '/static/tools/tools.js';
import {uploadToS3} from '/static/tools/network.js';
import { CellMeasurer, CellMeasurerCache, List, AutoSizer } from 'react-virtualized';

const cache = new CellMeasurerCache({
	defaultHeight: 50,
	fixedHeight: false,
	fixedWidth: true
});

const rowRenderer = function ({ index, isScrolling, key, parent, style }) {		  
	return (
	  <CellMeasurer
		cache={cache}
		columnIndex={0}
		key={key}
		parent={parent}
		rowIndex={index}
	  >
		{({ measure }) => {
			const message = _.get(this, `props.currentChat.messages[${index}]`);
			const {user} = this.props;
			const senderRedId = _.get(message, 'sender.ref_id');
			let isMe = (senderRedId == 'usr_'+user._id) || (user.type == 'parent' && user.others.find(e => e.ref_id == senderRedId));
			isMe = !!isMe;
			return (
				<div key={key} style={style}>
					<div className='cht-cell' me={`${isMe}`}>
						<Message message={this.props.currentChat.messages[index]} onLoad={measure}/>
					</div>
				</div>
			)
		}}
	  </CellMeasurer>
	);
};

class Message extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		const {message} = this.props;
		const dateParsed =  (new Date(_.get(message, 'date', Date.now()))).toLocaleDateString('fr-FR',
		{timeZone : 'Europe/Paris', month: 'numeric', day: 'numeric', hour : 'numeric', minute : 'numeric'});
		return (
			<div className="cht-message flex fdc marb20 brad_medium marh10">
				<div className="cht-messageTitle flex fdr">
					<span className='small_text marr10'>{_.get(message, 'sender.fname')}</span>
					<span className='mini_text cgrey'>Le {dateParsed}</span>
				</div>
				<div className="cht-messageContent mini_text mart10">
					{buildMessageJsx(message, {onElementLoad : this.props.onLoad})}
				</div>
			</div>
		)	
	}
};

const MessageBar = props => {
	const {currentChat} = props;
	let {readOnly} = currentChat;
	readOnly = !!readOnly;
	const [message, setMessage] = useState('');
	const [emojis, setEmojis] = useState(false);
	const [sending, setSending] = useState(false);
	const handleSendMessage = messageValue => {
		if (readOnly)
			return;
		const bredMessage = messageValue.replace(new RegExp('\r?\n','g'), '</br>');
		if (bredMessage.trim() == '')
			return;
		currentChat.socket.emit('cli_new_message', {
			date : Date.now(),
			content : bredMessage,
			chatId : currentChat.chatId
		}, ack => {
			if (!ack)
				return;
			setSending(false);
			setMessage('');
		});
	};
	const handleKeyPress = e => {
		if (readOnly)
			return;
		let messageValue = e.target.value;
		if (e.key == 'Enter' && !e.shiftKey && messageValue && messageValue.trim() != '') {
			e.preventDefault();
			handleSendMessage(messageValue);
		}
	};
	const handleSubmitFile = e => {
		if (readOnly)
			return;
		let file = e.target.files[0];
		setSending(true);
		uploadToS3(file)
		.then(suc => {
			let content = '';
			if (file.type.indexOf('image') >= 0) {
				content = `<a href="${suc.finalUrl}" target=_blank><img src="${suc.finalUrl}"></img></a>`;
			}
			else if (file.type.indexOf('video') >= 0) {
				content = `<video controls><source src="${suc.finalUrl}" type="${file.type}"></video>`;
			}
			else {
				content = `<a href="${suc.finalUrl}" target=_blank>${file.name}</a>`;
			}
			currentChat.socket.emit('cli_new_file', {
				date : Date.now(),
				content : content,
				file : {url : suc.finalUrl, name : file.name, type : file.type},
				chatId : currentChat.chatId
			}, ack => {
				if (!ack)
					return;
				setSending(false);
			});
		})
		.catch(err => {
			console.error('err upload', err); //ERROR
			setSending(false);
		})
	};
	const handlePaperClick = () => {
		if (readOnly)
			return;
		document.getElementById('chatFileUploader').click();
	};
	return (
		<div className="cht-messageBar flex aic">
			<div className="flex fdc relw85">
				<Textarea disabled={sending || readOnly} maxRows={7} className='cht-textarea relw100' value={message} onChange={e => setMessage(e.target.value)} onKeyPress={handleKeyPress} placeholder="Écrire un message ..." type="text" onClick={Bus.fcast('clicked_on_textarea')} />
				<input type='file' id='chatFileUploader' style={{display : 'none'}} onChange={handleSubmitFile}></input>
				<div className="cht-messageIcons mart20">
					<span className='marr15' onClick={()=>setEmojis(!emojis)} active={`${emojis}`}><FontAwesomeIcon icon={faSmile}/></span>
					<span><FontAwesomeIcon onClick={handlePaperClick} icon={faPaperclip}/></span>
				</div>
			</div>
			<div className="cht-mainButton relw12 txtac brad_medium fs12 marl50" readOnly={readOnly} onClick={() => handleSendMessage(message)}>
				{sending ? <span>Envoi&nbsp;<FontAwesomeIcon icon={faCircleNotch} spin/></span> : 'Envoyer'}
			</div>
			<Picker
				style={{
					backgroundColor : 'white',
					zIndex : 199,
					position : 'absolute',
					right : '102%',
					bottom : '10%',
					display : emojis ? 'block' : 'none'
				}} 
				set='emojione'
				onSelect={e => setMessage(message + e.native)}
				color='#51c088'
				i18n={{
					categories: {
						search: 'Résultats de recherche',
						recent: 'Les plus utilisés',
						people: 'Smileys',
						nature: 'Animaux',
						foods: 'Aliments',
						activity: 'Activités',
						places: 'Voyage',
						objects: 'Objets',
						symbols: 'Symboles',
						flags: 'Drapeaux'
						}
				}}
			/>
		</div>
	)
};

class Chat_Main extends React.Component {
	constructor(props) {
		super(props);
		const nowMessages = _.get(props, 'currentChat.messages', []);
		const lastNowMessage = nowMessages[nowMessages.length - 1];
		const nowDate = Date.now();
		this.begin = true;
		this.firstMessageDate = _.get(nowMessages, '[0].date', nowDate);
		this.lastMessageDate = _.get(lastNowMessage, 'date', nowDate);
		this.beginChatId == _.get(this, 'props.currentChat.chatId');
		this.state = {
			currentChatLength : _.get(props, 'currentChat.messages.length'),
			currentChatId : _.get(props, 'currentChat.chatId'),
			scrolled : false,
			actualIndex : 50
		};
	}

	recomputeListRowHeights() {
		let listR = _.get(this, 'listRef.current');
		if (listR)
			return listR.recomputeRowHeights();
	}

	scrollListToRow(index) {
		let listR = _.get(this, 'listRef.current');
		if (listR)
			return listR.scrollToRow(index);
	}

	componentDidUpdate(prevProps, prevState) {
		const nowDate = Date.now();
		const nowMessages = _.get(this.props, 'currentChat.messages');
		const nowLastMessage = nowMessages[nowMessages.length - 1];
		const nowLastMessageDate = _.get(nowLastMessage, 'date', nowDate);
		const nowChatId = _.get(this.props, 'currentChat.chatId');
		const differentChat = (prevProps.currentChat.chatId != nowChatId);
		const nowFirstMessageDate = _.get(nowMessages, '[0].date', nowDate);
		const scrollList = this.scrollListToRow.bind(this);
		const recomputeList = this.recomputeListRowHeights.bind(this);
		if ((this.lastMessageDate < nowLastMessageDate) || differentChat) {
			scrollList(nowMessages.length);
			setTimeout(() => {
				let tt  = document.getElementsByClassName('cht-virtualizedList')[0];
				tt.scrollTo(0, tt.scrollHeight);
			}, 1);
		}
		if (differentChat) {
			cache.clearAll();
			recomputeList();
			setTimeout(()=>{
				scrollList(nowMessages.length);
			}, 500);
			setTimeout(() => {
				let tt  = document.getElementsByClassName('cht-virtualizedList')[0];
				tt.scrollTo(0, tt.scrollHeight);
			}, 600);
		}
		if (this.firstMessageDate > nowFirstMessageDate) {
			let dateIndex = nowMessages.findIndex(m => (_.get(m, 'date') == this.firstMessageDate));
			if (dateIndex < 0)
				dateIndex = 0;
			this.firstMessageDate = nowFirstMessageDate;
			cache.clearAll();
			recomputeList();
			setTimeout(()=>{
				scrollList(dateIndex)
			}, 500);
		}
	}

	componentDidMount() {
		const recomputeList = this.recomputeListRowHeights.bind(this);
		const scrollList = this.scrollListToRow.bind(this);
		let tt  = document.getElementsByClassName('cht-virtualizedList')[0];
		setTimeout(() => {
			const nowMessages = _.get(this.props, 'currentChat.messages');
			scrollList(nowMessages.length);
			setTimeout(() => {
				tt.scrollTo(0, tt.scrollHeight);
				this.begin = false;
			}, 1);
		}, 0);
		setTimeout(recomputeList, 300);
		Bus.when('check_for_past_messages', () => {
			cache.clearAll();
			recomputeList();
		});
	}

	handleScroll = (e) => {
		if (e.scrollTop == 0 && !this.begin) {
			Bus.cast('check_for_past_messages');
		}
	}

	listRef = React.createRef();

	render() {
		const {user} = this.props;
		const currentChat = _.get(this.props, 'currentChat');
		const messages = _.get(currentChat, 'messages', []);
		const conv = _.get(currentChat, 'conv', 'student');
		return (
			
			<div className="cht-main relw53 flex fdc">
				{
					user.type == 'teacher' && _.get(currentChat, 'thereIsParent') &&
					<div className="cht-changeConv light" onClick={Bus.fcast('switch_conv')}>
						{conv == 'student' ? 'Écrire au parent' : 'Écrire à ton élève'}
						&nbsp;<FontAwesomeIcon icon={faExchangeAlt} size='xs'/>
					</div>
				}
				{
					user.type == 'parent' &&
					<div className="cht-changeConv light" onClick={Bus.fcast('switch_conv')}>
						{conv == 'student' ? 'Ecrire au Sherpa' : 'Voir la discussion avec votre enfant'}
						&nbsp;<FontAwesomeIcon icon={faExchangeAlt} size='xs'/>
					</div>
				}
				<div id="cht-mainMessages" className="cht-mainMessages relw100 relh100 flex fdc">
					<div style={{ flex: '1 1 auto' }}>
						<AutoSizer>
							{
								({width, height}) => (
									<List
										ref={this.listRef}
										width={width}
										height={height}
										className='cht-virtualizedList'
										rowCount={messages.length}
										deferredMeasurementCache={cache}
										rowHeight={cache.rowHeight}
										rowRenderer={rowRenderer.bind(this)}
										onScroll={this.handleScroll.bind(this)}
									/>
								)
							}
						</AutoSizer>
					</div>
				</div>
				{currentChat && <MessageBar currentChat={currentChat}/>}
			</div>
		)
	}
};
export default Chat_Main;