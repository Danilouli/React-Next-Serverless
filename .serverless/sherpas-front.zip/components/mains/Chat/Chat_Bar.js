import {useContext, useState, useEffect} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import SmallLegend from "/components/misc/SmallLegend/SmallLegend.js"
import GreenButton from "/components/misc/GreenButton/GreenButton.js";
import ClassicButton from "/components/misc/ClassicButton/ClassicButton.js"
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import Bus from '/static/tools/bus.js';
import {faCalendarAlt, faVideo, faStopwatch, faFileDownload, faTrashAlt} from '@fortawesome/free-solid-svg-icons';
import _ from 'lodash';
import {DEFAULTIMG} from '/static/tools/tools.js';

const Chat_Bar = props => {
	const context = useContext(WebsiteContext);
	let {currentChat} = props; 
	if (!currentChat)
		currentChat = {};
	const {user} = context;
	const workspace = _.get(currentChat, 'workspace');
	console.log('workspace', workspace);
	const isTrial = _.get(workspace, 'trialTime', 0) > 0;
	const interlocutor = _.get(currentChat, 'interlocutor');
	const studentHasStripe = _.get(workspace, 'student.hasStripe') || _.get(workspace, 'parent.hasStripe');
	console.log('interlocutor', interlocutor);
	const hasStripe = (user.type == 'teacher') ? (studentHasStripe || !!_.get(interlocutor, 'data.hasStripe')) : !!_.get(user, 'devInfos.stripeCustomerId');
	const [legend, showLegend] = useState(_.get(user, 'workspaces.length', 0) <= 1 || (!hasStripe && user.type == 'student'));
	const files = _.get(currentChat, 'messages', []).filter(m => !!_.get(m, 'file.url'));
	const interlocConn = _.get(interlocutor, 'connected');
	const buttonStatus = {
		reminder : !isTrial && !(interlocConn && hasStripe),
		trialReminder : isTrial && !(interlocConn && hasStripe),
		launchCourse : !isTrial && (hasStripe && interlocConn),
		launchTrial : isTrial && (hasStripe && interlocConn),
		// launchCourseProhibited : interlocConn && !isTrial && !hasStripe,
		// launchTrialProhibited : interlocConn && isTrial && !hasStripe,
		// reminderProhibited : !isTrial && !hasStripe && !interlocConn,
	}
	console.log('buttonstatus', buttonStatus);
	console.log()
	useEffect(() => {
		const cb = () => showLegend(false);
		Bus.when('clicked_on_textarea', cb);
		return function cleanup() {
			Bus.stop('clicked_on_textarea', cb);
		};
	});
	return (
		<div className="cht-bar relw18 flex fdc mart20 bsbb padh30" onMouseEnter={()=>showLegend(true)} onMouseLeave={()=>showLegend(false)}>
			<div className="cht-barHead relw100 flex fdr aic mart30">
				<div className="cht-barImage square60 brad_circle">
					<img className='sage_image' src={_.get(currentChat, 'picture', DEFAULTIMG)}/>
				</div>
				<div className="flex fdc aic marl10">
					<p className="big_text camphor black bold">&nbsp; {_.get(interlocutor, 'name', '')}</p>
					<div className="flex fdr aic">
						<div className={`brad_circle square10 ${interlocConn ? 'bggreen' : 'bggrey'}`}></div>&nbsp;
						{
							interlocConn ?
							"En ligne" : "Hors ligne"
						}
					</div>
				</div>
			</div>
			{
				buttonStatus.launchCourse &&
				<div className="cht-barButton relw100 marv30">
					<ClassicButton linkTo={`/workspace?workspace=${workspace._id}`} linkToAs={`/workspace/${workspace._id}`} className='relw100'>Démarrer un cours</ClassicButton>
				</div>
			}
			{
				buttonStatus.launchTrial &&
				<div className="cht-barButton relw100 marv30">
					<ClassicButton linkTo={`/workspace?workspace=${workspace._id}`} linkToAs={`/workspace/${workspace._id}`} className='relw100'>Lancer le RDV</ClassicButton>
				</div>
			}
			{
				buttonStatus.trialReminder &&
				<div className="cht-barButton relw100 marv30" onClick={Bus.fcast('show_meeting_modal')}>
					{
						legend && user.type != 'teacher' &&
						<SmallLegend>
							<span className='cht-trialLegend small_text flex aic fdc jcc cwhite bsbb padh20'>
								<span className='marv10'>
									Il ne vous reste plus qu’à <a href='#' onClick={Bus.fcast('show_meeting_modal')}>proposer un créneau</a> pour votre RDV gratuit de 20min.
								</span>
								{!hasStripe && <span className='marv10'>Pour confirmer le sérieux de votre demande nous vous demanderons votre CB. Elle ne sera pas débitée.</span>}
							</span>
						</SmallLegend>
					}
					<ClassicButton className='relw100 fs12' type='action'><FontAwesomeIcon icon={faCalendarAlt}/>&nbsp;Proposer un RDV Gratuit</ClassicButton>
				</div>
			}
			{
				buttonStatus.reminder &&
				<div className="cht-barButton relw100 marv30" onClick={Bus.fcast('show_meeting_modal')}>
					{
						legend && user.type != 'teacher' && !hasStripe &&
						<SmallLegend>
							<span className='cht-trialLegend small_text flex aic fdc jcc cwhite bsbb padh20'>			
								 <span className='marv10'>Pour confirmer le sérieux de votre demande nous <a href='#' onClick={Bus.fcast('show_card_modal')}>vous demandons votre CB</a>. Elle ne sera pas débitée.</span>
							</span>
						</SmallLegend>
					}
					<ClassicButton className='relw100 fs12' type='action'><FontAwesomeIcon icon={faCalendarAlt}/>&nbsp;Réserver un cours</ClassicButton>
				</div>
			}
			{
				!isTrial && 
				<div className='relw100 flex fdc'>
					<a href='#' className="cht-barOption" onClick={Bus.fcast('show_meeting_modal')}><span><FontAwesomeIcon icon={faCalendarAlt}/></span>Proposer une date de cours</a>
					{/* <a href='#' className="cht-barOption"><span><FontAwesomeIcon icon={faStopwatch}/></span>Prochaines sessions prévues</a> */}
					{/* <a href='#' className="cht-barOption"><span><FontAwesomeIcon icon={faVideo}/></span>Revoir une session passée</a> */}
					<div className="cht-barFiles">
						<p className="cht-barFilesTitle mini_text mart30 cgrey marb20">Fichiers partagés</p>
						<div className="cht-barFilesFiles">
							{
								files.map((m,i) => {
									let f = m.file;
									return (
										<div className="cht-barFile mart20 flex fdr jcsb" key={i}>
											<div className="flex fdc">
												<p className="mini_text cht-barFileTitle">{f.name.substring(0, 10) || 'Document'}</p>
												{/* <p className='mini_text cht-barFileDate cgrey light'>Il y a 5 jours</p> */}
											</div>
											<a href={f.url} target="_blank">
												<span className='cgrey'><FontAwesomeIcon icon={faFileDownload}/></span>
											</a>
										</div>
									)
								})
							}
						</div>
					</div>
				</div>
			}
			{/* <div className="cht-deleteWorkspace cred mini_text" onClick={Bus.fcast('show_delete_workspace_modal')}><span><FontAwesomeIcon icon={faTrashAlt} size='xs'/></span>
				&nbsp; Supprimer cet espace de travail
			</div> */}
		</div>
	)
};
export default Chat_Bar;