import './Chat.scss';
import Chat_List from './Chat_List.js';
import Chat_Main from './Chat_Main.js';
import Chat_Bar from './Chat_Bar.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {openModal} from '/components/misc/ClassicModal/ClassicModal.js';
import {openNotification, closeNotification, ClassicNotification} from '/components/misc/ClassicNotification/ClassicNotification.js';
import CardModal from "/components/misc/CardModal/CardModal.js";
import BigMeetingModal from "/components/misc/BigMeetingModal/BigMeetingModal.js";
import SmallMeetingModal from "/components/misc/SmallMeetingModal/SmallMeetingModal.js";
import Bus from '/static/tools/bus.js';
import {initWorkspaceSocket, initNotificationsSocket, api} from '/static/tools/network.js';
import _ from 'lodash';
import {concatMessages, DEFAULTIMG} from '/static/tools/tools.js';
import {isChrome} from '/static/tools/misc.js'; 
import {getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';
 
class Chat extends React.Component {
	static contextType = WebsiteContext;
	constructor(props, context) {
		super(props, context);
		const {user} = context;
		this.user = user;
		const chatInfos = {};
		let chatsToHave = [user.type];
		let notifSocket = initNotificationsSocket(this.context.auth);
		let sockets = [];
		if (user.type != 'student')
			chatsToHave = ['student','parent'];
		for (let w of _.get(user, 'workspaces', [])) {
			let socket = initWorkspaceSocket(w._id, this.context.auth);
			sockets.push(socket);
			for (let c of chatsToHave) {
				let thereIsParent = !!_.get(w, 'parent.ref_id') ;
				if (!w._id || (!thereIsParent && c == 'parent'))
					continue;
				const chatId = `_wks_${w._id}_${c}`;
				let toAdd = {
					conv : c,
					chatId,
					messages : concatMessages(w.chats[c]) || [],
					workspaceName : w.name,
					workspace : w,
					currentMessage : '',
					readOnly : (c == 'student' && user.type == 'parent'),
					socket,
					interlocutor : {
						connected : false,
						type : (user.type == 'teacher') ? c : 'teacher'
					},
					thereIsParent
				};
				console.log('w', w);
				if (user.type == 'teacher') {
					toAdd.interlocutor.name = (c == 'parent') ? `Parent de ${_.get(w, 'student.fname')}` : `${_.get(w, 'student.fname')}`;
					toAdd.name = (c == 'parent') ? 
					`Parent de ${_.get(w, 'student.fname')}` :
					`${_.get(w, 'student.fname')} ${_.get(w, 'student.studentInfos.level') ? `| ${_.get(w, 'student.studentInfos.level')}` : ''}`;
					toAdd.picture = `${_.get(w, 'student.profile.picture', DEFAULTIMG)}`;
				}
				else {
					toAdd.interlocutor.name = `${_.get(w, 'teacher.fname')}`;
					toAdd.name = `${_.get(w, 'teacher.fname')} ${_.get(w, 'teacher.teacherInfos.institution') ? `| ${_.get(w, 'teacher.teacherInfos.institution', '').split(',')[0]}` : ''}`;
					toAdd.picture = `${_.get(w, 'teacher.profile.picture', DEFAULTIMG)}`;
				}
				chatInfos[chatId] = toAdd;
			}
		}
		let currentChatId = Object.keys(chatInfos)[0];
		if (user.type == 'parent')
			currentChatId = Object.keys(chatInfos).find(k => chatInfos[k].conv == 'parent');
		if (context.chatId) {
			console.log('context chatId', context.chatId);
			let newCurrentChatId = Object.keys(chatInfos).find(k => k == context.chatId);
			if (newCurrentChatId)
				currentChatId = newCurrentChatId;
		}
		this.state = {
			chats : chatInfos,
			currentChatId,
			notifSocket
		}
	}

	checkForNewMessages = () => {
		for (let chatId in this.state.chats) {
			let c = this.state.chats[chatId];
			api.post(
				'tck_workspaces/get_messages_between',
				{
					chatId : c.chatId, after : _.get(c.messages, `${c.messages.length - 1}.date`, Date.now() - 1) + 1,
					auth : this.context.auth
				}
			)
			.then(newMessages => {
				this.setState(state => {
					c.messages = concatMessages(c.messages, newMessages);
					return state;
				})
			});
		};
	};

	checkForPastMessagesForCurrentChat = () => {
		let c = this.state.chats[this.state.currentChatId];
		api.post(
			'tck_workspaces/get_messages_between', {
				chatId : c.chatId, before : _.get(c.messages, `0.date`, Date.now() - 1) + 1,
				auth : this.context.auth
			}
		)
		.then(pastMessages => {
			let {chats} = this.state;
			chats[c.chatId].messages =  concatMessages(c.messages, pastMessages);
		});
	};

	getCurrentWorkspace() {
		return this.state.chats[this.state.currentChatId].workspace;
	}

	initializeChatSocket(chat) {
		let {socket} = chat;
		if (!socket)
			return;
		const newMessageOrFile = data => {
			const {chatId} = data;
			if (chatId != chat.chatId)
				return;
			this.setState(state => {
				state.chats[chat.chatId].messages = concatMessages(chat.messages, [data]);
				return state;
			});
		};
		socket.on('ser_stripe_set', this.context.refetchAll);
		socket.on('ser_new_message', newMessageOrFile);
		socket.on('ser_new_file', newMessageOrFile);
		socket.on('ser_wks_ready', (data) => {
			const {connected} = data;
			console.log('connected', connected);
			const userConnData = connected.connectedUsers.find(e => e.type == chat.interlocutor.type);
			if (userConnData) {
				this.setState(state => {
					state.chats[chat.chatId].interlocutor.connected = true;
					state.chats[chat.chatId].interlocutor.data = userConnData;
					return state;
				});
			}
		});
		socket.on('ser_user_disconnected', user => {
			const {type} = user;
			if (type == chat.interlocutor.type) {
				this.setState(state => {
					state.chats[chat.chatId].interlocutor.connected = false;
					return state;
				});
			}
		});
		socket.on('ser_user_connected', user => {
			const {type} = user;
			if (type == chat.interlocutor.type) {
				this.setState(state => {
					state.chats[chat.chatId].interlocutor.connected = true;
					return state;
				});
			}
		});
	}

	initializeNotifsSocket() {
		const {user} = this.context;
		this.state.notifSocket.on('ser_new_notification', e => {
			console.log('new NOTIF', e);
			try {
				let {event, data} = e;
				if (event == 'new_reminder') {
					let {workspace, whoInitiated} = data;
					let completeWorkspace = user.workspaces.find(c => c.ref_id == workspace.ref_id);
					let isTrial = _.get(completeWorkspace, 'trialTime', 0) > 0;
					openModal(<SmallMeetingModal title={`Proposition de ${isTrial ? "RDV Pédagogique" : "RDV de cours"} de ${completeWorkspace[whoInitiated].fname}`} className='cht-stillMeetingModal' reminder={data} user={user} workspace={completeWorkspace} meetWho={whoInitiated}/>)
				}
			}
			catch (err) {
				console.error('Error to show notif', e, err);
			}
		});
		console.log('INITIALI NOTIF SOCK');
	}

	componentDidUpdate() {
		// const {user} = this.context;
		// const hasCard = !!_.get(user, 'devInfos.stripeCustomerId');
		// if (hasCard || user.type == 'teacher') {
		// 	closeNotification();
		// }
	}

	cardSuccessHandler() {
		this.context.refetchAll(() => {
			Bus.cast('show_meeting_modal');
			const currentChat = _.get(this, 'state.chats[this.state.currentChatId]');
			if (currentChat) {
				let {socket} = currentChat;
				socket.emit("cli_stripe_set");
			}
		});
	}

	componentDidMount() {
		let chromus = isChrome();
		if (!chromus) {
			getAlert(
				<div>
					<p>La plateforme de cours et la messagerie ne sont pas actuellement entièrement compatibles avec votre navigateur.</p>
					<br></br>
					<p>Utilisez une version récente de Google Chrome pour un fonctionnement optimal</p>
				</div>
			);
		}
		const user = this.context.user;
		const hasCard = !!_.get(user, 'devInfos.stripeCustomerId');
		if (!hasCard && user.type != 'teacher')
			openNotification(
				<ClassicNotification
					content={<span className='cblack'>Pour avoir cours, assurez votre Sherpa du sérieux de votre demande : <a href='#' onClick={Bus.fcast('show_card_modal')}>Ajoutez une Carte Bancaire</a>. Les RDV pédagogiques sont gratuits : votre carte ne sera pas débitée</span>}
					close={false}
				/>
			)
		Bus.when('context_refetched_all', async () => {
			const {user} = this.context;
			const hasCard = !!_.get(user, 'devInfos.stripeCustomerId');
			if (hasCard || user.type == 'teacher')
				closeNotification();
		});
		Bus.when('show_card_modal', () => openModal(
			<CardModal
				className='cht-cardModal'
				userId={user._id}
				onSuccess={this.cardSuccessHandler.bind(this)}
			/>
		));
		Bus.when('show_meeting_modal', () => {
			const {user} = this.context;
			const wks = this.getCurrentWorkspace();
			const isTrial = wks.trialTime && wks.trialTime > 0;
			api.post('tck_reminders/find', {
				auth : {
					loginCookie : user._id,
					cookey : _.get(user, 'devInfos.cookey')
				},
				query : {
					'workspace.ref_id' : `wks_${wks._id}`,
					"acceptation.status" : {$ne : 'canceled'}
				}
			})
			.then(suc => {
				console.log('suc', suc);
				const currentChat = this.state.chats[this.state.currentChatId];
				console.log('user up', user, this.user);
				if (!!_.get(suc, '_id')) {
					let preTitle = isTrial ? "Proposition de RDV Pédagogique" : "Proposition de RDV";
					openModal(<SmallMeetingModal title={`${preTitle} avec ${currentChat.interlocutor.name}`} className='cht-stillMeetingModal' reminder={suc} user={user} workspace={currentChat.workspace} meetWho={currentChat.conv}/>)
				}
				else
					openModal(<BigMeetingModal className='cht-meetingModal' user={user} workspace={currentChat.workspace} meetWho={currentChat.conv}/>)
			})
			.catch(console.error);		
		});
		Bus.when('switch_conv', () => {
			let {currentChatId} = this.state;
			let currentChat = this.state.chats[currentChatId];
			let alterChatId = currentChat.conv == 'parent' ? currentChatId.replace('parent', 'student') : currentChatId.replace('student', 'parent');
			if (alterChatId) {
				this.setState ({
					currentChatId : alterChatId
				})
			}
		});
		Bus.when('check_for_past_messages', this.checkForPastMessagesForCurrentChat.bind(this));
		Bus.when('check_for_new_messages', this.checkForNewMessages.bind(this));
		for (let c in this.state.chats) {
			this.initializeChatSocket.bind(this)(this.state.chats[c]);
			this.state.chats[c].socket.connect();
		}
		this.initializeNotifsSocket.bind(this)();
		this.state.notifSocket.connect();
	}

	render() {
		return (
			<div className="Chat relw100 flex jcse">
				<Chat_List parent={this}/>
				<Chat_Main currentChat={this.state.chats[this.state.currentChatId]} user={this.context.user}/>
				<Chat_Bar currentChat={this.state.chats[this.state.currentChatId]}/>
			</div>
		)
	}
};
export default Chat;