import {useContext, useState} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import _ from 'lodash';

const Chat = props => {
	return (
		<div
			className="cht-listElt relw96 flex fdr aic marb15 brad_light"
			active={`${props.active}`}
			onClick={props.onClick}
		>
			<div className="square40 brad_circle marh20"><img src={props.chat.picture} className="sage_image badge_image"/></div>
			<div className="flex fdc">
				<p className='small_text'>{props.chat.name}</p>
				<p className='mini_text'>{props.chat.workspaceName}</p>
			</div>
		</div>
	)
};

const Chat_List = props => {
	const parent = props.parent;
	return (
		<div className="cht-list relw23 flex fdc mart20">
			<div className="relw100 flex fdc aic cht-chatList">
				{
					Object.keys(parent.state.chats).filter(e => !parent.state.chats[e].readOnly).map(c => (
						<Chat
							key={c}
							chat={parent.state.chats[c]}
							active={parent.state.currentChatId == c}
							onClick={() => parent.setState({currentChatId : c})}
						/>
					))
				}
			</div>
		</div>
	)
};
export default Chat_List;