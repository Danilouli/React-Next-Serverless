import './Gallery.scss';
import Gallery_SearchBar from './Gallery_SearchBar';
import MaterialSlider from '/components/misc/MaterialSlider/MaterialSlider.js';
import _ from 'lodash';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import TeachersList from '/components/misc/TeachersList/TeachersList.js';
import MaterialCheckboxes from '/components/misc/MaterialCheckboxes/MaterialCheckboxes.js';
import {api} from '/static/tools/network.js';

class Gallery extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			filters : {
				subjects : ['maths'],
				level : 'lycee',
				sex : {$in : ['male','female',null]},
				priceMax : 5000,
				priceMin : 0
			},
			teachers : [],
			titleSubject : 'Mathématiques'
		}
	}

	searchTeachers() {
		let toSend = this.state.filters;
		if (!toSend.level || toSend.level == 'placeholder')
			toSend.level = 'lycee';
		api.post('public/teachers/search', toSend)
		.then(suc => {
			this.setState({teachers : suc});
		});
		localStorage.setItem("shr_keep_gallery_subject", _.get(this, 'state.filters.subjects[0]', 'maths'));
		localStorage.setItem("shr_keep_gallery_level", _.get(this, 'state.filters.level', 'lycee'));
	}

	componentDidUpdate(prevProps, prevState) {
		if (!_.isEqual(prevState.filters, this.state.filters)) {
			this.searchTeachers();
		}
	}

	componentDidMount() {
		this.searchTeachers();
	}

	updatePriceMax(value) {
		let filters = this.state.filters;
		filters.priceMax = parseInt(value)*100;
		this.setState({filters}, this.searchTeachers);
	}

	updateSex(value) {
		let filters = this.state.filters;
		filters.sex['$in'] = (Object.keys(value).filter(s => !!value[s]));
		filters.sex['$in'].push(null);
		this.setState({filters}, this.searchTeachers);
	}

	static contextType = WebsiteContext;

	render() {
		return (
			<div className='Gallery'>
				<div className='gal-header mob__padh0 flex mob__aic mob__relw100'>
					{
						!!this.state.titleSubject && <h1 className='mob__txtac'>Cours particuliers de <span className='gal-subject'>{this.state.titleSubject}</span> en ligne</h1>
					}
					<p className='mob__txtac'>Trouvez le Sherpa idéal et programmez un rendez-vous gratuit.</p>
				</div>
				<div className='gal-searchBar'>
					<Gallery_SearchBar gallery={this}/>
				</div>
				<div className='large_flex_container'>
					<div className='gal-subPart'>
						<div className='gal-moreSearchData mob__hide'>
							<div className='gal-priceSlider'>
								<div className='marb50'>Prix maximum à l'heure</div>
								<MaterialSlider
									onValueChanged={this.updatePriceMax.bind(this)}
									getAriaValueText={
										value => `${value}€`
									}
									valueLabelFormat={value => (value + '€')}
									step={5}
									min={20}
									max={50}
									defaultValue={50}
									marks={[
										{
											value: 20,
											label: '20€',
										},
										{
											value: 50,
											label: '50€',
										}
									]}
								/>
							</div>
							{/* <div className='gal-priceSlider'>
								<span>Âge min. du professeur</span>
								<MaterialSlider
									onValueChanged={value => value}
									getAriaValueText={value => value}
									valueLabelFormat={value => value}
									step={1}
									min={18}
									max={70}
									defaultValue={18}
									marks={[
										{
											value: 18,
											label: '18',
										},
										{
											value: 70,
											label: '70',
										}
									]}
								/>
							</div> */}
							<div className='gal-priceSlider'>
								<MaterialCheckboxes
									onValueChanged={this.updateSex.bind(this)}
									labels={[
										{value : 'male', name : 'Homme', default : true},
										{value : 'female', name : 'Femme', default : true}
									]}
									uniq={false}
								/>
							</div>
						</div>
						<div className="gal-teachersList">
							<TeachersList
								teachers={this.state.teachers}
								filters={this.state.filters}
							/>
						</div>
					</div>
				</div>
			</div>
		)
	}
};
export default Gallery;