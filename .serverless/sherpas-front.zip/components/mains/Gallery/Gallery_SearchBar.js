import {useContext} from 'react';
import TagInput from '/components/misc/TagInput/TagInput.js';
import MaterialSelect from '/components/misc/MaterialSelect/MaterialSelect.js'
import _ from 'lodash';
import WebsiteContext from '/components/contexts/WebsiteContext.js';

const Gallery_SearchBar = props => {
	const context = useContext(WebsiteContext);
	const {lang} = context;

	const updateSubjects = ({tags}) => {
		let subj0 = _.get(tags, '[0].text');
		let filters = Object.assign({} , _.get(props, 'gallery.state.filters'));
		filters.subjects = tags.filter(e => !e.custom).map(e => e.id);
		filters.custom = tags.filter(e => e.custom).map(e => e.text);
		props.gallery.setState({filters, titleSubject : subj0});
	}

	const updateSelect = e => {
		let filters = Object.assign({} , _.get(props, 'gallery.state.filters'));
		filters.level = e.target.value;
		props.gallery.setState({filters});
	}

	const {subjects} = lang;
	let subjectsSuggestions = subjects.map(s => ({
		id : s.value,
		text : s.name
	}));


	const levels = [
		{ value: 'lycee', name: 'Lycée' },
		{ value: 'college', name: 'Collège' },
		{ value: 'prepa', name: 'Classe préparatoire' }
	];
	//context.lang.levels;
	return (
		<div className='gal-searchBarContainer'>
			<TagInput
				placeholder='Matière(s) : essayer Mathématiques, Histoire...'
				maxNumber={3}
				onChangeTags={updateSubjects}
				suggestions={subjectsSuggestions}
			/>
			<div className='gal-levelSelect'>
				<MaterialSelect
					placeholder='Niveau'
					selectedValue={_.get(props, 'gallery.state.filters.level')}
					onChange={updateSelect}
					items={levels}
				/>
			</div>
		</div>
	)
};
export default Gallery_SearchBar;