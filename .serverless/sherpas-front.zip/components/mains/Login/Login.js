import LoginModal from "/components/misc/LoginModal/LoginModal.js"

const Login = props => (
	<div className="Login relw100 flex aic jcc relh100">
		<LoginModal/>
	</div>
);
export default Login;