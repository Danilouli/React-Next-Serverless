import './ToggableVideo.scss';
import _ from 'lodash';
import Bus from '/static/tools/bus.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faExpand, faCompress, faVideoSlash, faVideo, faMicrophoneSlash, faMicrophone, faChevronRight} from '@fortawesome/free-solid-svg-icons';
import { connect, createLocalTracks } from 'twilio-video';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import ReactDOM from 'react-dom';

const toggleMicrophone = () => {
	Bus.cast('toggle_microphone');
}

const toggleCamera = () => {
	Bus.cast('toggle_camera');
}

const expandVideo = () => {
	Bus.cast('expand_video');
}

const compressVideo = () => {
	Bus.cast('compress_video');
}

class ToggableVideo extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			toggled : false,
			cameraActive : true,
			microphoneActive : true,
			expanded : false
		};
	}

	static contextType = WebsiteContext;

	toggleHandler() {
		this.setState({
			toggled : !this.state.toggled
		});
	}

	componentDidMount() {
		Bus.when('expand_video', () => {
			this.setState({expanded : true});
		});
		Bus.when('compress_video', () => {
			this.setState({expanded : false});
		});
		let tokenTwilio = this.context.tokenTwilio;
		let roomName = `${this.context.room}`;
		if (tokenTwilio) {
			createLocalTracks({
				audio: true,
				video: { width: 640 }
			})
			.then(localTracks => {
				connect(tokenTwilio , {name : roomName})
				.then(
					room => {
						for (let track of localTracks) {
							document.getElementById('meVideo').appendChild(track.attach());
							if (track.kind == 'video') {
								const toggleCameraHandler = () => {
									this.setState({
										cameraActive : !this.state.cameraActive
									}, () => {
										if (this.state.cameraActive) {
											track.enable();
											room.localParticipant.publishTrack(track);
										}
										else {
											track.disable();	
											room.localParticipant.videoTracks.forEach(videoTrack => {
												videoTrack.unpublish();
											});
										}
									})
								};
								Bus.when('toggle_camera', toggleCameraHandler);
							}
							if (track.kind == 'audio') {
								const toggleMicrophoneHandler = () => {
									this.setState({
										microphoneActive : !this.state.microphoneActive
									}, () => {
										if (this.state.microphoneActive) {
											track.enable();
											room.localParticipant.publishTrack(track);
										}
										else {
											track.disable();
											room.localParticipant.audioTracks.forEach(audioTrack => {
												audioTrack.unpublish();
											});
										}
									})
								};
								Bus.when('toggle_microphone', toggleMicrophoneHandler);
							}
						}
						room.participants.forEach(participant => {
							participant.tracks.forEach(publication => {
								if (publication.isSubscribed) {
									const track = publication.track;
									document.getElementById('remoteVideo').appendChild(track.attach());
								}	
							});
							participant.on('trackSubscribed', track => {
								document.getElementById('remoteVideo').appendChild(track.attach());
							});
						});						  
						room.on('participantConnected', participant => {
							participant.tracks.forEach(publication => {
								if (publication.isSubscribed) {
									const track = publication.track;
									document.getElementById('remoteVideo').appendChild(track.attach());
								}	
							});
							participant.on('trackSubscribed', track => {
								document.getElementById('remoteVideo').appendChild(track.attach());
							});							
						});
						Bus.when("leave_course", () => {
							if (!!room)
								room.disconnect();
						});
					},
					error => {
						console.error(`Unable to connect to Room: ${error.message}`);
					}
				);	
			});	 
		}
	}

	render() {
		return (
			<div className={'ToggableVideo ' + this.props.className} toggled={`${this.state.toggled}`} expanded={`${!this.state.toggled && this.state.expanded}`}>
				<div className='videoViewers'>
					<VideoViewer me={false} expanded={this.state.expanded}></VideoViewer>
					<VideoViewer me={true} miniature={this.state.expanded} cameraActive={this.state.cameraActive} microphoneActive={this.state.microphoneActive}></VideoViewer>
				</div>
				<VideoToggle toggled={this.state.toggled} onClick={this.toggleHandler.bind(this)}/>
			</div>
		)
	}
};
export {ToggableVideo};

const VideoViewer = props => {
	let videoId = `${props.me ? 'me' : 'remote'}Video`;
	if (!!props.expanded)
		videoId += 'Expanded';
	if (!!props.miniature)
		videoId += 'Miniature';
	return (
		<div className='videoElementContainer' expanded={`${!!props.expanded}`} miniature={`${!!props.miniature}`}>
			<div className='videoContainer' id={videoId}>
			</div>
			<VideoOptions expanded={props.expanded} me={props.me} cameraActive={props.cameraActive} microphoneActive={props.microphoneActive}/>
		</div>
	)
};

const VideoOptions = props => (
	<div className='VideoOptions'>
		{
			!props.me ? 
			(
				<span>
					{
						!props.expanded ?
						<span className='videoIcon'>
							<FontAwesomeIcon icon={faExpand} onClick={expandVideo}/>
						</span> :
						<span className='videoIcon'>
							<FontAwesomeIcon icon={faCompress} onClick={compressVideo}/>
						</span> 
					}
				</span>
			) :
			(
				<span>
					<span onClick={toggleCamera} className='videoIcon' active={`${!!props.cameraActive}`}>
						{
							!!props.cameraActive ? 
							<FontAwesomeIcon icon={faVideo}/> :
							<FontAwesomeIcon icon={faVideoSlash}/>
						}
					</span>
					<span onClick={toggleMicrophone} className='videoIcon' active={`${!!props.microphoneActive}`}>
						{
							!!props.microphoneActive ? 
							<FontAwesomeIcon icon={faMicrophone}/> :
							<FontAwesomeIcon icon={faMicrophoneSlash}/>
						}
					</span>
				</span>
			)
		}
	</div>
);

const VideoToggle = props => (
	<div className='VideoToggle' onClick={props.onClick} toggled={`${props.toggled}`}>
		<span>
			<FontAwesomeIcon icon={faChevronRight}/>
		</span>
	</div>
)

const expandLargeVideo = (jsxElt, callback) => {
	let body = document.querySelector('body');
	let containerJsx =
		<div id='modalus' style={{height : '100%', width : '100%', position : 'relative'}}>{jsxElt}</div>;
	let newDiv = document.createElement('div');
	newDiv.style = "position : absolute; width : 100vw; height : 100vh; background-color : transparent; z-index : 300; top : 0; display : flex; justify-content : center; align-items : center;";
	newDiv.id = 'modalus-conat';
	ReactDOM.render(containerJsx, newDiv, () => {
		body.appendChild(newDiv);
		callback();
	});
}

const closeLargeVideo = () => {
	ReactDOM.unmountComponentAtNode(document.getElementById('modalus-conat'));
	document.getElementById('modalus-conat').remove();
}
