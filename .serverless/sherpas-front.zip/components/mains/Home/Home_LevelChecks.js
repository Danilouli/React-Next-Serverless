import {useContext} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import LevelChecks from '/components/misc/LevelChecks/LevelChecks.js';
import _ from 'lodash';

const Home_LevelChecks = props => {
	const ctx = useContext(WebsiteContext);
	const {user} = ctx;
	return (
		<div className="hm-levelChecks relw100 marv20 flex jcsa">
			<div className="relw35">
				<LevelChecks/>
			</div>
			<div className="relw35">
				<LevelChecks/>
			</div>
		</div>
	)
};
export default Home_LevelChecks;