import WebsiteContext from '/components/contexts/WebsiteContext.js';
import PanelsToggler from '/components/misc/PanelsToggler/PanelsToggler.js';
import Home_Workspaces from './Home_Workspaces.js';
import Home_LevelChecks from './Home_LevelChecks.js';
import _ from 'lodash';
import './Home.scss';
import WavyCTA from '/components/misc/WavyCTA/WavyCTA.js';
import NeedHelp from '/components/misc/NeedHelp/NeedHelp.js';
import Bus from '/static/tools/bus.js';
import SmallMeeting from "/components/misc/SmallMeeting/SmallMeeting.js";
import BigMeetingModal from "/components/misc/BigMeetingModal/BigMeetingModal.js";
import SmallMeetingModal from "/components/misc/SmallMeetingModal/SmallMeetingModal.js";
import {openModal} from '/components/misc/ClassicModal/ClassicModal.js';
import CardModal from "/components/misc/CardModal/CardModal.js";
import {api} from '/static/tools/network.js';
import {isChrome} from '/static/tools/misc.js'; 
import {getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';

class Home extends React.Component {
	constructor(props) {
		super(props);
	}

	static contextType = WebsiteContext;

	cardSuccessHandler(detail) {
		this.context.refetchAll(Bus.fcast('show_meeting_modal', detail));
	}

	showMeetingModalHandler(data) {
		const detail = {data};
		if (!detail)
			return;
		const {user} = this.context;
		const {workspace, other, title} = data.detail;
		const wks = workspace;
		const isTrial = wks.trialTime && wks.trialTime > 0;
		if (isTrial) {
			api.post('tck_reminders/find', {
				auth : {
					loginCookie : user._id,
					cookey : _.get(user, 'devInfos.cookey')
				},
				query : {
					'workspace.ref_id' : `wks_${wks._id}`,
					'acceptation.status' : {$ne : 'canceled'}
				}
			})
			.then(suc => {
				console.log('suc', suc);
				const alreadyTrialReminder = _.get(suc, '_id') && isTrial;
				if (alreadyTrialReminder)
					openModal(
						<SmallMeetingModal
							title={`${title || "Proposition de RDV Pédagogique"} avec ${other.fname}`}
							className='hm-stillMeetingModal'
							reminder={suc}
							user={user}
							workspace={workspace}
							meetWho={other.type}
						/>
					)
				else
					openModal(
						<BigMeetingModal
							className='hm-meetingModal'
							user={user}
							workspace={workspace}
							meetWho={other.type}
						/>
					)
			});	
		}
		else {
			openModal(
				<BigMeetingModal
					className='hm-meetingModal'
					user={user}
					workspace={workspace}
					meetWho={other.type}
				/>
			)
		}
	};

	componentDidMount() {
		let chromus = isChrome();
		if (!chromus) {
			getAlert(
				<div>
					<p>La plateforme de cours et la messagerie ne sont pas actuellement entièrement compatibles avec votre navigateur.</p>
					<br></br>
					<p>Utilisez une version récente de Google Chrome pour un fonctionnement optimal</p>
				</div>
			);
		}
		const {user} = this.context;
		this.cb2 = Bus.when('show_card_modal', (data) => openModal(
			<CardModal
				className='hm-cardModal'
				userId={user._id}
				onSuccess={() => this.cardSuccessHandler.bind(this)(data.detail)}
			/>
		));
		this.cb1 = Bus.when('show_meeting_modal', (data) => {
			const detail = {data};
			if (!detail)
				return;
			const {user} = this.context;
			const {workspace, other, title} = data.detail;
			const wks = workspace;
			const isTrial = wks.trialTime && wks.trialTime > 0;
			if (isTrial) {
				api.post('tck_reminders/find', {
					auth : {
						loginCookie : user._id,
						cookey : _.get(user, 'devInfos.cookey')
					},
					query : {
						'workspace.ref_id' : `wks_${wks._id}`,
						'acceptation.status' : {$ne : 'canceled'}
					}
				})
				.then(suc => {
					const alreadyTrialReminder = _.get(suc, '_id') && isTrial;
					if (alreadyTrialReminder)
						openModal(
							<SmallMeetingModal
								title={`${title || "Proposition de RDV Pédagogique"} avec ${other.fname}`}
								className='hm-stillMeetingModal'
								reminder={suc}
								user={user}
								workspace={workspace}
								meetWho={other.type}
							/>
						)
					else
						openModal(
							<BigMeetingModal
								className='hm-meetingModal'
								user={user}
								workspace={workspace}
								meetWho={other.type}
							/>
						)
				});	
			}
			else {
				openModal(
					<BigMeetingModal
						className='hm-meetingModal'
						user={user}
						workspace={workspace}
						meetWho={other.type}
					/>
				)
			}
		});
	}

	componentWillUnmount() {
		Bus.stop('show_meeting_modal', this.cb1);
		Bus.stop('show_card_modal', this.cb2);
	}

	render() {
		const {user, reminders} = this.context;
		const workspaces = _.get(user, 'workspaces', []);
		let panels;
		if (user.type == 'teacher') {
			panels = {
				students : {
					content : <Home_Workspaces workspaces={workspaces.filter(w => !w.archived)}/>,
					name : "Tes Élèves"
				},
				archived : {
					content : <Home_Workspaces workspaces={workspaces.filter(w => !!w.archived)}/>,
					name : "Anciens élève"
				}
			};
		}
		else {
			panels = {
				teachers : {
					content : <Home_Workspaces workspaces={workspaces}/>,
					name : "Vos Sherpas"
				},
				// recent : {
				// 	content : <Home_Workspaces workspaces={this.context.user.workspaces}/>,
				// 	name : "Vus Récemment"
				// },
				// favorites : {
				// 	content : <Home_Workspaces workspaces={this.context.user.workspaces}/>,
				// 	name : "Favoris"
				// }
			};
		}
		const orders = {
			// parent : ['general',/*'children','recommend',*/'payment',/*'notifications','security','test'*/],
			student : ['teachers', 'recent', 'favorites'],
			// teacher : ['general','prices','marketing','payment'/*,'certifications','disponibilities'*/,'tablet',/*'notifications'*/]
		};
		const adminPanels = {
			levelChecks : {
				content : <Home_LevelChecks/>,
				name : "Ton Niveau"
			}
		};
		let WavyCTAProps;
		if (user.type == 'teacher')
			WavyCTAProps = {
				title : "Tu veux plus d'élèves ? Diffuse ton annonce et suis nos conseils !",
				text : "Moins de temps d’attente, et seulement 5% de frais de service : que demande le peuple ?",
				button : "Diffuser mon annonce",
				buttonLink : "settings"
			}
		else
			WavyCTAProps = {
				title : "Besoin d'un autre Sherpa ?",
				text : "Vous allez trouver la perle rare ! Contactez-nous si vous souhaitez de l’aide dans votre choix.",
				button : "Trouver un professeur",
				buttonLink : "gallery"
			}
		return (
			<div className="Home flex relw100vw jcc aic bgbeige">
				<div className="hm-container mart65 padb150 flex fdc aic relw80">
					<div className="hm-title classic_h2 relw100">Bienvenue <span className='cgreen'>{user.fname} !</span></div>
					<div className="hm-main relw100 marv20 flex fdr jcsb">
						<div className="hm-panelParts relw64 flex fdc">
							<div className="hm-panelPart hm-square relw100 flex fdc aic">
								<p className='big_text padl30 padt20 asfs'>Sherpas</p>
								<PanelsToggler panels={panels}/>
								<div className="relw95 marv20">
									<WavyCTA {...WavyCTAProps}/>
								</div>
							</div>
							{/* {
								user.type == 'teacher' &&
								<div className="hm-panelPart hm-square relw100 flex fdc aic mart25">
									<p className='big_text padl30 padt20 asfs'>Admin</p>
									<PanelsToggler panels={adminPanels}/>
								</div>
							} */}
						</div>
						<div className="hm-widgets relw32 flex fdc">
							<div className="hm-help hm-square relw100 padt40 padb30 bsbb padh70">
								<NeedHelp/>
							</div>
							{
								!!_.get(reminders, 'length') &&
								<div className="hm-reminders hm-square relw100 mart40 padt20 padb30 bsbb padh30">
									<p className='big_text asfs'>Prochains Cours</p>
									{/* <a href="#" className='mini_text'>+ Proposer un nouveau cours</a> */}
									<div className="relw100 mart20">
										{
											reminders.map(r => (
												<div className="relw100 marb20" key={r._id}>
													<SmallMeeting reminder={r} workspace={workspaces.find(w=>w.ref_id == r.workspace.ref_id)} user={user}/>
												</div>
											))
										}
									</div>
								</div>
							}
						</div>
					</div>
				</div>
			</div>
		)
	}
};
export default Home;