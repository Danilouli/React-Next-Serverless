import {useContext} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import ClassicButton from "/components/misc/ClassicButton/ClassicButton.js"
import {DEFAULTIMG} from '/static/tools/tools.js';
import Bus from '/static/tools/bus.js';
import Link from 'next/link';
import _ from 'lodash';

const WorkspaceCard = props => {
	const ctx = useContext(WebsiteContext);
	const {user} = ctx;
	const {type} = user;
	const {workspace} = props;
	const otherType = (type == 'teacher') ? 'student' : 'teacher';
	const other = workspace[otherType];
	const isTrial = _.get(workspace, 'trialTime', 0) > 0;
	let wksInfo;
	if (isTrial) {
		if (type == 'teacher') {
			wksInfo = {
				title : "Propose un RDV Gratuit",
				content : `Tu auras 20 min pour convaincre ${_.get(other, 'fname', "ton élève")} de continuer avec toi !`
			}
		}
	};
	let chatType = user.type == 'teacher' ? 'student' : user.type;
	return (
		<Link href={`/chat?chatId=_wks_${workspace._id}_${chatType}`} as={`/chat/_wks_${workspace._id}_${chatType}`} passHref>
			<a>
				<div className="hm-workspaceCard relw100 flex fdr aic jcse padv20 boxs_light brad_normal mart20">
					<div className="hm-workspaceImage brad_circle">
						<img className="sage_image" src={_.get(other, 'profile.picture', DEFAULTIMG)}/>
					</div>
					<div className="hm-workspaceTitle relw27 flex fdc">
						<p className="small_text cblack">{other.fname}</p>
						<p className="mini_text cgrey">{workspace.name || "Mathématiques"}</p>
					</div>
					<div className="hm-workspaceInfo relw30 flex fdc">
						{
							wksInfo &&
							<div>
								<p className="small_text cblack">
									{wksInfo.title}
								</p>
								<p className="mini_text cgrey">
									{wksInfo.content}
								</p>
							</div>
						}
					</div>
					<div className="hm-workspaceButtons relw19 relh100 flex fdc">
						{
							!isTrial &&
							<ClassicButton type='success' className='marb5 fs10'>
								Rejoindre la Classe
							</ClassicButton>
						}
						<ClassicButton onClick={e => {
							e.preventDefault();
							Bus.cast('show_meeting_modal', {workspace, other});
						}} type={isTrial ? 'action' : 'blue'} className='fs10'>
							{
								(!isTrial) ? 
								(
									(type == 'teacher') ?
									"Proposer un cours" :
									"Réserver un cours"
								) :
								(
									(type == 'teacher') ?
									"Proposer un RDV Gratuit" :
									"Réserver un RDV Gratuit"
								)
							}
						</ClassicButton>
					</div>
				</div>
			</a>
		</Link>
	);
};

const Home_Workspaces = props => (
	<div className="hm-workspaces relw100 flex fdc padh15 bsbb">
		{
			props.workspaces.map(w => !!w._id && <WorkspaceCard workspace={w} key={w._id}/>)
		}
	</div>
);

export default Home_Workspaces;