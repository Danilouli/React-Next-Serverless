import Icon from '@material-ui/core/Icon';
import './WorkspaceNavbarButton.scss';

const WorkspaceNavbarButton = props => {
	return (
		<button className='WorkspaceNavbarButton' {...props}>
			<Icon>{props.icon}</Icon>
			<span className='buttonTitle'>{props.children}</span>
		</button>
	)
};
export default WorkspaceNavbarButton;