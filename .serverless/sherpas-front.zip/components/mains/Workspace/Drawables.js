import {Arrow, Circle, Line, Rect, Image, Text} from "react-konva";
import Bus from '/static/tools/bus.js';

let keyIncrement = 0;

const generateId = (prefix => (prefix+'_'+Date.now()+Math.floor((Math.random() + Math.random())*1000)));

const mouseDownOnShapeHandler = function(e) {
	if (Bus.trunk.Whiteboard.mode == 'eraser') {
		e.target.remove();
		Bus.cast('remove_shape', {id : this.id});
	}
};

const mouseOverOnShapeHandler = function(e) {
	if (Bus.trunk.Whiteboard.mode == 'eraser' && Bus.trunk.Whiteboard.mouseDown) {
		e.target.remove();
		Bus.cast('remove_shape', {id : this.id});
	}
};

class Drawable {
	constructor(params) {
		const {startX, startY, points} = params;
		this.startX = startX;
		this.startY = startY;
		this.points = points;
	}
	registerMovement(x, y) {
		this.x = x;
		this.y = y;
	}
};
export {Drawable};

class ArrowDrawable extends Drawable {
	constructor(params) {
		const {startX, startY, x, y, weight, color, id} = params;
		super(params);
		this.x = x || startX;
		this.y = y || startY;
		this.weight = weight;
		this.color = color;
		this.id = id || generateId('ArrowDrawable');
		this.type = 'ArrowDrawable';
	}
	render() {
		const points = [this.startX, this.startY, this.x, this.y]
		return (
			<Arrow
				points={points}
				fill={this.color}
				stroke={this.color}
				strokeWidth={this.weight}
				onMouseDown={mouseDownOnShapeHandler.bind(this)}
				onMouseOver={mouseOverOnShapeHandler.bind(this)}
				perfectDrawEnabled={false}
				type='ArrowDrawable'
				key={keyIncrement++}
			/>
		)
	}
};
export {ArrowDrawable};


class ImageDrawable extends Drawable {
	constructor(params) {
		const {startX, startY, image, imageSrc, id} = params;
		super(params);
		this.x = startX;
		this.y = startY;
		this.imageSrc = imageSrc || image.src;
		this.image = image;
		this.id = id || generateId('image');
		this.type = 'ImageDrawable';
	}

	render() {
		return (
			<Image
				x={this.x}
				y={this.y}
				image={this.image}
				onMouseDown={mouseDownOnShapeHandler.bind(this)}
				onMouseOver={mouseOverOnShapeHandler.bind(this)}
				perfectDrawEnabled={false}
				type='ImageDrawable'
				key={keyIncrement++}
			/>
		);
	}
};
export {ImageDrawable};

class LineDrawable extends Drawable {
	constructor(params) {
		const {startX, startY, x, y, weight, color, id} = params;
		super(params);
		this.x = x || startX;
		this.y = y || startY;
		this.weight = weight;
		this.color = color;
		this.id = id || generateId('LineDrawable');
		this.type = 'LineDrawable';
	}
	render() {
		const points = [this.startX, this.startY, this.x, this.y];
		return (
			<Line
				points={points}
				fill='black'
				stroke={this.color}
				strokeWidth={this.weight}
				onMouseDown={mouseDownOnShapeHandler.bind(this)}
				onMouseOver={mouseOverOnShapeHandler.bind(this)}
				perfectDrawEnabled={false}
				key={keyIncrement++}
			/>
		);
	}
};
export {LineDrawable};

class CircleDrawable extends Drawable {
	constructor(params) {
		const {startX, startY, x, y, weight, color, id} = params;
		super(params);
		this.x = x || startX;
		this.y = y || startY;
		this.weight = weight;
		this.color = color;
		this.id = id || generateId('CircleDrawable');
		this.type = 'CircleDrawable';
	}
	render() {
		const dx = this.x - this.startX;
		const dy = this.y - this.startY;
		const radius = Math.sqrt(dx * dx + dy * dy);
		return (
			<Circle
				radius={radius}
				x={this.startX}
				y={this.startY}
				stroke={this.color}
				strokeWidth={this.weight}
				onMouseDown={mouseDownOnShapeHandler.bind(this)}
				onMouseOver={mouseOverOnShapeHandler.bind(this)}
				perfectDrawEnabled={false}
				key={keyIncrement++}
			/>
		);
	}
};
export {CircleDrawable};

class RectDrawable extends Drawable {
	constructor(params) {
		const {startX, startY, x, y, weight, color, id} = params;
		super(params);
		this.x = x || startX;
		this.y = y || startY;
		this.weight = weight;
		this.color = color;
		this.id = id || generateId('rect');
		this.type = 'RectDrawable';
	}

	render() {
		const dx = this.x - this.startX;
		const dy = this.y - this.startY;
		return (
			<Rect
				x={this.startX}
				y={this.startY}
				width={dx}
				height={dy}
				fill={'transparent'}
				stroke={this.color}
				strokeWidth={this.weight}
				onMouseDown={mouseDownOnShapeHandler.bind(this)}
				onMouseOver={mouseOverOnShapeHandler.bind(this)}
				perfectDrawEnabled={false}
				key={keyIncrement++}
			/>
		);
	}
};
export {RectDrawable};

class TextDrawable extends Drawable {
	constructor(params) {
		const {startX, startY, weight, color, textSize, id} = params;
		let {textValue} = params;
		if (!textValue || textValue.trim() == '')
			textValue = undefined;
		super(params);
		this.x = startX;
		this.y = startY;
		this.weight = weight;
		this.color = color;
		this.textSize = textSize;
		this.textEditVisible = false;
		this.textX = 0;
		this.textY = 0;
		this.textValue = textValue;
		this.id = id || generateId('TextDrawable');
		this.type = 'TextDrawable';
	}

	registerMovement(x, y) {
		this.x = x;
		this.y = y;
		let textValue = this.textValue;
		if (!textValue)
			textValue = prompt("Que voulez-vous écrire ?") || '';
		this.textValue = textValue;
	}

	handleTextDblClick = () => {
		let newTextVal = prompt("Par quoi voulez vous remplacer le texte ?");
		if (!newTextVal || newTextVal.trim() == '')
			return;
		this.textValue = newTextVal;
		Bus.cast('rerender_whiteboard');
	};
	render() {
		return (
			<Text
				x={this.startX}
				y={this.startY}
				text={this.textValue}
				fontSize={this.textSize}
				fill={this.color}
				onMouseDown={mouseDownOnShapeHandler.bind(this)}
				onMouseOver={mouseOverOnShapeHandler.bind(this)}
				onDblClick={this.handleTextDblClick.bind(this)}
				perfectDrawEnabled={false}
				key={keyIncrement++}
			/>
		);
	}
};
export {TextDrawable};

class FreePathDrawable extends Drawable {
	constructor(params) {
		const {startX, startY, weight, color, points, id} = params;
		super(params);
		this.points = points || [startX, startY];
		this.weight = weight;
		this.color = color;
		this.id = id || generateId('FreePathDrawable');
		this.type = 'FreePathDrawable';
	}
	registerMovement(x, y) {
		this.points = [...this.points, x, y];
	}
	render() {
		return (
			<Line
				shadowForStrokeEnabled={false}
				points={this.points}
				fill='black'
				stroke={this.color}
				strokeWidth={this.weight}
				onMouseDown={mouseDownOnShapeHandler.bind(this)}
				onMouseOver={mouseOverOnShapeHandler.bind(this)}
				perfectDrawEnabled={false}
				key={keyIncrement++}
			/>
		);
	}
};
export {FreePathDrawable};
