import './WhiteboardTool.scss';

class WhiteboardTool extends React.Component {
	constructor(props) {
		super(props);
	}
	render() {
		return (
			<button {...this.props} className={`${this.props.className} WhiteboardTool`}>
				{this.props.children}
			</button>
		)
	}
};
export default WhiteboardTool;