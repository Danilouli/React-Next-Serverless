import Editor from 'draft-js-plugins-editor';
import createImagePlugin from 'draft-js-image-plugin';
import {EditorState, RichUtils, Modifier, convertToRaw, convertFromRaw, AtomicBlockUtils} from 'draft-js';
import debounce from 'debounce';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import * as JsonDiffPatch from 'jsondiffpatch';
import Bus from '/static/tools/bus.js';

const imagePlugin = createImagePlugin();
const tabCharacter = "    ";

class TextEditor extends React.Component {
	constructor(props) {
		super(props);
		this.socket = props.socket;
		this.state = {editorState: EditorState.createEmpty()};
		this.focus = () => this.refs.editor.focus();
	}

	static contextType = WebsiteContext;

	wksReadyCallback = ({workspace}) => {
		let {editorState} = this.state;
		let texts = workspace.texts;
		if (!texts || !texts.length || !texts[0].content)
			return;
		let text = texts[0];
		this.setState({
			editorState: EditorState.push(editorState, convertFromRaw(text.content))
		});
	};

	componentDidMount() {
		Bus.whenWksIsReady(this.wksReadyCallback.bind(this));
		this.socket.on('ser_new_raw_draft', this.handleModification.bind(this));
	}

	handleModification = delta => {
		let {editorState} = this.state;
		let raw = convertToRaw(this.state.editorState.getCurrentContent());
		let nextContentState = convertFromRaw(JsonDiffPatch.patch(raw, delta));
		this.setState({
			editorState: EditorState.push(editorState, nextContentState)
		});
	};

	broadcast = debounce((editorState) => {
		let raw = convertToRaw(editorState.getCurrentContent());
		if (!raw.blocks || !raw.blocks[0])
			return;
		if (!raw.blocks[0].text || raw.blocks[0].text == '')
			return;
		this.socket.emit('cli_new_raw_draft', {raw : raw, textNum : 0});
	}, 300);

	onChange = editorState => {
		this.broadcast(editorState);
		this.setState({ editorState });
	};

	onTab(e) {
		e.preventDefault();
		let currentState = this.state.editorState;
		let newContentState = Modifier.replaceText(
			currentState.getCurrentContent(),
			currentState.getSelection(),
			tabCharacter
		);
		this.setState({
			editorState: EditorState.push(currentState, newContentState, 'insert-characters')
		});
	}

	toggleBlockType(blockType) {
		let editorState = RichUtils.toggleBlockType(
			this.state.editorState,
			blockType
		);
		this.setState({editorState});
	}

	toggleInlineStyle(inlineStyle) {
		let editorState = RichUtils.toggleInlineStyle(
			this.state.editorState,
			inlineStyle
		);
		this.setState({editorState});
	}

	onChangeColor(e) {
		let editorState = RichUtils.toggleInlineStyle(
			this.state.editorState,
			e.target.value
		);
		this.setState({editorState});
	}

	handleAddImage = async () => {
		const newEditorState = this.insertImage(this.state.editorState, 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Proboscis_Monkey_in_Borneo.jpg/1024px-Proboscis_Monkey_in_Borneo.jpg');
		this.onChange(newEditorState);
	};

	insertImage = (editorState, imgUrl) => {
		const contentState = editorState.getCurrentContent();
		const contentStateWithEntity = contentState.createEntity(
			"image",
			"IMMUTABLE",
			{src: imgUrl}
		);
		const entityKey = contentStateWithEntity.getLastCreatedEntityKey();
		const newEditorState = EditorState.set(editorState, {
			currentContent: contentStateWithEntity
		});
		return AtomicBlockUtils.insertAtomicBlock(newEditorState, entityKey, " ");
	};

	onUndo() {
		this.onChange(EditorState.undo(this.state.editorState));
	}

	onRedo() {
		this.onChange(EditorState.redo(this.state.editorState));
	}

	render() {

		const {editorState} = this.state;

		let className = 'draft_editor';

		var contentState = editorState.getCurrentContent();
		if (!contentState.hasText()) {
			if (contentState.getBlockMap().first().getType() !== 'unstyled') {
				className += ' draft_hidePlaceholder';
			}
		}

		return (
			<div className="draft_root">
				<BlockStyleControls
					editorState={editorState}
					onToggle={this.toggleBlockType.bind(this)}
				/>
				<InlineStyleControls
					editorState={editorState}
					onToggle={this.toggleInlineStyle.bind(this)}
					onChangeColor={this.onChangeColor.bind(this)}
				/>
				<button onClick={this.onUndo.bind(this)}>Undo</button>
				<button onClick={this.onRedo.bind(this)}>Redo</button>
				{/* <button onClick={this.handleAddImage.bind(this)}>Insert an image</button> */}
				<div className={className} onClick={this.focus.bind(this)}>
					<Editor
						blockStyleFn={getBlockStyle}
						customStyleMap={styleMap}
						editorState={editorState}
						onChange={this.onChange}
						onTab={this.onTab.bind(this)}
						ref="editor"
						placeholder='Écrire..'
						spellCheck={true}
						plugins={[imagePlugin]}
					/>
				</div>
			</div>
		);
	}
};
export {TextEditor}

const styleMap = {
	CODE: {
		backgroundColor: 'rgba(0, 0, 0, 0.05)',
		fontFamily: '"Inconsolata", "Menlo", "Consolas", monospace',
		fontSize: 16,
		padding: 2,
	},
	BLUE : {
		color : 'blue'
	},
	GREEN : {
		color : 'green'
	},
	RED : {
		color : 'red'
	},
	YELLOW : {
		color : 'yellow'
	},
	BLACK : {
		color : 'black'
	}
};

function getBlockStyle(block) {
	switch (block.getType()) {
		case 'blockquote': return 'draft_blockquote';
		default: return null;
	}
}

class StyleButton extends React.Component {
	constructor() {
		super();
		this.onToggle = (e) => {
			e.preventDefault();
			this.props.onToggle(this.props.style);
		};
	}

	render() {
		let className = 'draft_styleButton';
		if (this.props.active) {
			className += ' draft_activeButton';
		}

		return (
			<span className={className} onMouseDown={this.onToggle}>
				{this.props.label}
			</span>
		);
	}
};
export {StyleButton};

const BLOCK_TYPES = [
	{label: 'H1', style: 'header-one'},
	{label: 'H2', style: 'header-two'},
	{label: 'H3', style: 'header-three'},
	{label: 'H4', style: 'header-four'},
	{label: 'H5', style: 'header-five'},
	{label: 'H6', style: 'header-six'},
	{label: 'Blockquote', style: 'blockquote'},
	{label: 'UL', style: 'unordered-list-item'},
	{label: 'OL', style: 'ordered-list-item'},
	{label: 'Code Block', style: 'code-block'},
];

const BlockStyleControls = (props) => {
	const {editorState} = props;
	const selection = editorState.getSelection();
	const blockType = editorState
	.getCurrentContent()
	.getBlockForKey(selection.getStartKey())
	.getType();

	return (
		<span className="draft_controls">
		{BLOCK_TYPES.map((type) =>
			<StyleButton
				key={type.label}
				active={type.style === blockType}
				label={type.label}
				onToggle={props.onToggle}
				style={type.style}
			/>
		)}
		</span>
	);
};
export {BlockStyleControls};

const INLINE_STYLES = [
	{label: 'Bold', style: 'BOLD'},
	{label: 'Italic', style: 'ITALIC'},
	{label: 'Underline', style: 'UNDERLINE'},
	{label: 'Monospace', style: 'CODE'}
];

const INLINE_COLORS = [
	{label: 'Blue', style: 'BLUE'},
	{label: 'Red', style: 'RED'},
	{label: 'Green', style: 'GREEN'},
	{label: 'Yellow', style: 'YELLOW'},
	{label: 'Clear', style: 'BLACK'}
];

const InlineStyleControls = (props) => {
	var currentStyle = props.editorState.getCurrentInlineStyle();
	return (
		<span className="draft_controls">
		{INLINE_STYLES.map(type =>
			<StyleButton
				key={type.label}
				active={currentStyle.has(type.style)}
				label={type.label}
				onToggle={props.onToggle}
				style={type.style}
			/>
		)}
		<select onChange={props.onChangeColor}>
			{INLINE_COLORS.map(type =>
				<option
					key={type.label}
					value={type.style}
				>
					{type.label}
				</option>
			)}
		</select>
		</span>
	);
};
export {InlineStyleControls};
