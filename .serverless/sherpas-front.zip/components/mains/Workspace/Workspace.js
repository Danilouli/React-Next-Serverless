import './Workspace.scss';
import {TextEditor} from './TextEditor.js';
import {Whiteboard} from './Whiteboard.js';
import WorkspaceNavbar from './WorkspaceNavbar.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {ToggableChat} from '/components/mains/ToggableChat/ToggableChat.js';
import {ToggableVideo} from '/components/mains/ToggableVideo/ToggableVideo.js';
import {TIMEGLOBS} from '/static/tools/tools.js';
import _ from 'lodash';
import Bus from '/static/tools/bus.js';
import {getConfirm, getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';
import Router from 'next/router';

class Workspace extends React.Component {
	constructor() {
		super()
		this.state = {
			view: 'whiteboard'
		}
	}

	static contextType = WebsiteContext;

	getCurrentView = () => {
		switch(this.state.view) {
			case 'whiteboard':
				return <Whiteboard socket={this.props.socket}/>
			case 'texteditor':
				return <TextEditor socket={this.props.socket}/>
		}
	}

	viewWhiteboard = () => {this.setState({view: 'whiteboard'});};

	viewTexteditor = () => this.setState({view: 'texteditor'});

	async componentDidMount() {
		Bus.initTrunk();
		const user = this.context.user;
		let socket = this.context.socket;
		socket.connect();
		console.log('connecting to wks...');
		socket.on('ser_wks_ready', data => {
			let valsToSet = {
				workspace : data.workspace,
				connected : data.connected,
				tokenTwilio : this.context.tokenTwilio
			};
			console.log('ser_wks_ready', data);
			Bus.setTrunk(old => _.set(old, 'workspace', data.workspace));
			this.context.setVals(valsToSet);
			Bus.cast('ser_wks_ready', data);
			socket.emit('cli_launch_course');
		});
		socket.on('ser_wks_updated', data => {
			this.context.setVals({'workspace' : data});
			Bus.setTrunk(old => _.set(old, 'workspace', data));
			Bus.cast('ser_wks_updated', data);
			console.log('ser_wks_updated');
		});
		socket.on('ser_launch_course', data => {
			console.log("Course is LAUNCHED, course Id", data);
			let {workspace} = this.context;
			if (data) {
				Bus.cast('ser_launch_course');
				let trialTime = _.get(workspace, 'trialTime', 1);
				console.log('tralTime', trialTime, workspace);
				if (trialTime > 1 && user.type != 'teacher') {
					let leaveTimeout = setTimeout(() => {
						window.location = '/';
					}, trialTime*TIMEGLOBS.minute);
					setTimeout(() => {
						getConfirm({
							title : "Le RDV Pédagogique se termine dans une minute",
							message : "Dans une minute, le temps passé sera payant, continuer ? (Vous quitterez automatiquement la salle de cours en cas de réponse négative ou absente)"
						})
						.then(() => {
							clearTimeout(leaveTimeout);
							leaveTimeout = undefined;
						})
						.catch(e => {
							e && console.error('Error to confirm', e);
							clearTimeout(leaveTimeout);
							window.location = '/';
						})
					}, (trialTime - 1)*TIMEGLOBS.minute);
					console.log('Tinou set');
				}
			}
		});
		socket.on('ser_course_closed', course => {
			console.log('course closed',course);
			if (_.get(course, '_id')) {
				getAlert({
					title : "Cours terminé",
					message : "Le cours est terminé ou l'autre utilisateur s'est deconnecté, vous pouvez quitter cette page ou attendre une reconnection"
				});
				Bus.cast('ser_course_closed');	
			}
		});
		Bus.when('leave_course', () => {
			socket.disconnect();
			Router.push({
				pathname: '/chat',
			});
		})
	}

	render() {
		return (
			<div className='Workspace'>
				<WorkspaceNavbar activeView={this.state.view} viewWhiteboard={this.viewWhiteboard} viewTexteditor={this.viewTexteditor}></WorkspaceNavbar>
				<div className='workspaceContent' id='workspaceContent'>
					<div>{this.getCurrentView()}</div>
					<div className='workspaceChat'>
						<ToggableChat socket={this.props.socket} conversation="student"></ToggableChat>
					</div>
				</div>
				<ToggableVideo className='workspaceVideo' socket={this.props.socket} conversation="student"></ToggableVideo>
			</div>
		);
	}
};
export default Workspace;
