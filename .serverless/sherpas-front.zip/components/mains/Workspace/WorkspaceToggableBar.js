import {ToggableChat} from '/components/mains/ToggableChat/ToggableChat.js';
import './WorkspaceToggableBar.scss';

class WorkspaceToggableBar extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div>
				<ToggableChat socket={this.props.socket}/>
			</div>
		)
	}
};
export default WorkspaceToggableBar;