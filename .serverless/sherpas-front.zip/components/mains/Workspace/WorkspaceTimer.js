import Icon from '@material-ui/core/Icon';
import './WorkspaceTimer.scss';
import Bus from '/static/tools/bus.js';

const toDoubleNumString = num => {
	if (num < 10)
		return '0'+num;
	return num.toString();
};

class WorkspaceTimer extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			intervalId : null,
			timeSpent : 0,
			seconds : 0,
			minutes : 0,
			hours : 0,
			timer : '00:00:00'
		};
	}

	increaseTimeSpentByOneSec() {
		let newTimeSpent = this.state.timeSpent + 1000;
		let newSeconds = Math.floor(newTimeSpent/1000);
		let newMinutes = Math.floor(newSeconds/60);
		newSeconds = newSeconds % 60;
		let newHours = Math.floor(newMinutes/60);
		newMinutes = newMinutes % 60;
		this.setState({
			timeSpent : newTimeSpent,
			minutes : newMinutes,
			seconds : newSeconds,
			hours : newHours,
			timer : `${toDoubleNumString(newHours)}:${toDoubleNumString(newMinutes)}:${toDoubleNumString(newSeconds)}`
		})
	}

	componentDidMount() {
		Bus.when('ser_launch_course', () => {
			if (!this.state.intervalId) {
				const boundFunc = this.increaseTimeSpentByOneSec.bind(this);
				this.state.intervalId = setInterval(boundFunc, 1000);
			}	
		});
		Bus.when('ser_course_closed', () => {
			if (this.state.intervalId) {
				clearInterval(this.state.intervalId);
				this.setState({intervalId : undefined, timeSpent : 0});
			}
			this.setState({
				timer : '00:00:00'
			});
		});
	}

	componentWillUnmount() {
		if (this.state.intervalId)
			clearInterval(this.state.intervalId);
	}

	render() {
		return (
			<span className='WorkspaceTimer'>
				<span><Icon>av_timer</Icon></span>
				<span className='time'>{this.state.timer}</span>
			</span>
		)	
	}
};
export default WorkspaceTimer;