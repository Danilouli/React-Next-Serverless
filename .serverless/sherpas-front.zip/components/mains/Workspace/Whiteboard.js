import './Workspace.scss'
import {Stage, Layer} from "react-konva";
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import * as Drawables from './Drawables.js';
import Bus from '/static/tools/bus.js';
import * as StyleTools from '/static/tools/style_tools.js';
import WhiteboardToolBar from './WhiteboardToolBar.js';
import _ from 'lodash';
import {getConfirm} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';

class Whiteboard extends React.Component {
	constructor(props) {
		super(props);
		this.socket = props.socket;
		this.state = {
			drawables: [],
			newDrawable: [],
			lastActions: [],
			forwardActions: [],
			newDrawableType: "FreePathDrawable",
			selectedWeight: 5,
			selectedColor: '#454545',
			selectedTextSize: 18,
			offsetVector: {x : 0, y : 0},
			outOfCanvas : false,
			mouseDown : false,
			mode: 'FreePathDrawable',
			stageScale: 1,
			isWriting : false
		};
	}

	registerDrawable(addedDrawable) {
		let {drawables} = this.state;
		let addedInd = drawables.findIndex(elt => (elt.id == addedDrawable.id));
		if (addedInd < 0)
			addedInd = drawables.length;
		drawables[addedInd] = addedDrawable;
		this.setState({drawables});
	}

	registerAndSendDrawable(addedDrawable) {
		let {drawables, lastActions} = this.state;
		let drawableToSend = Object.assign({}, addedDrawable);
		const drawableType = addedDrawable.constructor.name;
		this.registerDrawable(addedDrawable);
		lastActions.push({
			action : 'add',
			drawable : addedDrawable,
			id : addedDrawable.id
		});
		this.setState({
			newDrawable: [],
			lastActions,
			forwardActions: []
		});
		let toSend = {
			points : drawableToSend,
			type : drawableType,
			wbNum : 0
		};
		if (drawableType == 'ImageDrawable') {
			toSend.points.imageSrc = addedDrawable.image.src;
			delete toSend.points.image;
		}
		let theDrawablesToSend = JSON.parse(JSON.stringify(drawables));
		this.socket.emit('cli_updated_whiteboard_drawables', {drawables : theDrawablesToSend, wbNum : 0});
	}

	sockDrawablesUpdates = async data => {
		let {drawables} = data;
		let reDrawables = [];
		for (let d of drawables) {
			if (d.type == 'ImageDrawable') {
				let imgProm = new Promise((resolve, reject) => {
					const image = new window.Image();
					image.onload = () => {
						d.image = image;
						resolve();
					};
					image.src = d.imageSrc;
				});
				await imgProm;
			}
			reDrawables.push(this.getNewDrawableBasedOnType(d));
		}
		this.setState({drawables : reDrawables});
	};

	removeShapeCallback = e => {
		let {drawables, lastActions} = this.state;
		let toRemIndex = drawables.findIndex(elt => (elt && elt.id == e.detail.id));
		lastActions.push({
			action : 'remove',
			id : e.detail.id,
			drawable : drawables[toRemIndex]
		});
		drawables.splice(toRemIndex, 1);
		let theDrawablesToSend = JSON.parse(JSON.stringify(drawables));
		this.socket.emit('cli_updated_whiteboard_drawables', {drawables : theDrawablesToSend, wbNum : 0});
		this.setState({drawables, lastActions});
	};

	rerenderCallback = () => {
		let {drawables} = this.state;
		this.setState({drawables});
	};

	wksReadyCallback = ({workspace}) => {
		let wbs = workspace.whiteboards;
		if (!wbs || !wbs.length || !wbs[0].drawables)
			return;
		let wb = wbs[0];
		this.sockDrawablesUpdates(wb);
	};

	getNewDrawableBasedOnType = options => {
		let {type} = options;
		return new Drawables[type](options);
	};

	handleMouseDown = e => {
		const theStage = e.target.getStage();
		let { x, y } = theStage.getPointerPosition();
		let {cx,cy} = this.getComputedVector.bind(this)({x,y});
		const {newDrawable} = this.state;
		const {mode} = this.state;
		if (!Drawables[mode])
			return;
		if (newDrawable.length === 0) {
			// x -= this.state.offsetVector.x;
			// y -= this.state.offsetVector.y;
			if (this.state.newDrawableType) {
				const newDrawable = this.getNewDrawableBasedOnType({
					startX : cx,
					startY : cy,
					type : this.state.newDrawableType,
					weight : this.state.selectedWeight,
					color : this.state.selectedColor,
					image : this.state.imageTile,
					textSize : this.state.selectedTextSize,
					textToPrint : this.state.textToPrint
				});
				this.setState({
					isWriting : true,
					newDrawable: [newDrawable]
				});
			}
		}
	};

	handleZoom = e => {
		const theStage = this.stageRef.getStage();
		let zoomVal = parseFloat(_.get(e, 'target.value', 1));
		theStage.scaleX(zoomVal);
		theStage.scaleY(zoomVal);
		this.setState({
			stageScale : zoomVal
		});
	};

	handleUndo = () => {
		let {lastActions, drawables, forwardActions} = this.state;
		const lastAction = lastActions.pop();
		if (!lastAction)
			return;
		if (lastAction.action == 'remove')
			drawables.push(lastAction.drawable);
		else if (lastAction.action == 'add')
			drawables = drawables.filter(el => el.id != lastAction.id);
		forwardActions.push(lastAction);
		let theDrawablesToSend = JSON.parse(JSON.stringify(drawables));
		this.socket.emit('cli_updated_whiteboard_drawables', {drawables : theDrawablesToSend, wbNum : 0});
		this.setState({drawables, lastActions, forwardActions});
	}

	handleRedo = () => {
		let {lastActions, drawables, forwardActions} = this.state;
		const forwardAction = forwardActions.pop();
		if (!forwardAction)
			return;
		if (forwardAction.action == 'add')
			drawables.push(forwardAction.drawable);
		else if (forwardAction.action == 'remove')
			drawables = drawables.filter(el => el.id != forwardAction.id);
		lastActions.push(forwardAction);
		let theDrawablesToSend = JSON.parse(JSON.stringify(drawables));
		this.socket.emit('cli_updated_whiteboard_drawables', {drawables : theDrawablesToSend, wbNum : 0});
		this.setState({drawables, lastActions, forwardActions});
	}

	handleMouseMove = e => {
		const theStage = e.target.getStage();
		let { x, y } = theStage.getPointerPosition();
		let {cx,cy} = this.getComputedVector.bind(this)({x,y});
		const {newDrawable} = this.state;
		const {mode, mouseDown} = this.state;
		if (!Drawables[mode] && mouseDown)
			return;
		if (newDrawable.length !== 1) {
			if (this.state.outOfCanvas)
				this.setState({outOfCanvas : false});
			return;
		}
		if (this.state.outOfCanvas) {
			const drawableToAdd = newDrawable[0];
			this.registerAndSendDrawable(drawableToAdd);
			this.setState({outOfCanvas : false});
		}
		else {
			// x -= this.state.offsetVector.x;
			// y -= this.state.offsetVector.y;
			const updatedNewDrawable = newDrawable[0];
			updatedNewDrawable.registerMovement(cx, cy);
			this.setState({
				isWriting : true,
				newDrawable: [updatedNewDrawable]
			});
		}
	};

	handleEraser = () => {
		this.setState({mode : 'eraser'});
	}

	handleDragWhiteboard = () => {
		this.setState({mode : 'drag'});
	};

	handleFreePath = () => {
		this.setState({mode : 'FreePathDrawable', newDrawableType : 'FreePathDrawable'});
	}

	handleArrow = () => {
		this.setState({mode : 'ArrowDrawable', newDrawableType : 'ArrowDrawable'});
	}

	handleCircle = () => {
		this.setState({mode : 'CircleDrawable', newDrawableType : 'CircleDrawable'});
	};

	handleRectangle = () => {
		this.setState({mode : 'RectDrawable', newDrawableType : 'RectDrawable'});
	}

	handleLine = () => {
		this.setState({mode : 'LineDrawable', newDrawableType : 'LineDrawable'});
	}

	handleText = () => {
		this.setState({mode : 'TextDrawable', newDrawableType : 'TextDrawable'});
	}

	getComputedVector({x,y}) {
		return {
			cx : (x - this.state.offsetVector.x)/this.state.stageScale,
			cy : (y - this.state.offsetVector.y)/this.state.stageScale
		}
	};

	handleMouseUp = e => {
		let { x, y } = e.target.getStage().getPointerPosition();
		let {cx,cy} = this.getComputedVector.bind(this)({x,y});
		let {newDrawable} = this.state;
		const {mode} = this.state;
		if (!Drawables[mode])
			return;
		if (newDrawable.length === 1) {
			// x -= this.state.offsetVector.x;
			// y -= this.state.offsetVector.y;
			const drawableToAdd = newDrawable[0];
			drawableToAdd.registerMovement(cx, cy);
			this.setState({isWriting : false}, () => this.registerAndSendDrawable(drawableToAdd));
		}
	};

	handleDragEnd = e => this.setState({offsetVector : e.target._lastPos});

	handleExportClick = () => {
		var dataURL = this.stageRef.getStage().toDataURL({ pixelRatio: 3 });
		this.downloadURI(dataURL, 'stage.png');
	}

	downloadURI = (uri, name) => {
		var link = document.createElement('a');
		link.download = name;
		link.href = uri;
		document.body.appendChild(link);
		link.click();
	}

	handleSelectWeight = e => {
		let stateUp = {
			selectedWeight: e.value
		};
		if (this.state.mode.indexOf('Drawable') < 0) {
			stateUp.mode = 'FreePathDrawable';
			stateUp.newDrawableType = 'FreePathDrawable';
		}
		this.setState(stateUp);
		if (this.state.mode == 'eraser')
			this.handleFreePath(e);
	};

	handleSelectColor = e => {
		let stateUp = {
			selectedColor: e.value
		};
		if (this.state.mode.indexOf('Drawable') < 0) {
			stateUp.mode = 'FreePathDrawable';
			stateUp.newDrawableType = 'FreePathDrawable';
		}
		this.setState(stateUp);
		if (this.state.mode == 'eraser')
			this.handleFreePath(e);
	};

	handleSelectTextSize = e => {
		this.setState({selectedTextSize: e.target.value})
	};

	handleClearWhiteboard = () => {
		getConfirm({
			title : "Attention, en procédant, tout le tableau sera effacé et irrécupérable",
			message : "Effacer ?"
		})
		.then(() => {
			this.setState({
				inDragMode : false,
				drawables : [],
				lastActions : [],
				forwardActions : []
			});
			this.socket.emit('cli_updated_whiteboard_drawables', {drawables : [], wbNum : 0});	
		})
		.catch(e => e && console.error("Error to get confirm", e));
	};

	handleImageChange = e => {
		e.preventDefault();
		let theFiles = e.target.querySelector('input[type="file"]').files;
		let imgUrl = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Proboscis_Monkey_in_Borneo.jpg/1024px-Proboscis_Monkey_in_Borneo.jpg';
		let imgTile = new window.Image();
		imgTile.onload = () => {
			this.setState({
				imageTile: imgTile,
				newDrawableType: "ImageDrawable"
			});
		};
		imgTile.src = imgUrl;
	}

	updateWhiteboardSize = () => {
		const parent = document.getElementById('workspaceContent');
		const stageWidth = window.innerWidth;
		const stageHeight = StyleTools.getCSSNumProp(parent, 'height');
		this.setState({stageWidth, stageHeight});
	}

	linkToTrunk = Bus.linkToTrunk(this, {sendState : true, eltName : 'Whiteboard'});

	static contextType = WebsiteContext;

	setMouseDown = () => {
		Bus.setTrunk(old => _.set(old, 'Whiteboard.mouseDown', true));
	};
	
	setMouseUp = () => {
		Bus.setTrunk(old => _.set(old, 'Whiteboard.mouseDown', false));
	};

	componentDidMount() {
		this.linkToTrunk.sendState();
		Bus.whenWksIsReady(this.wksReadyCallback.bind(this));
		let canvas = document.querySelector('canvas');
		canvas.addEventListener('mouseout', () => this.setState({outOfCanvas : true}));
		Bus.when('remove_shape', this.removeShapeCallback.bind(this));
		Bus.when('rerender_whiteboard', this.rerenderCallback.bind(this));
		window.addEventListener('mousedown', this.setMouseDown.bind(this));
		window.addEventListener('mouseup', this.setMouseUp);
		this.socket.removeAllListeners('ser_updated_whiteboard_drawables');
		this.socket.on('ser_updated_whiteboard_drawables', this.sockDrawablesUpdates.bind(this));
		this.updateWhiteboardSize();
	}

	componentDidUpdate(prevProps, prevState) {
		this.linkToTrunk.sendChanges(prevProps, prevState);
	};

	render() {
		const drawables = [...this.state.drawables, ...this.state.newDrawable];
		return (
			<div>
				<WhiteboardToolBar wb={this}></WhiteboardToolBar>
				<div>
					<Stage
						onMouseDown={this.handleMouseDown}
						onMouseUp={this.handleMouseUp}
						onMouseMove={this.handleMouseMove}
						onDragStart={this.handleDragStart}
						onDragMove={this.handleDragMove}
						onDragEnd={this.handleDragEnd}
						width={this.state.stageWidth}
						height={this.state.stageHeight}
						ref={node => {this.stageRef = node}}
						draggable={this.state.mode == 'drag'}
						style={{backgroundImage : 'url("static/background.svg")'}}
					>
						<Layer>
							{drawables.map(drawable => {
								if (!drawable.deleted)
									return drawable.render();
							})}
						</Layer>
					</Stage>
				</div>
			</div>
		);
	}
};
export {Whiteboard};
