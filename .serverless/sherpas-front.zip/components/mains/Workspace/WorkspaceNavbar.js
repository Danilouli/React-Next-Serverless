import WorkspaceNavbarButton from './WorkspaceNavbarButton.js';
import WorkspaceTimer from './WorkspaceTimer.js';
import {getConfirm} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';
import Bus from '/static/tools/bus.js';
import './WorkspaceNavbar.scss';
import ClassicButton from "/components/misc/ClassicButton/ClassicButton.js"

const WorkspaceNavbar = props => {
	const handleCourseLeave = () => {
		getConfirm({title : "Quitter le cours", message : "Voulez-vous vraiment vous déconnecter de l'espace de cours ?", close : false})
		.then(Bus.fcast('leave_course'))
		.catch(console.error);
	}

	return (
		<div className='WorkspaceNavbar'>
			<span className='partContainer imageAndTitle'>
				<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/logo_horizontal.png'></img>
				<span className='title'>Salle de classe</span>
			</span>
			<span className='partContainer workspaceButtons'>
				<WorkspaceNavbarButton active={`${props.activeView == 'whiteboard'}`} icon='create' onClick={props.viewWhiteboard}>Tableau</WorkspaceNavbarButton>
				<WorkspaceNavbarButton active={`${props.activeView == 'texteditor'}`} icon='subject' onClick={props.viewTexteditor}>Éditeur de texte</WorkspaceNavbarButton>
				{/* <WorkspaceNavbarButton active={`${props.activeView == 'sharedFiles'}`} icon='insert_drive_file' onClick={e=>e}>Fichiers partagés</WorkspaceNavbarButton> */}
			</span>
			<span className='partContainer timerAndSettings'>
				<WorkspaceTimer></WorkspaceTimer>
				<span className='settingsIcon'>
					<ClassicButton className='padv10 padh20' type='caution' defaultCss={false} onClick={handleCourseLeave}>
						Quitter le cours
					</ClassicButton>
				</span>
			</span>
		</div>
	);
}
export default WorkspaceNavbar;