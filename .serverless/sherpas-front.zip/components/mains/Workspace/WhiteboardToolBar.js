import './WhiteboardToolBar.scss';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faPencilAlt, faLongArrowAltDown, faRuler, faFont, faImage, faUndo, faRedo, faCamera, faEraser, faTrash, faTextHeight} from '@fortawesome/free-solid-svg-icons';
import {faCircle, faSquare, faHandPaper} from '@fortawesome/free-regular-svg-icons';
import InlineSelect from '/components/misc/InlineSelect/InlineSelect.js';
import WhiteboardTool from './WhiteboardTool.js';

class WhiteboardToolBar extends React.Component {
	constructor(props) {
		super(props);
	}
	render() {
		const wb = this.props.wb;
		return (
			<div className='WhiteboardToolBar'>
				<WhiteboardTool onClick={wb.handleUndo}>
					<FontAwesomeIcon icon={faUndo}/>
				</WhiteboardTool>

				<WhiteboardTool onClick={wb.handleRedo}>
					<FontAwesomeIcon icon={faRedo}/>
				</WhiteboardTool>

				<WhiteboardTool onClick={wb.handleEraser} active={`${wb.state.mode == 'eraser'}`}>
					<FontAwesomeIcon icon={faEraser}/>
				</WhiteboardTool>

				<WhiteboardTool onClick={wb.handleDragWhiteboard} active={`${wb.state.mode == 'drag'}`}>
					<FontAwesomeIcon icon={faHandPaper}/>
				</WhiteboardTool>

				<WhiteboardTool onClick={wb.handleFreePath} active={`${wb.state.mode == 'FreePathDrawable'}`}>
					<FontAwesomeIcon icon={faPencilAlt}/>
				</WhiteboardTool>

				<WhiteboardTool onClick={wb.handleArrow} active={`${wb.state.mode == 'ArrowDrawable'}`}>
					<FontAwesomeIcon icon={faLongArrowAltDown}/>
				</WhiteboardTool>

				<WhiteboardTool onClick={wb.handleCircle} active={`${wb.state.mode == 'CircleDrawable'}`}>
					<FontAwesomeIcon icon={faCircle}/>
				</WhiteboardTool>

				<WhiteboardTool onClick={wb.handleRectangle} active={`${wb.state.mode == 'RectDrawable'}`}>
					<FontAwesomeIcon icon={faSquare}/>
				</WhiteboardTool>

				<WhiteboardTool onClick={wb.handleLine} active={`${wb.state.mode == 'LineDrawable'}`}>
					<FontAwesomeIcon icon={faRuler}/>
				</WhiteboardTool>
			
				{/* Text tool to ameliorate */}
				{/* <WhiteboardTool className='textTool' onClick={wb.handleText}>
					<FontAwesomeIcon icon={faFont}/>
				</WhiteboardTool>

				<select className='tool textSizeSelect' value={wb.state.selectedTextSize} onChange={wb.handleSelectTextSize}>
					<option value={18}>Taille : 18</option>
					<option value={24}>Taille : 24</option>
					<option value={32}>Taille : 32</option>
					<option value={42}>Taille : 42</option>
					<option value={60}>Taille : 60</option>
				</select> */}

				<InlineSelect className='colorSelect tool' value={wb.state.selectedColor} style={{display: 'inline-block'}} onChange={wb.handleSelectColor}>
					{['#454545','#DD4E40','#30AD8C','#E57D46','#3A91CA','#862ACB']
					.map(color =>
						<div 
							style={{ "--bg-color": color }}
							className='color subTool'
							key={color}
							value={color}
						></div>
						)
					}
				</InlineSelect>

				<InlineSelect className='weightSelect tool' value={wb.state.selectedWeight} style={{display: 'inline-block'}} onChange={wb.handleSelectWeight}>
					{[5, 10, 15, 20, 25]
					.map(weight =>
						<div 
							style={{"--weight-width": `${weight}px`, "--bg-color" : `${wb.state.selectedColor}`}}
							className='weight subTool'
							key={weight}
							value={weight}
						></div>
						)
					}
				</InlineSelect>
				
				<select className='tool textSizeSelect' value={wb.state.stageScale} onChange={wb.handleZoom}>
					<option value={0.1}>10%</option>
					<option value={0.25}>25%</option>
					<option value={0.5}>50%</option>
					<option value={0.75}>75%</option>
					<option value={1}>100%</option>
					<option value={1.5}>150%</option>
				</select>

				<WhiteboardTool onClick={wb.handleClearWhiteboard}>
					<FontAwesomeIcon icon={faTrash}/>
				</WhiteboardTool>

				<form style={{display: 'none'}} onSubmit={wb.handleImageChange}>
					<input className="fileInput" type="file"/>
				</form>

				<WhiteboardTool><FontAwesomeIcon icon={faImage}/></WhiteboardTool>

				<WhiteboardTool onClick={wb.handleExportClick}><FontAwesomeIcon icon={faCamera}/></WhiteboardTool>
				</div>
		)
	}
};
export default WhiteboardToolBar;