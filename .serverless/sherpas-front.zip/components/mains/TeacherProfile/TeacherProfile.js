import './TeacherProfile.scss';
import _ from 'lodash';
import PropTypes from 'prop-types'; 
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import TeacherProfile_Head from './TeacherProfile_Head.js';
import TeacherProfile_Description from './TeacherProfile_Description.js';
import TeacherProfile_Prices from './TeacherProfile_Prices.js';
import TeacherContactBox from '/components/misc/TeacherContactBox/TeacherContactBox.js';

class TeacherProfile extends React.Component {
	constructor(props) {
		super(props);
	}

	static contextType = WebsiteContext;

	render() {
		let subjectsTaught = this.context.teacher.teacherInfos.subjectsTaught;
		for (let s in subjectsTaught) {
			subjectsTaught[s]._realName = _.get(this.context.lang.subjects.find(e => e.value == s), 'name', s);
			let sub = subjectsTaught[s];
			for (let l in sub) {
				if (l == '_realName')
					continue;
					sub[l]._realName = _.get(this.context.lang.levels.find(e => e.value == l), 'name', l);
			}
		}
		return (
			<div className='TeacherProfile large_flex_container bgbeige'>
				<div className='tp-main'>
					<div className='tp-descriptionContainer'>
						<TeacherProfile_Head teacher={this.context.teacher} subjectsTaught={subjectsTaught}/>
						<h2 className='bold fs18 mart50 marb20'>Présentation</h2>
						<TeacherProfile_Description teacher={this.context.teacher}/>
						<div className='tp-teacherPrices'>
							<h2 className='bold fs18 marb20'>Matières enseignées et tarifs</h2>
							<div className='tp-teacherSubjectsPrices'>
								<TeacherProfile_Prices subjectsTaught={subjectsTaught}/>
							</div>
						</div>
					</div>
					<div className='tp-contactBox'>
						<TeacherContactBox teacher={this.context.teacher} subjectsTaught={subjectsTaught} fromTeacher={this.props.fromTeacher}/>
					</div>
				</div>
			</div>
		)
	}
};
export default TeacherProfile;