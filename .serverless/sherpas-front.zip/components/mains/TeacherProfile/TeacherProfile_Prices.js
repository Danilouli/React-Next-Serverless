import _ from 'lodash';

const TeacherProfile_Prices = props => {
	let subjectsTaught = props.subjectsTaught;
	return (
		<table className='tp-prices'>
			<tbody>
			<tr className='tp-teacherPriceLine tp-teacherPriceHead'>
				<td><h3 className='marb0'>Matière proposée</h3></td>
				<td><h3 className='marb0'>Qualification</h3></td>
				<td><h3 className='marb0'>Prix</h3></td>
			</tr>
			{Object.keys(subjectsTaught).map(s => {
				let sub = subjectsTaught[s];
				let priceLines = Object.keys(sub).map((p,ind) => {
					if (p == '_realName')
						return;
					let proposition = sub[p];
					if (!_.get(proposition, 'price') || !_.get(proposition, 'wants'))
						return;
					return (
						<tr key={ind} className='tp-teacherPriceLine'>
							<td>{sub._realName}</td>
							<td>{proposition._realName}</td>
							<td>{Math.floor(proposition.price/100)}€ / heure</td>
						</tr>
					)
				}).filter(e=>e);
				return priceLines;
			})}
			</tbody>
		</table>
	)
};
export default TeacherProfile_Prices;
