const TeacherProfile_Description = props => (
	<div className='tp-description mart10 boxs_extra-light'>
		<div className='tp-textContainer'>
			<div className='tp-text classic_text light marb30'>
				<h2 dangerouslySetInnerHTML={{__html : props.teacher.profile.description.catchPhrase}}></h2>
			</div>
			<div className='tp-text classic_text light' dangerouslySetInnerHTML={{__html : props.teacher.profile.description.methodology}}></div>
		</div>
		<div className='tp-gradesContainer'>
			<h3 className='rb28 marb10'>Mes notes</h3>
			<div className='tp-grades classic_text light' dangerouslySetInnerHTML={{__html : props.teacher.profile.description.grades}}></div>
		</div>
		<div className='tp-cvContainer'>
			<h3 className='rb28 marb10'>Mon parcours</h3>
			<div className='tp-cv classic_text light' dangerouslySetInnerHTML={{__html : props.teacher.profile.description.cv}}></div>
		</div>
	</div>
);
export default TeacherProfile_Description;