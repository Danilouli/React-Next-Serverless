const Stat = props => (
	<div className='tp-stat'>
		<div className='tp-statTitle'>{props.statTitle}</div>
		<div className='tp-statInfo'>{props.statInfo}</div>
	</div>
);

const TeacherProfile_Head = props => {
	const teacher = props.teacher;
	const su = props.subjectsTaught;
	console.log('subjectsTaught', su);
	let minPrice = (Math.min(...(Object.keys(su).map(s=>(Math.min(...(Object.keys(su[s]).map(l=>su[s][l].price || Infinity))))))))/100;
	let maxPrice = (Math.max(...(Object.keys(su).map(s=>(Math.max(...(Object.keys(su[s]).map(l=>su[s][l].price || 0))))))))/100;
	console.log('minPrice', minPrice);
	console.log('maxPrice', maxPrice);
	let pricePhrase = (minPrice != maxPrice) ? `${minPrice} à ${maxPrice} €` : `${minPrice} €`;
	return (
		<div className='tp-head '>
			<div className='tp-headImage'>
				<img src={teacher.profile.picture}></img>
			</div>
			<div className='tp-headInfos'>
				<div className='nameAndLove'>
					<span className='name big_h2'>{teacher.fname}</span>
					{/* <span className='love'>LOVE</span> */}
				</div>
				<div className='tp-headDescription'>
					<h1 dangerouslySetInnerHTML={{__html : teacher.profile.description.title}}></h1>
				</div>
				<div className='tp-stats'>
					<Stat statTitle={pricePhrase} statInfo='par heure'/>
					{/* <Stat statTitle='⭐️ 4.87' statInfo='125 avis'/>
					<Stat statTitle='46' statInfo='leçons complétées'/> */}
				</div>
			</div>
		</div>
	)
};
export default TeacherProfile_Head;