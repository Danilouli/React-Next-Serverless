import Settings_Navbar from './Settings_Navbar.js';
import Settings_General from './Settings_General.js';
import Settings_Prices from './Settings_Prices.js';
import Settings_Marketing from './Settings_Marketing.js';
import Settings_Payment from './Settings_Payment.js';
import Settings_Tablet from './Settings_Tablet.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import './Settings.scss';

const panelElements = {
	general : {
		content : <Settings_General/>,
		name : 'General'
	},
	payment : {
		content : <Settings_Payment/>,
		name : 'Paiement'
	},
	notifications : {
		content : <Settings_Prices/>,
		name : 'Notifications'
	},
	prices : {
		content : <Settings_Prices/>,
		name : 'Tes Tarifs',
	},
	marketing : {
		content : <Settings_Marketing/>,
		name : 'Ton Marketing',
	},
	certifications : {
		content : <Settings_Prices/>,
		name : 'Tes Certifications',
	},
	disponibilities : {
		content : <Settings_Prices/>,
		name : 'Tes Disponibilités',
	},
	tablet : {
		content : <Settings_Tablet/>,
		name : "Tablette graphique",
	},
	children : {
		content : <Settings_Prices/>,
		name : 'Parrainer un Ami',
	},
	recommend : {
		content : <Settings_Prices/>,
		name : 'Parrainer un Ami',
	},
	security : {
		content : <Settings_Prices/>,
		name : "Sécurité",
	},
	test : {
		content : <Settings_Prices/>,
		name : "Tester la salle de classe",
	},
};
const orders = {
	parent : ['general',/*'children','recommend',*/'payment',/*'notifications','security','test'*/],
	student : ['general','payment',/*'notifications','recommend','test'*/],
	teacher : ['general','prices','marketing','payment'/*,'certifications','disponibilities'*/,'tablet',/*'notifications'*/]
};


class Settings extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			switch : true,
			panel : 'general'
		}
		this.panels = {
			orders,
			elements : panelElements
		};
	}

	static contextType = WebsiteContext;

	render() {
		return (
			<div className="Settings flex relw100vw bgbeige">
				<div className="set-navbarContainer marl150 marr40 rel">
					<Settings_Navbar settings={this}/>
				</div>
				<div className="set-main rel flex fdc">
					{this.panels.elements[this.state.panel].content}
				</div>
			</div>
		)
	}
};
export default Settings;