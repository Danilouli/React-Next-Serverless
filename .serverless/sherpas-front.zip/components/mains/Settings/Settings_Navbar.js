import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faPen, faEye} from '@fortawesome/free-solid-svg-icons';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import MaterialSwitch from '/components/misc/MaterialSwitch/MaterialSwitch.js';
import {useContext} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {deleteLoginCookies} from '/static/tools/tools.js';
import {api} from '/static/tools/network.js';
import {DEFAULTIMG} from '/static/tools/tools.js';
import _ from 'lodash';

const logout = () => {
	deleteLoginCookies();
	api.post('tck_users/logout').then(suc => {
		window.location = '/';
	});
};

const Settings_Navbar = props => {
	const context = useContext(WebsiteContext);
	const {user} = context;
	const {settings} = props;
	return (
		<div className="set-navbar flex fdc">
			<div className="set-navbarBar relw100 flex fdc marb15">
				<div className="set-profilePic relw100">
					<img className='sage_image' src={_.get(user, 'profile.picture', DEFAULTIMG)}/>
					{/* <span className='set-editProfilePic'><FontAwesomeIcon icon={faPen}/></span> */}
				</div>
				<div className="set-links relw100 flex fdc">
					<div className="set-navbarName set-linksPart">
						<p className='big_text cblack'>{_.get(user, 'fname', '*****')}</p>
						{user.type == 'teacher' && <p className='classic_text cgrey'>{_.get(user, 'teacherInfos.institution', "")}</p>}
					</div>
					<div className="set-mainLinks set-linksPart">
						{
							settings.panels.orders[user.type].map(panel => (
								<p className='set-link' key={panel} active={`${settings.state.panel == panel}`} onClick={() => settings.setState({panel})}>{settings.panels.elements[panel].name}</p>
							))
						}
					</div>
					<div className="set-helpLinks set-linksPart">
						<p className='set-link'>Centre d'Aide</p>
						<p className='set-link'>Signaler un problème</p>
						<p className='set-link'>Nous contacter</p>
						<p className='set-link' onClick={logout}>Déconnexion</p>
					</div>
				</div>
			</div>
			{
				user.type == 'teacher' && false &&
				<div className="set-seeTeacherAnnounceButton relw100 cwhite marb15">
					<GreenButton className='padv20'>
						<span className='txtac classic_text'>
							<FontAwesomeIcon icon={faEye}/><br/>
							Voir et modifier mon annonce
						</span>
					</GreenButton>
				</div>
			}
			{
				user.type == 'teacher' && false &&
				<div className="set-switchTeacher relw100 flex jcc fdr aic">
					<span><MaterialSwitch checked={settings.state.switch} onChange={() => settings.setState({switch : !settings.state.switch})}/></span>
					<span className='fs14 cblue lh18'>
						{
							settings.state.switch ?
							"Tu es visible sur la Marketplace" :
							"Tu n'es pas visible sur la Marketplace"
						}
					</span>
				</div>
			}
		</div>
	);
};
export default Settings_Navbar;