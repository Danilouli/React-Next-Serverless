import {useContext} from 'react';
import SettingsBoard from '/components/misc/SettingsBoard/SettingsBoard.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {validateEmail, isPhone} from '/static/tools/misc.js';
import {getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';

const Settings_General = props => {
	const context = useContext(WebsiteContext);
	const {user} = context;
	return (
		<div className="set-general">
			<div className="set-board">
				<SettingsBoard
					title="Général"
					subtitle={`Les informations générales concernant ton profil`}
					sendText={<span>Sauver les modifications</span>}
					inputs={[
						[
							{
								value : 'fname',
								label : 'Prénom',
								disabled : true,
								placeholder : user.fname
							},
							{
								value : 'lname',
								label : 'Nom',
								disabled : true,
								placeholder : user.lname
							}
						],
						[
							{
								value : 'email',
								label : 'Adresse email',
								type : 'email',
								placeholder : user.email,
								optional : true,
								check : e=>(!validateEmail(e) ? "Mail invalide" : false)
							},
							{
								value : 'phone',
								label : 'Téléphone',
								placeholder : user.phone,
								optional : true,
								check : v=>(!isPhone(v) ? "Numéro invalide" : false),
								transform : v=>(isPhone(v) || v)
							}
						],
						// [
						// 	{
						// 		value : 'country',
						// 		label : 'Pays'
						// 	},
						// 	{
						// 		value : 'city',
						// 		label : 'Ville'
						// 	}
						// ],
						[
							{
								value : 'birthDate',
								label : 'Date de Naissance',
								type : 'date'
							},
							{
								content : <span></span>
							}	
						]
					]}
					submitUrl='tck_users/update/set'
					beforeSend={e=>{
						if (e.birthDate)
							e.birthDate = (new Date(e.birthDate)).getTime();
						const ret = {
							auth : context.auth,
							query : {
								_id : user._id
							},
							update : e
						};
						return ret;
					}}
					onSubmitSuccess={() => getAlert("Informations mises à jour")}
				/>
			</div>
			<div className="set-board">
				<SettingsBoard
					title="Sécurité"
					subtitle="Modifie ton mot de passe"
					sendText={<span>Sauver les modifications</span>}
					inputs={[
						[
							{
								value : 'oldPsswd',
								label : 'Ancien mot de passe',
								type : 'password',
								check : v=>(v.length < 6 ? "Au moins 6 caractères" : false)
							},
							// {
							// 	content : <a className='fs10 light'>Mot de passe oublié ?</a>
							// }	
						],
						[
							{
								value : 'newPsswd',
								label : 'Nouveau mot de passe',
								type : 'password',
								check : v=>(v.length < 6 ? "Au moins 6 caractères" : false)
							},
							{
								value : 'newPsswdConf',
								label : 'Confirmation',
								type : 'password'
							}
						],
					]}
					beforeSend={e=>{
						const {newPsswd, newPsswdConf} = e;
						if (newPsswd != newPsswdConf) {
							getAlert("Les mots de passe ne conviennent pas");
							return;
						}
						const ret = {
							auth : context.auth,
							query : {
								_id : user._id
							},
							update : {
								psswd : newPsswd
							}
						};
						return ret;
					}}
					submitUrl='tck_users/update/set'
					onSubmitSuccess={() => getAlert("Informations mises à jour")}
				/>
			</div>
		</div>
	)
};
export default Settings_General;