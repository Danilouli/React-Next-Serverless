import {useContext, useState} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import SmallAlert from '/components/misc/SmallAlert/SmallAlert.js';
import MaterialSwitch from '/components/misc/MaterialSwitch/MaterialSwitch.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight, faCheckCircle, faCircleNotch} from '@fortawesome/free-solid-svg-icons';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import {api} from '/static/tools/network.js';
import _ from 'lodash';
import {getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';
import {purgeNonNumbers} from '/static/tools/misc.js';
import {DEFAULTIMG} from '/static/tools/tools.js';

class SubjectLine extends React.Component {
	constructor(props, context) {
		super(props, context);
		const {teacherGrade} = context;
		this.pathLine = `${props.subject.value}.${props.level.value}`;
		this.min = 12;
		this.max = _.get(teacherGrade, 'maxPrice', 2400)/100;
		this.state = {
			wants : this.props.wants,
			price : this.props.price
		}
	}

	static contextType = WebsiteContext;

	unCheckLine() {
		const {user, auth} = this.context;
		let update = {}
		update[`teacherInfos.subjectsTaught.${this.pathLine}.wants`] = false;
		api.post('tck_users/update/set', {
			auth,
			query : {_id : user._id, type : 'teacher'},
			update
		})
		.then(suc => {
			this.setState({wants : false});
		})
		.catch(err => {
			console.error('err', err);
			getAlert({title : "Erreur", message : "Impossible de mettre à jour le statut pour cette matière"});
		})
	}

	checkLine() {
		const {user, auth} = this.context;
		let update = {}
		update[`teacherInfos.subjectsTaught.${this.pathLine}.wants`] = true;
		api.post('tck_users/update/set', {
			auth,
			query : {_id : user._id, type : 'teacher'},
			update
		})
		.then(suc => {
			this.setState({wants : true});
		})
		.catch(err => {
			console.error('err', err);
			getAlert({title : "Erreur", message : "Impossible de mettre à jour le statut pour cette matière"});
		})
	}

	parsePrice(e) {
		let val = e.target.value;
		val = purgeNonNumbers(val);
		val = parseInt(val);
		if (isNaN(val))
			val = '';
		else {
			if (val > this.max)
				return;
			val *= 100;
		}
		this.setState({price : val})
	} 

	checkPrice(e) {
		const {user, auth} = this.context;
		let val = e.target.value;
		let priceToSend = parseInt(val);
		if (val < this.min || val > this.max) {
			priceToSend = Math.ceil((this.min + this.max)/2);
			console.log('pricetosend', priceToSend, this.max, this.min);
		}
		priceToSend *= 100;
		let update = {}
		update[`teacherInfos.subjectsTaught.${this.pathLine}.price`] = priceToSend;
		console.log('up to send', update);
		api.post('tck_users/update/set', {auth, update})
		.then(suc => {
			console.log('suc up price', suc);
			this.setState({price : priceToSend});
		})
		.catch(err => {
			console.error('err', err);
			getAlert({title : "Erreur", message : "Impossible de mettre à jour le prix pour cette matière"});
		})
	}

	render() {
		return (
			<div className="set-subjectLine flex aic marb10">
				<span><MaterialSwitch checked={this.state.wants} onCheck={this.checkLine.bind(this)} onUnCheck={this.unCheckLine.bind(this)}/></span>
				<input disabled className='set-subjectLineInput marr10' type="text" value={this.props.subject.name}/>
				<input disabled className='set-subjectLineInput marr10' type="text" value={this.props.level.name}/>
				<FontAwesomeIcon icon={faArrowRight} size='xs' />
				<input className='set-subjectLinePriceInput marh10' type="text" value={Math.floor(this.state.price/100)} onChange={this.parsePrice.bind(this)} onBlur={this.checkPrice.bind(this)}/>
				<span>€/heure</span>
				{/* <span>prix conseillé :</span>
				<span>15€/h</span> */}
			</div>
		)
	}
};

const StudentPriceInput = props => {
	return (
		<div className="set-studentPriceInput relw80 flex aic marb20">
			<div className="set-studentPriceInputImage brad_circle marr25"><img className='sage_image' src={_.get(props, 'workspace.student.profile.picture', DEFAULTIMG)}/></div>
			<div className="set-studentPriceInputTitle marr10">
				<p className="cblack classic_text bold">{_.get(props, 'workspace.student.fname')}</p>
				<span className="cgrey light fs14">{_.get(props, 'workspace.name')}</span>
			</div>
			<div className="set-studentPricesAnnounce fs12 lh15 marr30">
				Ton élève et ses parents seront automatiquement prévenus pour chaque changement de tarif.
			</div>
			<input onChange={e => props.onChangePrice(e.target.value)} onBlur={e => props.onBlurPrice(e.target.value)} className='set-studentPriceInputInput txtac marr20' type="text" value={Math.floor(_.get(props, 'workspacePrice', 1200)/100)}/>
			<span className='small_span'>€/heure</span>
		</div>
	)
};

class StudentPrices extends React.Component {
	constructor(props, context) {
		super(props, context);
		const {teacherGrade} = context;
		const workspacePrices = {};
		for (let w of props.workspaces)
			workspacePrices[w._id] = w.price;
		this.state = {
			check : false,
			sending : false,
			error : null,
			workspacePrices
		};
		this.min = 12;
		this.max = _.get(teacherGrade, 'maxPrice', 2400)/100;;
		this.avg = Math.ceil((this.min + this.max)/2);
	}

	static contextType = WebsiteContext;

	handleOnChangePrice(workspaceId) {
		return (newPrice) => {
			newPrice = purgeNonNumbers(newPrice);
			newPrice = parseInt(newPrice);
			if (isNaN(newPrice))
				newPrice = 0;
			else {
				if (newPrice > this.max)
					return;
			}
			newPrice *= 100;
			let {workspacePrices} = this.state;
			workspacePrices[workspaceId] = newPrice;
			this.setState({workspacePrices});
		}
	}

	handleOnBlurPrice(workspaceId) {
		return (newPrice) => {
			newPrice = purgeNonNumbers(newPrice);
			newPrice = parseInt(newPrice);
			if (newPrice < this.min || newPrice > this.max) {
				newPrice = this.avg;
			}
			newPrice *= 100;
			let {workspacePrices} = this.state;
			workspacePrices[workspaceId] = newPrice;
			this.setState({workspacePrices});
		}
	}

	submitPrices() {
		this.setState({sending : true, check : false});
		const {auth} = this.context;
		let prices = this.state.workspacePrices;
		api.post('/tck_workspaces/change_price', {auth, workspaceUps : prices})
		.then(suc => {
			console.log('wks up', suc);
			this.setState({sending : false, check : true});
		})
		.catch(err => {
			console.error("wks up err", err);
			this.setState({sending : false});
			getAlert({title : "Erreur", message : "Impossible de mettre à jour les prix"});
		});
	}

	render() {
		return (
			<div className="set-studentPrices relw100 flex fdc">
				<div className="set-studentPriceInputs relw100">
					{
						this.props.workspaces.map((w,i) => <StudentPriceInput
							workspace={w}
							workspacePrice={this.state.workspacePrices[w._id]}
							key={i}
							onChangePrice={(this.handleOnChangePrice(w._id)).bind(this)}
							onBlurPrice={(this.handleOnBlurPrice(w._id)).bind(this)}
						/>)
					}
				</div>
				<div className="set-studentPricesButton mart20 relw100 flex aic">
					<GreenButton className='relw20 marr35' onClick={this.submitPrices.bind(this)}>Enregistrer</GreenButton>
					{
						!!this.state.check &&
						<span className='small_span'>
							<span className='cgreen marr10'><FontAwesomeIcon icon={faCheckCircle}/></span>
							<span>Modifications sauvegardées !</span>
						</span>
					}
					{
						!!this.state.sending &&
						<span className='small_span'>
							<span><FontAwesomeIcon icon={faCircleNotch} spin/></span> 
						</span>
					}
				</div>
			</div>
		)
	}
};

const Settings_Prices = props => {
	const ctx = useContext(WebsiteContext);
	const {user, teacherGrade} = ctx;
	const subjectsT = _.get(user, 'teacherInfos.subjectsTaught', {});
	return (
		<div className="set-prices">
			<div className="set-board">
				<div className="set-boardPart">
					<p className="set-title">Tes Tarifs sur ton Annonce</p>
					<p className="set-subTitle">Fixe tes prix comme bon te semble dans une fourchette correspondant à ton niveau</p>
					<SmallAlert className='relw40 marb15'>
						<div className="flex fdc jcse">
							<p className='cblack bold fs12 lh15'>Tu es {_.get(teacherGrade, 'name', "Nouveau Sherpa")}</p>
							<p className='cblack light fs12 lh15'>Tes prix doivent être compris entre 12 et {_.get(teacherGrade, 'maxPrice', 2400)/100}€/h</p>
							{/* <a href="#" className='fs12 light lh15'>Tu pourras les augmenter en devenant Sherpa</a> */}
						</div>
					</SmallAlert>
					<p className="set-subTitle">Matières visible sur ton annonce</p>
					<div className="set-subjectLines relw100 flex fdc">
						{
							_.flattenDeep(
								Object.keys(subjectsT).map(subj => (
									Object.keys(subjectsT[subj]).map(level => {
										return (
											<SubjectLine key={`${subj}_${level}`} subject={ctx.getSubject(subj)} level={ctx.getLevel(level)} price={subjectsT[subj][level].price} wants={subjectsT[subj][level].wants}/>
										);	
									})
								))
							)
						}
					</div>
				</div>
				<div className="set-boardPart">
					<p className="set-title">Tes Tarifs par élève</p>
					<p className="set-subTitle">Fidélise tes élèves en leur proposant des réductions, ou augmente ton tarif lors d’un changement de classe</p>
					<StudentPrices workspaces={user.workspaces || []}/>
				</div>
			</div>
		</div>
	)
};
export default Settings_Prices;