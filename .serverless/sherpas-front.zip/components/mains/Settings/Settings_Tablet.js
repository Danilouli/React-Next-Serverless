import {useContext, useState} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import _ from 'lodash';
import SmallAlert from '/components/misc/SmallAlert/SmallAlert.js';
import SimpleUpload from "/components/misc/SimpleUpload/SimpleUpload.js";
import {api} from '/static/tools/network.js';
import {getError} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';


const Settings_Tablet = () => {
	const ctx = useContext(WebsiteContext);
	const {auth, user} = ctx;
	const imageSent = !!_.get(user, 'teacherInfos.tablet.image');
	const validTablet = _.get(user, 'teacherInfos.tablet.valid');
	const photoUploaded = (finalUrl, file) => {
		console.log('photoUploaded', finalUrl, file);
		api.post('tck_users/update/set', {auth, update : {'teacherInfos.tablet' : {
			image : finalUrl,
			valid : false
		}}})
		.then(suc => {
			console.log('suc tab', suc);
		})
		.catch(err => {
			console.error('err tab', err);
			getError("Il y a eu un problème pour envoyer la photo, réessayer");
		})
	};
	return (
		<div className="set-tablet">
			<div className="set-board">
				<div className="set-boardPart">
					<p className="set-title">Ta Tablette Graphique</p>
					<p className="set-subTitle">Une tablette graphique est obligatoire pour enseigner une matière Scientifique. Tu ne pourras pas être sur la Marketplace sans tablette.</p>
				</div>
				<div className="set-boardPart">
					<p className="set-title">Où acheter une Tablette ?</p>
					<SmallAlert className='relw42'>
						<p className='set-alertContent'>
							Nous te conseillons le <span className='bold'>modèle Huion 420</span>, à environ 20€ sur Amazon. Elle est rentabilisée en 1 cours en moyenne. <a href='https://amzn.to/2LQF0cS' target='_blank'>Clique ici pour acheter ta tablette sur Amazon</a>.
						</p>
					</SmallAlert>
				</div>
				<div className="set-boardPart">
					<p className="set-title">Ta tablette</p>
					{validTablet && <p className="set-subTitle">Nous avons validé ta tablette graphique ! En cas de perte ou de casse, contacte-nous.</p>}
					{!validTablet && imageSent && <p className="set-subTitle">Tu as déja téléchargé une photo de toi tenant ta tablette graphique.<br></br>Tu peux en retélécharger une en cliquant de nouveau sur le bouton.</p>}
					{!validTablet && !imageSent && <p className="set-subTitle">Télécharge une photo de toi tenant ta tablette graphique et son stylet.<br></br>Libre à toi d’utiliser une autre marque. (iPad avec l’app Sidecar et l’Apple Pen, Tablette Wacom …)</p>}
					{
						!validTablet &&
						<div className="set-uploadTabletButton relw25">
							<SimpleUpload
								statusTexts={{
									normal : "Télécharger une photo",
									success : "Fichier bien reçu",
									sending : "Veuillez patienter ..."
								}}
								onFileUploaded={photoUploaded}
								firstStatus={imageSent ? 'success' : 'normal'}
							/>
						</div>
					}
				</div>
				{/* <div className="set-boardPart">
					<div className="relw100 flex fdr aic mart25">
						<GreenButton className='relw25 marr50'>Envoyer</GreenButton>
						{sending && <SmallSuccess/>}
					</div>
				</div> */}
			</div>
		</div>
	)
};
export default Settings_Tablet;