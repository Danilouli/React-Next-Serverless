import {useContext} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import SmallAlert from '/components/misc/SmallAlert/SmallAlert.js';
import AutoCopyInput from '/components/misc/AutoCopyInput/AutoCopyInput.js';
import _ from 'lodash';

const Settings_Marketing = props => (
	<div className="set-marketing">
		<div className="set-board">
			<p className="set-title">Ton Marketing</p>
			<p className="set-subTitle">Fais-toi connaître et développe ton Business de prof particulier.</p>
			<SmallAlert className='relw65 marb40'>
				<div className="flex fdc jcse marl10">
					<p className='cblack bold fs12 lh15 marb10'>Tu as intérêt à faire ton Marketing :</p>
					<p className='cblack light fs12 lh15 marb5'>Nous prenons 15% de frais de service sur les cours des élèves que nous t’avons trouvé (10% pour faire ton Marketing, et 5% pour la plateforme de cours)</p>
					<p className='cblack bold fs12 lh15 marb5'>OU</p>
					<p className='cblack light fs12 lh15'>Nous prenons 5% de frais de service sur les cours des élèves que tu inscris via ton Profil Privé. (5% juste pour la plateforme). En plus, tu auras des élèves plus vite. CQFD !</p>
				</div>
			</SmallAlert>
			<div className="set-marketingStep">
				<p className='set-marketingStepTitle'>1. Construis une annonce Canon !</p>
			</div>
			<div className="set-marketingStep">
				<p className='set-marketingStepTitle'>2. Pars à la chasse aux élèves … avec ton numéro de téléphone.</p>
				<p className="set-marketingStepSubTitle">Bouche à oreille, petites annonces dans ton Lycée, annonces Leboncoin ou en boulangerie...</p>
			</div>
			<div className="set-marketingStep">
				<p className='set-marketingStepTitle'>3. Réponds aux appels des élèves et parents et propose leur de faire un essai via le lien.</p>
				<div className="set-marketingLink relw45 mart20">
					<AutoCopyInput/>
				</div>
			</div>
			<div className="set-marketingStep">
				<p className='set-marketingStepTitle'>4. Après un RDV de 20min gratuit, fais ton premier cours rémunéré.</p>
			</div>
			<div className="set-marketingStep">
				<p className='set-marketingStepTitle'>5. Fidélise tes élèves grâce à la plateforme et nos conseils.</p>
			</div>			
		</div>
	</div>
);

export default Settings_Marketing;
