import {useContext, useState, useEffect} from 'react';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import _ from 'lodash';
import SettingsBoard from '/components/misc/SettingsBoard/SettingsBoard.js';
import SmallAlert from '/components/misc/SmallAlert/SmallAlert.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {api} from '/static/tools/network.js';
import {faTrash, faArrowRight} from '@fortawesome/free-solid-svg-icons';
import {getError, getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';

const CardPart = props => {
	const ctx = useContext(WebsiteContext);
	const user = props.user || ctx.user;
	const [stripeCard, setStripeCard] = useState({
		__unFetched : true,
		last4 : '****',
		exp_month : '..',
		exp_year : '..',
		brand : '****'
	});
	useEffect(() => {
		console.log('ADADA', stripeCard, !stripeCard);
		if (stripeCard.__unFetched) {
			api.post('payments/list_payment_methods', {auth : ctx.auth})
			.then(suc => {
				console.log('stripe suc', suc);
				setStripeCard(_.get(suc, 'data[0].card'));
			})
			.catch(err => {
				console.log('stripe err', err);
			})
		}
	});
	return (
		!stripeCard.__unFetched && 
		<div className="set-cardPart relw100 fs10 flex jcsb aic">
			<div className="set-cardDescription bgst_beige relw45 relh100 flex jcsa aic">
				<img className='relh80' src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/cards_logos/visa.svg"/>
				<span className='light'>{stripeCard.brand} **** {stripeCard.last4}</span>
				<span className='bold'>Expire {stripeCard.exp_month}/{stripeCard.exp_year}</span>
			</div>
			{/* <p className="set-ceilingText fs10 light">Plafond mensuel sur cette carte : </p>
			<input type="text" className="set-ceilingInput txtac" placeholder="200€/mois"/> */}
			<span className="set-deleteCard cred"><FontAwesomeIcon icon={faTrash}/>&nbsp; Supprimer votre moyen de paiement</span>
		</div>
	)
};

const Settings_Payment = props => {
	const ctx = useContext(WebsiteContext);
	const {user} = ctx;
	const type = _.get(user, 'type');
	return (
		<div className="set-payment">
			<div className="set-board">
				<div className="set-boardPart">
					<p className="set-title">Paiement</p>
					{
						(type =='teacher') ?
						<p className="set-subTitle">Indique tes coordonnées bancaires (RIB et adresse de facturation), consulte tes factures, et choisi ton rythme de paiement.</p> :
						<p className="set-subTitle">Indiquez vos coordonnées bancaires, et récupérez vos factures.</p>
					}
					{
						(type != 'teacher') &&
						<SmallAlert className='relw68 marb40 padr20'>
							<div className="flex fdc jcse marl10">
								<p className="set-alertTitle">Comment se passent les paiements ?</p>
								<p className="set-alertContent marb20">
									Après chaque cours, nous multiplions la durée du cours à la minute près par le tarif auquel facture votre Sherpa. Vous êtes ensuite débité par Stripe, notre intermédiaire de paiement du montant du cours, et votre professeur est payé. La transaction est supervisée de bout en bout par la Banque Populaire.
								</p>
								<p className="set-alertTitle">Vous me prenez une commission ? </p>
								<p className="set-alertContent marb20">
									En plus du prix du cours, nous vous facturons un frais fixe de 0,46€/cours afin de couvrir les frais de fonctionnement de la plateforme. Pas de commission sinon. 
								</p>
								<p className="set-alertTitle">Ma carte est-elle en sécurité ? </p>
								<p className="set-alertContent marb20">
									Évidemment ! Nous ne détenons pas vos coordonnées bancaires : elles sont cryptées en 128-SSL par la Banque Populaire qui réutilise en notre nom votre empreinte  de carte à chaque fois que vous payez un cours.
								</p>
								<p className="set-alertTitle">Je n’ai besoin de saisir qu’une fois ma carte bleue ? </p>
								<p className="set-alertContent">
									Comme chez nombre de sites marchands, oui. Nous nous réservons le droit d’effectuer des vérifications anti-fraude. Vous devrez alors vous identifier par 3D Secure pour continuer de prendre des cours. 
								</p>
							</div>
						</SmallAlert>
					}
				</div>
				{
					(type == 'teacher') &&
					<div className="set-boardPart">
						<p className="set-title">Rythme et montants des virements</p>
						<SmallAlert className='relw68 marb40'>
							<div className="flex fdc jcse marl10">
								<p className="set-alertTitle">Tu es automatiquement payé(e) après chaque journée de cours.</p>
								<p className="set-alertContent marb20">
									En moyenne, ton argent prendra 7 jours ouvrés pour atteindre le compte lié à ton RIB.
								</p>
								<p className="set-alertTitle marb20">
									Notre intermédiaire de paiement prend une commission de 0.67€ et 1,65% du montant versé.
								</p>
								<p className="set-alertContent">
									<span className='bold'>S’ajoutent enfin nos frais de service : </span> 15%, si nous t’avons trouvé ton élève, ou 5% si tu as incris ton élève via ton annonce privée. <a href="#">Voici comment trouver tes élèves.</a> 
								</p>
							</div>
						</SmallAlert>
					</div>
				}
				{
					(type == 'teacher') &&
					<div className="set-boardPart">
						<SmallAlert className='relw68 marb40'>
							<div className="flex fdc jcse marl10">
								<p className="set-alertContent">
									Nous acceptons seulement les <span className='bold'>adresses françaises</span>. Si tu ne peux pas en avoir, contacte-nous.
								</p>
							</div>
						</SmallAlert>
						<div className="set-paymentRib relw80">
							<SettingsBoard
								title="Ton RIB et adresse"
								subtitle={false}
								sendText={<span>Enregistrer</span>}
								inputs={[
									[
										// {
										// 	value : 'country',
										// 	label : 'Pays',
										// 	placeholder : "France",
										// 	type : 'select',
										// 	options : [
										// 		{name: 'Australie', value: 'AU'},
										// 		{name: 'Autriche', value: 'AT'},
										// 		{name: 'Belgique', value: 'BE'},
										// 		{name: 'Brésil ', value: 'BR'},
										// 		{name: 'Canada', value: 'CA'},
										// 		{name: 'Danmark', value: 'DK'},
										// 		{name: 'Finlande', value: 'FI'},
										// 		{name: 'France', value: 'FR'},
										// 		{name: 'Allemagne', value: 'DE'},
										// 		{name: 'Hong Kong', value: 'HK'},
										// 		{name: 'Irelande', value: 'IE'},
										// 		{name: 'Japon', value: 'JP'},
										// 		{name: 'Luxembourg', value: 'LU'},
										// 		{name: 'Mexique ', value: 'MX'},
										// 		{name: 'Pays-Bas', value: 'NL'},
										// 		{name: 'Nouvelle Zélande', value: 'NZ'},
										// 		{name: 'Norwège', value: 'NO'},
										// 		{name: 'Singapour', value: 'SG'},
										// 		{name: 'Espagne', value: 'ES'},
										// 		{name: 'Suède', value: 'SE'},
										// 		{name: 'Suisse', value: 'CH'},
										// 		{name: 'Royaume Uni', value: 'GB'},
										// 		{name: 'États Unis', value: 'US'},
										// 		{name: 'Italie', value: 'IT'},
										// 		{name: 'Portugal', value: 'PT'}
										// 	],
										// 	defaultValue : _.get(user, 'profile.payment.address.country', 'FR')
										// },
										{
											value : 'line1',
											label : 'Adresse',
											placeholder : _.get(user, 'profile.payment.address.line1', "10 Rue des Petits Champs")
										}
									],
									[
										{
											value : 'zipCode',
											label : 'Code postal',
											placeholder : _.get(user, 'profile.payment.address.zipCode', '75000')
										},
										{
											value : 'city',
											label : 'Ville',
											placeholder : _.get(user, 'profile.payment.address.city', 'Paris')
										}
									],
									[
										{
											value : 'iban',
											label : 'IBAN',
											placeholder : _.get(user, 'profile.payment.iban', 'FR **********************')
										}
									]
								]}
								beforeSend={e => {
									return {
										address : {
											country : e.country || 'FR',
											city : e.city,
											zipCode : e.zipCode,
											line1 : e.line1
										},
										iban : e.iban
									}
								}}
								submitUrl={'tck_users/teachers/set_stripe_external_account_and_legal_entity'}
								onSubmitSuccess={() => getAlert("Informations de paiement mises à jour")}
								onSubmitError={() => getError("Problème pour enregistrer les informations de paiement")}
							/>
						</div>
					</div>
				}
				{
					(type != 'teacher') &&
					<div className="set-boardPart">
						<p className="set-title">Votre moyen de paiement</p>
						<CardPart/>
						{/* <a href="#" className='fs12 mart25'><FontAwesomeIcon icon={faArrowRight} size='xs'/>&nbsp; Modifier votre moyen de paiement</a> */}
					</div>
				}
				{/* <div className="set-boardPart"></div>
				<div className="set-boardPart"></div> */}
			</div>
		</div>
	);
};
export default Settings_Payment;