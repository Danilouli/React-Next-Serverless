import Link from 'next/link';
import LinksBoard from '/components/misc/LinksBoard/LinksBoard.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {useContext} from 'react';
import _ from 'lodash';

const Landing_Links = props => {
	const ctx = useContext(WebsiteContext);
	const subjects = _.get(ctx, 'lang.subjects');
	const seoLevels = _.get(ctx, 'lang.seo_levels');
	const onBoardSubjs = subjects.filter(s=>_.get(s, 'metadata.onBoard'));
	const subjLinks = onBoardSubjs.map(s=>({
		name : s.name,
		as : `/cours/${s.value}`,
		url : `/course_seo_page?param1=${s.value}`
	}));
	subjLinks.push({
		name : "Voir +",
		url : "/gallery",
		as : "/professeurs"
	});
	const levelLinks = seoLevels.map(s=>({
		name : s.name,
		as : `/cours/${s.value}`,
		url : `/course_seo_page?param1=${s.value}`
	}));
	levelLinks.push({
		name : "Voir +",
		url : "/gallery",
		as : "/professeurs"
	});
	return (
		<div className='lan-links large_vertical_part'>
			<div className='lan-linksContent relw100 flex jcse fdc aic'>
				<div className='lan-linksContent txtac relw100 mob__relw85 mob__txtal'>
					<div className='tryptiq'>
						<h2 className='cb30 cblue padh16vw'>
							Des cours pour tous, <span className='cgreen'>au Collège, Lycée, Prépa et dans le Supérieur</span>
						</h2>
						<p className='classic_text light padh22vw'>
							Les cours particuliers en ligne sont pratiques et flexibles, et s’intègrent parfaitement à votre vie de famille.
						</p>
						<Link href="/gallery" as="/professeurs" passHref>
							<a className='lan-howItWorksLink'>Trouvez un Sherpa <FontAwesomeIcon size='xs' icon={faArrowRight}/></a>
						</Link>
					</div>
				</div>
			</div>
			<div className='lan-linksBoard relw47 mart50 mob__relw90'>
				<h2 className='cb30 cblue marb20'>
					Matière
				</h2>
				<LinksBoard
					links={subjLinks}
				/>
			</div>
			<div className='lan-linksBoard relw47 mart50 mob__relw90'>
				<h2 className='cb30 cblue marb20'>
					Niveau
				</h2>
				<LinksBoard
					links={levelLinks}
				/>
			</div>
		</div>
	);

}
export default Landing_Links;