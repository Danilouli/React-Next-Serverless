import SocialProofs from '/components/misc/SocialProofs/SocialProofs.js';

const Landing_SocialProofs = props => (
	<div className="lan-socialProofs relw70 padt70 padb20">
		<SocialProofs/>
	</div>
);
export default Landing_SocialProofs;