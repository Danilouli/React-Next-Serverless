import Link from 'next/link';
import SmallTeacherCard from '/components/misc/SmallTeacherCard/SmallTeacherCard.js';
import FindATeacherSmallCards from '/components/misc/FindATeacherSmallCards/FindATeacherSmallCards.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';

const Landing_HowItWorks = props => (
	<div className='lan-howItWorks relw72 padv60'>
		<h2 className="classic_h2 relw100 flex jcc aic marb50">
			Comment ça marche ?
		</h2>
		<FindATeacherSmallCards
			h2={<span>Sélectionnez <span className='cgreen'>un Sherpa</span> avec les compétences dont vous avez besoin</span>}
			p={<span>Nous sélectionnons avec soin nos Sherpas parmi les étudiants et jeunes diplômés des meilleures universités et grandes écoles. Seul 1 candidat sur 7 est sélectionné. Nos Sherpas vivaient la même chose que votre enfant il y a peu. Ils sauront se comprendre.</span>}
		/>
	</div>
);
export default Landing_HowItWorks;

