import './Landing.scss';
import Landing_Schools from './Landing_Schools.js';
import Landing_HowItWorks from './Landing_HowItWorks.js';
import Landing_Results from './Landing_Results.js';
import Landing_Links from './Landing_Links.js';
import Landing_NoTime from './Landing_NoTime.js';
import Landing_AppPart from './Landing_AppPart.js';
import Landing_SocialProofs from './Landing_SocialProofs.js';
import TextAndImageSide from '/components/misc/TextAndImageSide/TextAndImageSide.js';
import TeachersCarousel from '/components/misc/TeachersCarousel/TeachersCarousel.js';
import FindTeacherBoardHeader from '/components/misc/FindTeacherBoardHeader/FindTeacherBoardHeader.js';
import {studentReviews} from '/static/data/carousel_cards.js';

class Landing extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div className='Landing'>
				<FindTeacherBoardHeader/>
				<div className='lan-body large_vertical_part'>
					<Landing_Schools/>
					<Landing_HowItWorks/>
					<TextAndImageSide 
						className='lan-meeting mob__relw85 mob__marb30'
						p={"Posez toutes vos questions et expliquez vos attentes. Une fois le courant passé, prenez des cours particuliers en ligne, où vous voulez, quand vous voulez. À la maison, chez mamie, ou en vacances, tout est permis !"}
					/>
					<Landing_Results/>
				</div>
				<div className="lan-carousel marb70 mart20 mob__mart0">
					<TeachersCarousel
						cards={studentReviews}					
					/>
				</div>
				<div className='lan-body large_vertical_part'>
					<Landing_Links/>
					<Landing_NoTime/>
					<Landing_AppPart/>
					<Landing_SocialProofs/>
				</div>
			</div>
		)
	}
};
export default Landing;