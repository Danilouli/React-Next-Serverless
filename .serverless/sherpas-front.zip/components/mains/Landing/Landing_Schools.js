const Landing_Schools = props => (
	<div className='lan-schools large_vertical_part'>
		<p className='lan-schoolsTitle txtac cr16 mob__padh10'>
			Nos professeurs viennent des meilleures écoles de France
		</p>
		<div className='lan-schoolsLogos relw100 flex jcc aic fww'>
			<img className='lan-schoolLogo' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/polytechnique.png'></img>
			<img className='lan-schoolLogo' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/hec.png'></img>
			<img className='lan-schoolLogo' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/ens.png'></img>
			<img className='lan-schoolLogo' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/centralesup.png'></img>
			<img className='lan-schoolLogo' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/mines.png'></img>
			<img className='lan-schoolLogo' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/essec.png'></img>
			<img className='lan-schoolLogo' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/dauphine.png'></img>
			<img className='lan-schoolLogo' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/sciencespo.png'></img>
		</div>
	</div>
);
export default Landing_Schools;