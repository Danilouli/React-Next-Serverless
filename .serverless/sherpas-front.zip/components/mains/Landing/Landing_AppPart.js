const Landing_AppPart = props => (
	<div className='lan-appPart large_vertical_part bgst_beige padt60 mart100 mob__hide'>
		<div className='lan-appPartContainer relw60 flex jcc'>
			<div className='lan-appImage flex'>
				<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/app_on_phone.svg'></img>
			</div>
			<div className='lan-appText flex fdc jcse marl70'>
				<h2 className='classic_h2'>Votre Sherpa toujours dans votre poche</h2>
				<p className='classic_text light'> Entre les cours, discutez et partagez des documents avec votre professeur grâce à notre application mobile.</p>
				<div className='lan-appStoreLogos'>
					<img className='marr5' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/playstore.svg'></img>
					<img className='marl5' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/appstore.svg'></img>
				</div>
			</div>
		</div>
	</div>
);
export default Landing_AppPart;