import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faChartLine} from '@fortawesome/free-solid-svg-icons';

const Landing_Results = props => (
	<div className='lan-results large_vertical_part mart65'>
		<div className='lan-resultsContent relw78 flex jcfs aifs fdc'>
			<div className='lan-resultsLogo'>
				<FontAwesomeIcon icon={faChartLine}/>
			</div>
			<div className='lan-resultsText'>
				<div className='tryptiq'>
					<h2 className='cb30'>
						L'an dernier, nos élèves ont gagné <span className='cgreen'>4 points</span> en moyenne. Et ce n’est que le début !
					</h2>
					<p className='rl20'>
						85% de nos élèves disent que Les Sherpas ont augmenté leur confiance en eux à l’école. Ils participent,<br></br> posent plus de questions, et apprécient davantage les cours. 
					</p>
				</div>
			</div>
		</div>
	</div>
);
export default Landing_Results;
