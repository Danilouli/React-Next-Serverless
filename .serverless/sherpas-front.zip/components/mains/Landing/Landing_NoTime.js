import WhiteButton from '/components/misc/WhiteButton/WhiteButton.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight, faPhone} from '@fortawesome/free-solid-svg-icons';
import {useState} from 'react';

const Landing_NoTime = props => {
	const [tel, setTel] = useState(false);
	return (
		<div className='lan-noTime large_vertical_part mart80'>
			<div className='lan-noTimeContent relw100 flex jcse fdc aic'>
				<div className='lan-noTimeImage'>
					<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/clock-7.svg'></img>
				</div>
				<h2 className='cb26 mart25 mob__relw85 mob__fs24'>Pas le temps de chercher un Professeur Particulier ?</h2>
				<p className='classic_text light relw30 txtac marv15 mob__relw85 mob__txtal'>Dites-nous quel genre de prof particulier vous souhaitez, nous vous mettrons en contact au plus vite.</p>
				<WhiteButton className='mart60' onClick={()=>setTel(true)}>
					{
						tel ? 
						<span>Appelez nous au 09 73 05 06 70</span> : 
						<span>Expliquez-nous votre besoin</span>
					}
				</WhiteButton>
			</div>
		</div>
	)
};
export default Landing_NoTime;