import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import './LandingNavbar.scss';
import Link from 'next/link';
import MobileNavbar from '/components/layouts/MobileNavbar/MobileNavbar.js'
import Dynamic from 'next/dynamic';
import MediaQuerySSR from 'react-responsive';
const MediaQuery = Dynamic(() => Promise.resolve(MediaQuerySSR), {
	ssr: false
});

class LandingNavbar extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div className='LandingNavbar'>
				<MediaQuery query="(min-width: 1200px)">
					<div className='logoAndLinks'>
							<div className='logo'>
								<Link href='/landing' as='/' passHref>
									<a>
										<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/sherpas_white_logo.png'></img>
									</a>
								</Link>
							</div>
						<div className='links'>
							<Link href='/gallery' as='/professeurs' passHref>
								<a className='link'>Trouver un Prof</a>
							</Link>
							<Link href='/how_it_works' as='/comment-ca-marche'>
								<a className='link'>Comment ça marche ?</a>
							</Link>
							<Link href='/prices' as='/tarifs'>
								<a className='link'>Tarifs</a>
							</Link>
							<a href="https://blog.les-sherpas.co" className='link'>Blog</a>
						</div>
					</div>
					<div className='moreLinks'>
						<div className='hmnv-becomeTeacherLink'>
							<Link href='/become_teacher' as='/donner-cours-particuliers' passHref>
								<a className='link'>Devenir Prof</a>
							</Link>
						</div>
						<span>|</span>
						<Link href='/login' passHref>
							<a className='link'>Connexion</a>
						</Link>
						<Link href='/gallery' as='/professeurs' passHref>
							<a className='link'>Inscription <FontAwesomeIcon icon={faArrowRight} size='xs'/></a>
						</Link>
					</div>
				</MediaQuery>
				<MediaQuery query="(max-width: 1200px)">
					<MobileNavbar/>
				</MediaQuery>
			</div>
		)
	}
};
export default LandingNavbar;