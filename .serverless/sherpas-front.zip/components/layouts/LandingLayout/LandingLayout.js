import LandingNavbar from './LandingNavbar.js';
import Footer from '/components/layouts/Footer/Footer.js';
import './LandingLayout.scss';
import Head from 'next/head';
import {IN_PROD} from '/static/tools/network.js';

const LandingLayout = props => (
	<div className='LandingLayout'>
		{
			!IN_PROD &&
			<Head>
				<meta name="robots" content="noindex, nofollow"/>
			</Head>
		}
		<LandingNavbar/>
		<div className='subLandingNavbar'>
			{props.children}
			<Footer/>
		</div>
	</div>
);

export default LandingLayout;