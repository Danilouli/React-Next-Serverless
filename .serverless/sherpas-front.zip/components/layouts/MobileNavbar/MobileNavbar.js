import './MobileNavbar.scss';
import {useState, useContext} from 'react';
import Link from 'next/link';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faTimes} from '@fortawesome/free-solid-svg-icons';

const MobileNavbarLink = props => {
	const context = useContext(WebsiteContext);
	return (
		<div className='mobn-linkContainer' active={`${context.page == props.href}`}>
			{
				props.as ?
				<Link href={"/"+props.href} as={props.as} passHref>
					<a className='link'>{props.pageName}</a>
				</Link> :
				<Link href={"/"+props.href} passHref>
					<a className='link'>{props.pageName}</a>
				</Link>
			}
		</div>
	);
};

const MobileNavbar = props => {
	const [opened, open] = useState(false);
	return (
		<div className='MobileNavbar'>
			{
				!opened &&
				<div className='relw100 relh100 flex jcse aic'>
					<div className="mobn-mobileToggle" onClick={()=>open(true)}>Menu</div>
					<div className='mobn-mobileLogo'>
						<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/logo_horizontal.png'></img>
					</div>
				</div>
			}
			{
				opened && 
				<div className='relw100 relh100 mobn-links'>
					<span className='mobn-close' onClick={()=>open(false)}><FontAwesomeIcon icon={faTimes}/></span>
					<div className='relw100 relh100 flex fdc jcse aic'>
						<MobileNavbarLink href='landing' as='/' pageName="Accueil"/>
						<MobileNavbarLink href='gallery' as='/professeurs' pageName="Trouver un professeur"/>
						<MobileNavbarLink href='prices' as='/tarifs' pageName="Tarifs"/>
						<MobileNavbarLink href='how_it_works' as='/comment-ca-marche' pageName="Comment ça marche ?"/>
						<MobileNavbarLink href='become_teacher' as='/donner-cours-particuliers' pageName="Devenir prof"/>
						<a className='link cgrey' href="https://blog.les-sherpas.co" className='link'>Blog</a>
					</div>
				</div>
			}
		</div>
	)
};
export default MobileNavbar;