import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {useContext} from 'react';
import {faEnvelope} from '@fortawesome/free-regular-svg-icons';
import './Navbar.scss';
import Link from 'next/link';
import Dynamic from 'next/dynamic';
import MediaQuerySSR from 'react-responsive';
import _ from 'lodash';
const MediaQuery = Dynamic(() => Promise.resolve(MediaQuerySSR), {
	ssr: false
});
import MobileNavbar from '/components/layouts/MobileNavbar/MobileNavbar.js';
import {DEFAULTIMG} from '/static/tools/tools.js';

const NavbarLink = props => {
	const context = useContext(WebsiteContext);
	return (
		<div className='nav-linkContainer' active={`${context.page == props.href}`}>
			{
				props.as ?
				<Link href={"/"+props.href} as={props.as} passHref>
					<a className='link'>{props.pageName}</a>
				</Link> :
				<Link href={"/"+props.href} passHref>
					<a className='link'>{props.pageName}</a>
				</Link>
			}
		</div>
	);
};


class Navbar extends React.Component {
	constructor(props) {
		super(props);
	}

	static contextType = WebsiteContext;

	render() {
		const {user} = this.context;
		const workspaceL = _.get(user, 'workspaces.length', 0);
		return (
			<div className='Navbar' fixed={`${this.props.fixed}`}>
				<MediaQuery query="(min-width: 1200px)">
					<div className="nav-main relw100 flex aic">
						<div className='logoAndLinks relh100'>
							<div className='logo'>
								<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/logo_horizontal.png'></img>
							</div>
							<div className='links relh100 flex fdr'>
								{!user && <NavbarLink href='landing' as='/' pageName="Accueil"/>}
								{!!user && <NavbarLink href='home' as='/' pageName="Accueil"/>}
								{_.get(user, 'type') != 'teacher' && <NavbarLink href='gallery' as='/professeurs' pageName="Trouver un sherpa"/>}
								{!!user && (workspaceL > 0) && <NavbarLink href='chat' pageName="Messages"/>}
								{/* <div className="nav-linkContainer">
									<Link href="/gallery" as='/professeurs' passHref>
											<a className='link'>Trouver un sherpa</a>
									</Link>
								</div>
								<div className='nav-linkContainer' active={`${this.context.page == 'chat'}`}>
									<Link href="/chat" passHref>
											<a className='link'>Messages</a>
									</Link>
								</div> */}
								{/* <Link href="#">
									<a className='link'>Mes cours</a>
								</Link> */}
							</div>
						</div>
						{
							!!user &&
							<div className='profileAndMessages'>
								{
									(workspaceL > 0) && <Link href='/chat' passHref>
										<a className='messages'>
											<FontAwesomeIcon icon={faEnvelope}/>
										</a>
									</Link>
								}
								<Link href='/settings' passHref>
									<a className='imageAndProfile cgrey calm_link'>
										<img src={_.get(user, 'profile.picture', DEFAULTIMG)}></img>
										<span className='profileName'>{user.fname}</span>
									</a>
								</Link>
							</div>
						}
					</div>
				</MediaQuery>
				<MediaQuery query="(max-width: 1200px)">
					<MobileNavbar/>
				</MediaQuery>
			</div>
		)
	}
};
export default Navbar;