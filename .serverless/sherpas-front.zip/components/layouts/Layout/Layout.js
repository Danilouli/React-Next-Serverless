import Navbar from './Navbar.js';
import Footer from '/components/layouts/Footer/Footer.js';
import Head from 'next/head';
import {IN_PROD} from '/static/tools/network.js';

const layoutStyle = {
	margin: 0,
	padding: 0,
	position : 'relative',
	height: '100vh',
	width: '100vw',
	overflowX: 'hidden',
	overflowY: 'auto'
};

const Layout = props => (
	<div style={layoutStyle} className='flex fdc Layout'>
		{
			!IN_PROD &&
			<Head>
				<meta name="robots" content="noindex, nofollow"/>
			</Head>
		}
		<div id='__the_notification_container' className='notification_container'></div>
		<div className="layout-main relw100">
			<Navbar fixed={props.fixedNavbar}/>
			<div className='subNavbar'>
				{props.children}
				{!props.noFooter && <Footer/>}
			</div>
		</div>
	</div>
);
Layout.defaultProps = {
	noFooter : false,
	fixedNavbar : true
}

export default Layout;