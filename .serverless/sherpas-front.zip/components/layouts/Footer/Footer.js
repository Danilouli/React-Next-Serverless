import Link from 'next/link';
import './Footer.scss';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faTwitter, faYoutube, faFacebookF, faInstagram} from '@fortawesome/free-brands-svg-icons';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import Dynamic from 'next/dynamic';
import MediaQuerySSR from 'react-responsive';
const MediaQuery = Dynamic(() => Promise.resolve(MediaQuerySSR), {
	ssr: false
});

const Footer = props => (
	<div className='Footer'>
		<div className="foot-columns">
			<div className="foot-logo foot-column">
				<Link passHref href='/home'><a><img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/green_logo_1.svg'></img></a></Link>
			</div>
			<div className="foot-linksColumn foot-column">
				<Link passHref href='/gallery' as='/professeurs'><a>Inscription</a></Link>
				<Link passHref href='/login'><a>Connexion</a></Link>
				<a href='https://blog.les-sherpas.co' target='_blank'>Blog</a>
				<Link passHref href='/how_it_works' as='/comment-ca-marche'><a>Comment ça marche</a></Link>
				<Link passHref href='/become_teacher' as='/donner-cours-particuliers'><a>Devenir Sherpa</a></Link>
				<Link passHref href='/prices' as='/tarifs'><a>Prix</a></Link>
				{/* <Link href='#'><a href="#">Aide</a></Link> */}
			</div>
			{/* <div className="foot-newsl foot-column">
				<p className='foot-subTitle'>Newsletter</p>
				<p className='foot-subTitle'>Support</p>
				<Link href='#'><a href="#">Foire aux questions</a></Link>
				<Link href='#'><a href="#">Mentions légales</a></Link>
				<Link href='#'><a href="#">Dossier de presse</a></Link>
				<Link href='#'><a href="#">CGU</a></Link>
			</div> */}
			<MediaQuery query="(min-width: 1200px)">
				<div className="foot-help foot-column">
					<p className='foot-bigSubTitle'>Besoin d'aide ?</p>
					<p className='foot-subTitle'>+33 9 73 05 06 70</p>
					<a href="mailto:support@les-sherpas.co">support@les-sherpas.co</a>
					<a href="mailto:support@les-sherpas.co" className='relw100 flex aic jcc'>
						<GreenButton>
							Contactez-nous !
						</GreenButton>
					</a>
					<div className='foot-socialIcons'>
						<a href="https://www.facebook.com/lessherpas/" target='_blank'><FontAwesomeIcon icon={faFacebookF}/></a>
						<a href="https://www.instagram.com/les_sherpas/" target='_blank'><FontAwesomeIcon icon={faInstagram}/></a>
						<a href="https://www.youtube.com/channel/UCaki-fxlvKI7Yc--vv-b2Yw" target='_blank'><FontAwesomeIcon icon={faYoutube}/></a>
					</div>
				</div>
			</MediaQuery>
		</div>
		<div className="foot-love">© Les Sherpas. Fait avec ❤️ et ☕️ à Paris, France.</div>
	</div>
);
export default Footer;