import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import './MaterialSelect.scss';

const MaterialSelect = (props) => {
	return (
		<div className={`MaterialSelect ${props.className || ''}`}>
			<FormControl>
				<Select
					value={props.selectedValue}
					onChange={props.onChange}
				>
				{props.placeholder && 
					<MenuItem value='placeholder' disabled>
						{props.placeholder}
					</MenuItem>
				}
				{props.items.map(item => <MenuItem value={item.value} key={item.value}>{item.name || item.value}</MenuItem>)}
				</Select>
			</FormControl>
		</div>
	)
};
export default MaterialSelect;