import { withStyles } from '@material-ui/core/styles';
import FormLabel from '@material-ui/core/FormLabel';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import _ from 'lodash';

const OurCheckbox = withStyles({
	root: {
		color: 'var(--green)',
		'&$checked': {
			color: 'var(--green)',
		},
	},
	checked: {},
})(props => <Checkbox color="default" {...props} />);

class MaterialCheckboxes extends React.Component {
	constructor(props) {
		super(props);
		let toUp = {};
		for (let label of this.props.labels) {
			toUp[label.value] = label.default;
		}
		this.state = toUp;
	}

	handleChange = label => (() => {
		this.setState({
			[label] : !this.state[label]
		}, () => {
			if (this.props.uniq && this.state[label]) {
				let otherLabels = this.props.labels.filter(e => e.value != label);
				let toUp = {};
				for (let l of otherLabels) {
					toUp[l.value] = false;
				}
				this.setState(toUp, this.props.onValueChanged(this.state));
			}
			else
				this.props.onValueChanged(this.state);
		});
	});

	render() {
		let i =0;
		return (
			<div className={`MaterialCheckboxes ${this.props.className || ''}`}>
				<FormControl component="fieldset">
					<FormLabel component="legend">Genre du professeur</FormLabel>
						<FormGroup>
							{this.props.labels.map(label => (
								<FormControlLabel
									control={
									<OurCheckbox 
										checked={this.state[label.value]}
										onChange={this.handleChange(label.value).bind(this)}
										value={label.value}
									/>}
									label={label.name}
									key={i++}
								/>
							))}
						</FormGroup>
				</FormControl>
			</div>
		);
	}
};
export default MaterialCheckboxes;