import './TeachersList.scss';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faCircleNotch} from  '@fortawesome/free-solid-svg-icons';
import TeacherCard from '/components/misc/TeacherCard/TeacherCard.js';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';

const TeachersList = props => (
	<div className={`TeachersList ${props.className || ''}`}>
		<div className='tchl-list relw100'>
			{
				props.teachers.length ?
				props.teachers.map((teacher, i) => <TeacherCard teacher={teacher} filters={props.filters} key={i}/>) :
				<span className='tchl-teachersLoader'><FontAwesomeIcon icon={faCircleNotch} spin/></span>
			}
		</div>
		{
			props.more &&
			<div className="tchl-moreButton relw30 flex jcc aic mart50">
				<GreenButton linkTo='/gallery' linkToAs='/professeurs'>
					Voir plus de professeurs
				</GreenButton>
			</div>	
		}
	</div>
);
TeachersList.defaultProps = {
	teachers : [],
	filters : {},
	more : false,
	handleOnMore : e=>e
};
export default TeachersList;