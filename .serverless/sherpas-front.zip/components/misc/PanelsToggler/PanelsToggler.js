import './PanelsToggler.scss';
import {useState} from 'react';
import _ from 'lodash';

const PanelsToggler = props => {
	const [panel, setPanel] = useState(Object.keys(props.panels)[0]);

	return (
		<div className={`PanelsToggler relw100 flex fdc ${props.className}`}>
			<div className="pant-toggles relw100 flex jcse aic">
				{
					Object.keys(props.panels).map(panelKey => (
						<div key={panelKey} className="pant-toggle" onClick={() => setPanel(panelKey)} active={`${panelKey == panel}`}>
							{_.get(props.panels[panelKey], 'name')}
						</div>
					))
				}
			</div>
			<div className="pant-panels relw100">
				{_.get(props.panels[panel], 'content')}
			</div>
		</div>
	)
};
PanelsToggler.defaultProps = {
	panels : {},
};
export default PanelsToggler;