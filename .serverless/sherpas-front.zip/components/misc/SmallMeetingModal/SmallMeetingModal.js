import SmallMeeting from "/components/misc/SmallMeeting/SmallMeeting.js";
import _ from 'lodash';
import SmallAlert from "/components/misc/SmallAlert/SmallAlert.js"
import ClassicModal from "/components/misc/ClassicModal/ClassicModal.js";
import Bus from '/static/tools/bus.js';

const SmallMeetingModal = props => {
	let cannotSendReminder = !_.get(props, 'user.devInfos.stripeCustomerId') && _.get(props, 'user.type') != 'teacher';
	return (
		<ClassicModal
			className={`SmallMeetingModal ${props.className}`}
			title={props.title}
			close={true}	
			content={
				<div className='relw100'>
				{
					cannotSendReminder && 
					<SmallAlert className='marb20'>
						<div className='flex fdc relw100'>
							Afin d’assurer le sérieux de votre demande de cours, une carte de crédit doit être liée a votre compte.<br></br><a href='#' className='mart5' onClick={Bus.fcast('show_card_modal')}>Cliquer ici pour lier une carte a votre compte.</a>
						</div>
					</SmallAlert>
				}
				<SmallMeeting
					reminder={props.reminder}
					meetWho={props.meetWho}
					workspace={props.workspace}
					user={props.user}
				/>
				</div>
			}
		/>
	)
};
SmallMeetingModal.defaultProps = {
	title : "Votre proposition de cours avec Marie Antoinette"
};
export default SmallMeetingModal;