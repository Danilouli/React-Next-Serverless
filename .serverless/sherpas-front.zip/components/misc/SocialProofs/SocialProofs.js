import './SocialProofs.scss';

const SocialProofs = props => (
	<div className={`SocialProofs flex relw100 jcse aic fww mob__padh15 mob__bsbb ${props.className || ''}`}>
		<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/bfm.png"/>
		<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/figaro_madame.png"/>
		<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/challenge.png"/>
		<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/frenchWeb.png"/>
		<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/techCrunch.png"/>
		<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/konbini.png"/>
		<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/fr3.png"/>
	</div>
);
export default SocialProofs;