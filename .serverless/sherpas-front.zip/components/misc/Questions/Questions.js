import './Questions.scss';

const Question = props => (
	<div className="Question flex jcsb marv20">
		<div className="quest-logo flex jcc aic brad_circle bgpale_green marr30">
			?
		</div>
		<div className="quest-content flex fdc">
			<h3 className="camphor bold fs20 cblue marb15">
				{props.h3}
			</h3>
			<p className="roboto light fs16 cgrey">
				{props.p}
			</p>
		</div>
	</div>
);
const Questions = props => (
	<div className="Questions relw100 flex fww jcse bsbb">
		{
			props.questions.map((q,i) => <Question key={i} h3={q.h3} p={q.p}/>)
		}
	</div>
);
Questions.defaultProps = {
	questions : [
		{h3 : "Quelles conditions pour devenir Sherpa ?",
		p:"Une fois que vous avez trouvé un profil de Professeur qui vous plaît, vous pouvez le rencontrer pendant un RDV gratuit de 20 min pour lui poser toutes vos questions."},
		{h3 : "Quelles conditions pour devenir Sherpa ?",
		p:"Une fois que vous avez trouvé un profil de Professeur qui vous plaît, vous pouvez le rencontrer pendant un RDV gratuit de 20 min pour lui poser toutes vos questions."},
		{h3 : "Quelles conditions pour devenir Sherpa ?",
		p:"Une fois que vous avez trouvé un profil de Professeur qui vous plaît, vous pouvez le rencontrer pendant un RDV gratuit de 20 min pour lui poser toutes vos questions."},
		{h3 : "Quelles conditions pour devenir Sherpa ?",
		p:"Une fois que vous avez trouvé un profil de Professeur qui vous plaît, vous pouvez le rencontrer pendant un RDV gratuit de 20 min pour lui poser toutes vos questions."},
		{h3 : "Quelles conditions pour devenir Sherpa ?",
		p:"Une fois que vous avez trouvé un profil de Professeur qui vous plaît, vous pouvez le rencontrer pendant un RDV gratuit de 20 min pour lui poser toutes vos questions."},
		{h3 : "Quelles conditions pour devenir Sherpa ?",
		p:"Une fois que vous avez trouvé un profil de Professeur qui vous plaît, vous pouvez le rencontrer pendant un RDV gratuit de 20 min pour lui poser toutes vos questions."},
	]
}

export default Questions;