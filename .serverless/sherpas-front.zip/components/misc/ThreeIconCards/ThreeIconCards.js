import IconCard from '/components/misc/IconCard/IconCard.js';
import './ThreeIconCards.scss';

const ThreeIconCards = props => {
	let i = 0;
	return (
		<div className={`ThreeIconCards relw100 bsbb flex fdr mob__fdc jcse aic ${props.className || ''}`}>
			{props.iconCards.map(iconCard => (
				<div className='tcwi-iconCard' key={i++}>
					<IconCard {...iconCard}/>
				</div>
			))}
		</div>
	)
};
ThreeIconCards.defaultProps = {
	iconCards : [
		{
			color : 'yellow',
			icon : 'desktop',
			title : "Donne cours où tu veux, quand tu veux.",
			text : "Pas besoin de te déplacer, c’est pratique et flexible. Stylé.",
		},
		{
			color : 'green',
			icon : 'heart',
			title : "Quoi de mieux que d’aider quelqu’un à se dépasser ?",
			text : "Tu vas aussi développer des qualités appréciées pour ton CV !",
		},
		{
			color : 'blue',
			icon : 'card',
			title : "Gagne de l’argent pour payer tes factures.",
			text : "C’est un des jobs étudiants les mieux payés. Finance tes sorties et tes vacances.",
		}
	]
};
export default ThreeIconCards;