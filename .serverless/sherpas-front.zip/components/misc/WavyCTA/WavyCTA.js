import './WavyCTA.scss';
import ClassicButton from '/components/misc/ClassicButton/ClassicButton.js';

const WavyCTA = props => (
	<div className={`WavyCTA relw100 flex fdc bsbb padv20 padh30 brad_medium ${props.className}`}>
		<p className="classic_text cwhite">{props.title}</p>
		<p className="mini_text cwhite">{props.text}</p>
		<ClassicButton type='blank' linkTo={props.buttonLink} className='relw30 mini_text mart10'>
			<span className='cblack'>{props.button}</span>
		</ClassicButton>
	</div>
);
WavyCTA.defaultProps = {
	title : "Tu veux plus d'élèves ? Diffuse ton annonce et suis nos conseils !",
	text : "Moins de temps d’attente, et seulement 5% de frais de service : que demande le peuple ?",
	button : "Diffuser mon annonce",
	buttonLink : '#'
}
export default WavyCTA;