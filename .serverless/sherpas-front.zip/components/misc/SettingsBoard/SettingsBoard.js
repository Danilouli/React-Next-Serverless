import ClassicForm from '/components/misc/ClassicForm/ClassicForm.js';
import './SettingsBoard.scss';

const SettingsBoard = props => (
	<div className={`SettingsBoard relw100 flex fdc jcc jcsb ${props.className || ''}`}>
		<p className="big_text cblack marb15">{props.title}</p>
		{!!props.subtitle && <p className="fs14 light cgrey marb20">{props.subtitle}</p>}
		<ClassicForm {...props}/>
	</div>
);
SettingsBoard.defaultProps = {
	title : "Général",
	subtitle : "Les informations générales concernant ton profil",
	inputs : [
		[
			{
				value : 'fname',
				label : 'Prénom'
			},
			{
				value : 'lname',
				label : 'Nom',
				disabled : true,
				defaultValue : 'Nomulus'
			}
		],
		[
			{
				value : 'email',
				label : 'Adresse email',
				type : 'email'
			},
			{
				value : 'phone',
				label : 'Téléphone'
			}
		],
		[
			{
				value : 'country',
				label : 'Pays'
			},
			{
				value : 'city',
				label : 'Ville'
			}
		],
		[
			{
				value : 'birthDate',
				label : 'Date de Naissance',
				type : 'date'
			},
			{
				type : 'hidden'
			}	
		]
	],
	sendText : <span>Sauver les modifications</span>
};
export default SettingsBoard;