import Slider from "react-slick";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import TeacherCarouselCard from "/components/misc/TeacherCarouselCard/TeacherCarouselCard";
import './TeachersCarousel.scss';

const SampleNextArrow = props => {
	const { className, style, onClick } = props;
	return (
		<div
			className={className}
			style={{ ...style, display: 'block' }}
			onClick={onClick}
		>
			<FontAwesomeIcon icon={faArrowRight} />
		</div>
	);
};

const SamplePrevArrow = props => {
	const { className, style, onClick } = props;
	return (
		<div
			className={className}
			style={{ ...style, display: 'block' }}
			onClick={onClick}
		>
			<FontAwesomeIcon icon={faArrowLeft} />
		</div>
	);
};

const TeachersCarousel = props => (
	<div className={`TeachersCarousel ${props.className || ''}`}>
		<link rel="stylesheet" type="text/css" charSet="UTF-8" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css" /> 
		<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css" />
		<div className='tchca-GreenRect'></div>
		<div className='tchca-Slider'>
			<Slider
				dots={false}
				infinite={true}
				nextArrow={<SampleNextArrow />}
				prevArrow={<SamplePrevArrow />}
				speed={500}
				slidesToShow={3}
				slidesToScroll={1}
				responsive={[
					{
						breakpoint: 1300,
						settings: {
							slidesToShow: 1,
							dots : true,
							nextArrow : <div></div>,
							prevArrow : <div></div>
						}
					}
				]}
			>
				{
					props.cards.map((c,i) => (
						<TeacherCarouselCard
							teacher={c.teacher}
							student={c.student}
							key={i}
						/>
					))
				}
			</Slider>
		</div>
	</div>
);
const defaultCardProps = {
	teacher : {
		fname : 'Mariel',
		picture : 'https://qkit.les-sherpas.co/uploads/files/5c1bb495721397360ef755f7/5c1ce5b4858a773747a8b984/v2th6fv1u.jpg',
		title : "Professeure de Physique-Chimie"
	},
	student : {
		fname : "Salomé",
		review : "Marie est une professeur géniale ! J’ai fait de gros progrès en quelques semaines grâce à ses cours, je la recommande !",
		stars : 4.8
	}
};
TeachersCarousel.defaultProps = {
	cards : [
		defaultCardProps,defaultCardProps,defaultCardProps,defaultCardProps
	]
};
export default TeachersCarousel;