import {useEffect} from 'react';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';

const AutoCopyInput = props => (
	<div className="AutoCopyInput flex aic relw100 relh100 bradr0">
		<div className="aci-container bgst_beige relh100 flex relw80 aic jcc txtac classic_text cblue fs14 light">
			{props.content}
		</div>
		{/* <GreenButton className='relh100 bradl0'>{props.copyLabel}</GreenButton> */}
	</div>
);
AutoCopyInput.defaultProps = {
	content : 'https://sherpas.co/fedbsx12',
	copyLabel : "Copier"
};
export default AutoCopyInput;