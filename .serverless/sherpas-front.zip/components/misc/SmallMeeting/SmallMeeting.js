import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {faCalendar, faBookmark} from '@fortawesome/free-regular-svg-icons';
import {datify, TIMEGLOBS} from '/static/tools/tools.js';
import {api, getAuth} from '/static/tools/network.js';
import {useState} from 'react';
import {getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';
import _ from 'lodash';
import ClassicButton from "/components/misc/ClassicButton/ClassicButton.js";
import './SmallMeeting.scss';
import {DEFAULTIMG} from '/static/tools/tools.js';
import {useContext} from 'react';
import Bus from '/static/tools/bus.js';

const SmallMeeting = props => {
	try {
		const ctx = useContext(WebsiteContext);
		const {reminder, workspace, user} = props;
		const {type} = user;
		const otherType = (type == 'teacher') ? 'student' : 'teacher';
		let beginDay = datify(reminder.begin, {weekday : 'long', day : 'numeric', month : 'long'});
		let beginHour = datify(reminder.begin, {hour : 'numeric', minute : 'numeric'});
		let endTs = reminder.begin + reminder.duration;
		let endHour = datify(endTs, {hour : 'numeric', minute : 'numeric'});
		let durationInMins = reminder.duration/TIMEGLOBS.minute;
		let trialTime = _.get(workspace, 'trialTime', 0);
		let price = Math.max(Math.floor(((durationInMins - trialTime)*(workspace.price/60))/100), 0);
		let [sending, setSending] = useState(false);
		let hasCard = !!_.get(user, 'devInfos.stripeCustomerId');
		let cannotSendReminder = !_.get(user, 'devInfos.stripeCustomerId') && user.type != 'teacher';
		let isUserDemand = reminder.whoInitiated == user.type;
		let other = isUserDemand ? workspace[reminder.destinedTo] : workspace[reminder.whoInitiated];
		const textData = {
			title : _.get(workspace, 'name', "Mathématiques"),
			with : _.get(other, 'fname', "Marie-Antoinette")
		};
		const reportReminder = () => {
			if (cannotSendReminder)
				return Bus.cast('show_card_modal', {workspace, other});
			setSending(true);
			api.post('tck_reminders/update/set', {
				auth : getAuth(user),
				query : {_id : reminder._id},
				update : {
					acceptation : {
						status : 'canceled',
						lastUpdateDate : Date.now()
					}
				}
			})
			.then(suc => {
				setSending(false);
				Bus.cast('context_refetch_all', {
					callback : Bus.fcast('show_meeting_modal', {workspace, other})
				});
			})
			.catch(err => {
				console.error('reminder cancleation errored', err);
				setSending(false);
				getAlert("Une erreur est apparue");
			})
		};
		const cancelReminder = () => {
			setSending(true);
			api.post('tck_reminders/update/set', {
				auth : getAuth(user),
				query : {_id : reminder._id},
				update : {
					acceptation : {
						status : 'canceled',
						lastUpdateDate : Date.now()
					}
				}
			})
			.then(suc => {
				setSending(false);
				Bus.cast('context_refetch_all', {
					callback : () => getAlert("Le RDV a été annulé")
				});
			})
			.catch(err => {
				console.error('reminder cancleation errored', err);
				setSending(false);
				getAlert("Une erreur est apparue");
			})
		};
		const acceptReminder = () => {
			if (cannotSendReminder)
				return Bus.cast('show_card_modal', {workspace, other});
			setSending(true);
			api.post('tck_reminders/update/set', {
				auth : getAuth(user),
				query : {_id : reminder._id},
				update : {
					acceptation : {
						status : 'accepted',
						lastUpdateDate : Date.now()
					}
				}
			})
			.then(suc => {
				setSending(false);
				Bus.cast('context_refetch_all', {
					callback : () => getAlert("Le RDV a été accepté !")
				});
			})
			.catch(err => {
				console.error('reminder acceptation errored', err);
				setSending(false);
				getAlert("Une erreur est apparue");
			})
		};
		return (
			<div className="SmallMeeting relw100 brad_medium flex fdc">
				<div className="smm-head flex fdr bradt_medium" status={`${reminder.acceptation}`}>
					<div className="smm-image marr10">
						<img className='sage_image' src={_.get(other, 'profile.picture', DEFAULTIMG)}/>
					</div>
					<div className="flex fdc">
						<p className="small_text">{textData.title}</p>
						<p className="mini_text">avec {textData.with}</p>
					</div>
				</div>
				<div className="smm-time smm-section flex fdr">
					<span className='marr10 cgrey'><FontAwesomeIcon icon={faCalendar}/></span>
					<div className="flex fdc">
						<p className="mini_text">{`Le ${beginDay}, de ${beginHour} à ${endHour}`}</p>
						<p className="mini_text cgrey">{durationInMins} minutes</p>
					</div>
				</div>
				<div className="smm-price smm-section flex fdr">
					<span className='marr10 cgrey'><FontAwesomeIcon icon={faBookmark}/></span>
					<p className="mini_text">~ {price}€</p>
				</div>
				{
					_.get(reminder, 'acceptation.status') != 'accepted' &&
					<div className="smm-buttons smm-section flex fdr jcsa">
						<ClassicButton type='blank' disabled={sending || cannotSendReminder} onClick={reportReminder}>Reporter</ClassicButton>
						{
							isUserDemand ?
							<ClassicButton disabled={sending} type='caution' onClick={cancelReminder}>Annuler</ClassicButton> :
							<ClassicButton type='success' disabled={sending || cannotSendReminder} onClick={acceptReminder}>Accepter</ClassicButton>
						}
					</div>
				}
			</div>
		)
	}
	catch (err) {
		console.error(err);
		return <div>Une erreur innatendue est apparue</div>;
	}
};
SmallMeeting.defaultProps = {
	title : "Mathématiques",
	with : "Marie-Antoinette",
	date : "20 Janvier, de 16h30 à 16h55",
	duration : 25,
	price : 12,
	refecth : e=>e
};
export default SmallMeeting;