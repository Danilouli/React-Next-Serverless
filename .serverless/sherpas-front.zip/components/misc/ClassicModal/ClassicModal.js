import './ClassicModal.scss';
import ReactDOM from 'react-dom';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faTimes} from '@fortawesome/free-solid-svg-icons';

class ClassicModal extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div className={`ClassicModal ${this.props.className || ''}`}>
				{
					this.props.title &&
					<div className='cm-title cb20'>
						{this.props.close && <span className='cm-close' onClick={closeModal}><FontAwesomeIcon icon={faTimes}/></span>}
						{this.props.title}
					</div>
				}
				<div className='cm-content'>
					{this.props.content}
				</div>
			</div>
		)
	}
};
export {ClassicModal};
export default ClassicModal;

const openModal = (jsxElt, callback = (e=>e), options = {preventScroll : true}) => {
	closeModal();
	let body = document.querySelector('body');
	if (options.preventScroll)
		body.style.overflow = 'hidden';
	let newDiv = document.createElement('div');
	newDiv.style = "position : absolute; width : 100vw; height : 100vh; background-color : rgba(255,255,255,0.8); z-index : 300; top : 0; display : flex; justify-content : center; align-items : center;";
	newDiv.id = '__the_modal_container';
	ReactDOM.render(jsxElt, newDiv, () => {
		body.appendChild(newDiv);
		callback();
	});
};
export {openModal};

const closeModal = () => {
	let body = document.querySelector('body');
	let theModalContainer = document.getElementById('__the_modal_container');
	if (theModalContainer) {
		ReactDOM.unmountComponentAtNode(theModalContainer);
		theModalContainer.remove();	
	}
	body.style.overflow = '';
};
export {closeModal};