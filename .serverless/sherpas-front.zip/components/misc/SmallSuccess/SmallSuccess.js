import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faCheckCircle} from '@fortawesome/free-solid-svg-icons';

const SmallSuccess = props => (
	<span className={`SmallSuccess small_span ${props.className || ''}`}>
		<span className='cgreen marr10'><FontAwesomeIcon icon={faCheckCircle}/></span>
		{props.children || "Modifications sauvegardées"}
	</span>
);
export default SmallSuccess;