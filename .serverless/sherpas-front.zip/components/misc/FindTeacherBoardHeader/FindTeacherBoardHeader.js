import './FindTeacherBoardHeader.scss';
import FindTeacherBoard from '/components/misc/FindTeacherBoard/FindTeacherBoard.js';
import Dynamic from 'next/dynamic';
import MediaQuerySSR from 'react-responsive';
const MediaQuery = Dynamic(() => Promise.resolve(MediaQuerySSR), {
	ssr: false
});

const FindTeacherBoardHeader = props => (
	<div className='FindTeacherBoardHeader'>
		<div className='ftbh-part ftbh-barPart mob__mart80'>
			<div className='ftbh-findTeacherBoard'>
				<FindTeacherBoard {...props}/>
			</div>
		</div>
		<MediaQuery query="(min-width: 1200px)">
			<div className='ftbh-part ftbh-imagePart'>
				<img className='ftbh-deskImage' src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/bureau_visuel.jpg'></img>
			</div>
		</MediaQuery>
	</div>
);
export default FindTeacherBoardHeader;