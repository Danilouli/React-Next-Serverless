import './MaterialSwitch.scss';
import {useState} from 'react'
import Switch from '@material-ui/core/Switch';

const MaterialSwitch = props => {
	const [checked, setChecked] = (props.checkAuto) ? useState(!!props.checked) : [!!props.checked , e=>e];
	const onChange = () => {
		let willBe = !checked;
		if (props.checkAuto)
			setChecked(!checked);
		if (willBe)
			props.onCheck();
		else
			props.onUnCheck();
	}
	return (
		<div className="MaterialSwitch">
			<Switch checked={checked} onChange={onChange}/>
		</div>
	)
};
MaterialSwitch.defaultProps = {
	onCheck : e=>e,
	onUnCheck : e=>e,
	checked : true,
	checkAuto : false
};
export default MaterialSwitch;