import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faCircleNotch, faLock} from '@fortawesome/free-solid-svg-icons';
import {api} from '/static/tools/network.js';
import _ from 'lodash';
import './CheckoutForm.scss';
import GreenButton from "/components/misc/GreenButton/GreenButton.js";
import {CardNumberElement, CardExpiryElement, CardCvcElement, injectStripe} from 'react-stripe-elements';
import SmallAlert from "/components/misc/SmallAlert/SmallAlert.js";

const errors = {
	our : (
		<div className='relw100 flex fdc'>
			<p className='bold marb10'>Il y a eu une erreur</p>
			<p>Nous sommes désolés, il semblerait qu'il y ait une erreur de notre côté. Veuillez réessayer plus tard ou nous contacter.</p>
		</div>
	),
	their : (
		<div className='relw100 flex fdc'>
			<p className='bold marb10'>Le Paiement a été décliné par votre Banque.</p>
			<p>Soit ils ont fait planter leur minitel … soit vous vous êtes trompé(e) de carte. Essayez avec une autre carte.</p>
		</div>		
	)
};

const successes = {
	waiting : (
		<div className='relw100 flex fdc cwhite'>
			<p className='bold marb10'>Veuillez patienter</p>
			<p>Nous nous mettons en relation avec votre banque, veuillez valider notre demande.</p>
		</div>		
	),
	done : (
		<div className='relw100 flex fdc cwhite'>
			<p className='bold marb10'>C'est tout bon !</p>
			<p>Votre carte a été enregistrée, vous pouvez maintenant faire votre RDV pédagogique.</p>
		</div>
	)
};

class CheckoutForm extends React.Component {
	constructor(props) {
		super(props);
		this.submit = this.submit.bind(this);
		this.state = {
			infoModal : null,
			sending : false,
			cardName : ''
		};
	}

	isComplete() {
		return ((this.state.cardName.trim() != '') && this.state.expiryComplete && this.state.cvcComplete && this.state.numberComplete);
	}

	showOurError(e) {
		this.setState({
			infoModal : {
				type : 'error',
				content : errors.our,
				info : e
			},
			sending : false
		});
		console.error(e);
	}

	showTheirError(e) {
		this.setState({
			infoModal : {
				type : 'error',
				content : errors.their,
				info : e
			},
			sending : false
		});
		console.error(e);
	}

	async submit(ev) {
		const userId = _.get(this, 'props.userId');
		const cardName = this.state.cardName;
		if (!userId)
			return console.error("No user id to send card form");
		this.setState({sending : true}, async () => {
			await this.props.stripe.createToken({name: cardName});
			const setupIntent = await api.post('payments/create_setup_intent').catch(this.showOurError.bind(this));
			const setupIntentCliSecret = _.get(setupIntent, 'client_secret');
			if (!setupIntentCliSecret)
				return this.showOurError.bind(this);
			this.setState({
				infoModal : {
					type : 'success',
					content : successes.waiting
				}
			}, () => {
				this.props.stripe.handleCardSetup(setupIntentCliSecret, {
					payment_method_data: {billing_details: {name: cardName}}
				})
				.then(async suc => {
					const {setupIntent} = suc;
					const customer = await api.post('payments/create_customer_with_payment_method', {
						userId,
						paymentMethodId : setupIntent.payment_method
					}).catch(this.showTheirError.bind(this));
					this.setState({
						infoModal : {
							type : 'success',
							content : successes.done
						},
						sending : false
					}, this.props.onSuccess);
				})
				.catch(this.showTheirError.bind(this));	
			});
		});
	}

	render() {
		return (
			<div className="CheckoutForm flex fdc relw100 bsbb">
				{
					_.get(this, 'state.infoModal.content') &&
					<SmallAlert className='marb20 cblack' type={_.get(this, 'state.infoModal.type', 'success')}>
						{_.get(this, 'state.infoModal.content')}
					</SmallAlert>
				}
				<div className="chck-inputAndLabel relw100 flex fdc marb20">
					<p className='chck-label' errored={`${!!this.state.numberError}`} errinfo={_.get(this, 'state.numberError.message', "Numéro de carte invalide")}>Numéro de carte</p>
					<div className="bord_grey_thin relw100 chck-input chck-number">
						<CardNumberElement
							style={{base: {textAlign : 'left', fontSize : 12}}}
							onChange={e => {this.setState({numberComplete : !!e.complete, numberError : e.error})}}
						/>
					</div>
				</div>
				<div className="chck-inputAndLabel relw100 flex fdc marb20">
					<p className='chck-label' errored={`${this.state.cardName && this.state.cardName.trim() == ''}`} errinfo={"Nom vide"}>Nom du titulaire</p>
					<input className="bord_grey_thin relw100 chck-input chck-name" placeholder="Albert Einstein" onChange={e => this.setState({cardName : e.target.value})}/>
				</div>
				<div className="relw100 flex fdr jcfs marb30">
					<div className="chck-inputAndLabel flex fdc rel marr20">
						<p className='chck-label' errored={`${!!this.state.expiryError}`} errinfo={_.get(this, 'state.expiryError.message', "Date invalide")}>Date d'expiration</p>
						<div className="bord_grey_thin relw100 chck-input chck-expiry">
							<CardExpiryElement
								style={{base: {fontSize : 12, textAlign : 'center'}}}
								onChange={e => this.setState({expiryComplete : !!e.complete, expiryError : e.error})}
							/>
						</div>
					</div>
					<div className="chck-inputAndLabel flex fdc relw35 marl20">
						<p className='chck-label chck-cvcLabel' errored={`${!!this.state.cvcError}`} errinfo={_.get(this, 'state.cvcError.message', "CVC invalide")}>CVC</p>
						<div className="bord_grey_thin relw100 chck-input chck-cvc">
							<CardCvcElement
								style={{base: {fontSize : 12, textAlign : 'center'}}}
								placeholder='123'
								onChange={e => this.setState({cvcComplete : !!e.complete, cvcError : e.error})}
							/>
						</div>
					</div>
				</div>
				<GreenButton onClick={this.submit.bind(this)} disabled={!this.isComplete() || this.state.sending}>
					{
						this.state.sending ?
						<span>VEUILLEZ PATIENTER &nbsp;<FontAwesomeIcon icon={faCircleNotch} spin/></span> :
						<span><FontAwesomeIcon icon={faLock}/>&nbsp;VALIDER</span>
					}
				</GreenButton>
			</div>
		);
	}
};
CheckoutForm.defaultProps = {
	onSuccess : e=>e,
	onError : e=>e
};
export default injectStripe(CheckoutForm);