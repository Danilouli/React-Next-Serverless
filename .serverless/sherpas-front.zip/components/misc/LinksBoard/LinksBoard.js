import Link from 'next/link';
import './LinksBoard.scss';

const links = [];
for (let i = 0; i <= 19; i++)
	links.push(	{
		name : 'Mathématiques',
		url : 'https://www.google.com'
	});

const LinksBoard = props => {
	let i = 0;
	return (
		<div className={`LinksBoard ${props.className || ''}`}>
			{
				props.links.map(link => (
					<Link key={i++} href={link.url} as={link.as || link.url}><a className='lkb-link'>{link.name}</a></Link>
				))
			}
		</div>
	)
};
LinksBoard.defaultProps = {
	links
};
export default LinksBoard;