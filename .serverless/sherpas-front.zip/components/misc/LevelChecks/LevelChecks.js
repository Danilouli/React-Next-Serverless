import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faCheckCircle} from '@fortawesome/free-solid-svg-icons';
import _ from 'lodash';

const LevelChecks = props => (
	<div className="LevelChecks relw100 flex fdc aic boxs_light brad_light">
		<div className="lvc-title bggreen relw100 padv20 cwhite txtac brad_light bradb0 marb15">{props.title}</div>
		<div className="lvc-checks marb30">
			{
				props.checks.map(check => (
					<div className="lvc-check mart15" key={_.kebabCase(check)}>
						<span className='cgreen'><FontAwesomeIcon icon={faCheckCircle}/>&nbsp;</span><span className='cgrey mini_text'>{check}</span>
					</div>
				))
			}
		</div>
	</div>
);
LevelChecks.defaultProps = {
	title : "N°1 Nouveau Sherpa",
	checks : [
		"Mis en avant sur la Marketplace",
		"Commence entre 16 et 24€/h",
		"Récolte tes premiers avis",
		"5% de frais sur tes élèves",
		"15% de frais sur nos élèves"
	]
};
export default LevelChecks;