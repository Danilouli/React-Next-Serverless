import './SmallConfirmModal.scss';
import {ClassicModal, openModal, closeModal} from "/components/misc/ClassicModal/ClassicModal.js";
import ClassicButton from "/components/misc/ClassicButton/ClassicButton.js";

const SmallConfirmModal = props => {
	return (
		<ClassicModal
			title={props.title}
			close={props.noButtons || props.close}
			content={
				<div className='relw100 flex fdc jcse aic'>
					<div className='marb20'>
						{props.message}
					</div>
					{
						!props.noButtons &&
						<div className='relw100 flex fdr jcse'>
							<ClassicButton defaultCss={false} className='padh20 padv10' type={props.yes.type} onClick={props.onConfirm}>{props.yes.message}</ClassicButton>
							<ClassicButton defaultCss={false} className='padh20 padv10' type={props.no.type} onClick={props.onRefuse}>{props.no.message}</ClassicButton>
						</div>
					}
				</div>
			}
			className='SmallConfirmModal'
		/>
	)
};
SmallConfirmModal.defaultProps = {
	title : "Voulez vous confirmer ?",
	message : "Confirmus confirmum",
	yes : {message : "Oui", type : 'success'},
	no : {message : "Non", type : 'caution'},
	onConfirm : e=>e,
	onRefuse : e=>e,
	noButtons : false,
	close : false
};
export default SmallConfirmModal;
export {SmallConfirmModal};

const getConfirm = (props) => {
	return (new Promise((resolve, reject) => {
		let onConfirm = () => {
			resolve(closeModal());
		};
		let onRefuse = () => {
			reject(closeModal());
		};
		let finalProps = {...props, onConfirm , onRefuse};
		if (typeof props == 'string') {
			finalProps.message = props;
			finalProps.title = props.title || "Confirmation demandée";
		}
		finalProps.noButtons = false;
		openModal(<SmallConfirmModal {...finalProps}/>);
	}));
};
export {getConfirm};

const getAlert = props => {
	let finalProps = {};
	if (typeof props == 'string' || !props.message) {
		finalProps.message = props;
		finalProps.title = props.title || "Information";
	}
	else
		finalProps = props;
	finalProps.noButtons = true;
	finalProps.close = true;
	openModal(<SmallConfirmModal {...finalProps}/>);
};
export {getAlert};

const getError = props => {
	let finalProps = {};
	if (typeof props == 'string' || !props.message) {
		finalProps.message = props;
		finalProps.title = props.title || "Erreur";
	}
	else
		finalProps = props;
	finalProps.noButtons = true;
	finalProps.close = true;
	openModal(<SmallConfirmModal {...finalProps}/>);
};
export {getError};