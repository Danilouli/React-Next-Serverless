import './SmallLegend.scss';

const SmallLegend = props => (
	<span className={`SmallLegend`} direction={props.direction}>
		{props.children}
	</span>
);
SmallLegend.defaultProps = {
	direction : 'left'
};
export default SmallLegend;