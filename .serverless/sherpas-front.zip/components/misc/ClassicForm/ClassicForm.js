import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import _ from 'lodash';
import Axios from 'axios';
import {ZOGHEAD, api} from '/static/tools/network.js';

class ClassicForm extends React.Component {
	constructor(props) {
		super(props);
		let keyValues = [];
		this.localStorageStocks = {};
		for (let lineInputs of props.inputs) {
			if (!Array.isArray(lineInputs))
				lineInputs = [lineInputs];
			for (let input of lineInputs) {
				if (!input.value)
					continue;
				keyValues.push(input.value);
				this[input.value] = React.createRef();
				this.localStorageStocks[input.value] = e=>e;
				if (this.props.localStoragePrefix) {
					this.localStorageStocks[input.value] = val => {
						if (val)
							localStorage.setItem(`shr_${this.props.localStoragePrefix}_${input.value}`, `${val}`);
						else
							localStorage.removeItem(`shr_${this.props.localStoragePrefix}_${input.value}`);
					};
				}
			}
		}
		this.keyValues = keyValues;
		this.state = {
			sending : false,
			error : null,
			currentVals : {},
			invalid : {}
		}
	}

	componentDidMount() {
		for (let lineInputs of this.props.inputs) {
			if (!Array.isArray(lineInputs))
				lineInputs = [lineInputs];
			for (let input of lineInputs) {
				if (!input.value)
					continue;
				if (this.props.localStoragePrefix) {
					let val = input.defaultValue;
					if (val) {
						let currentVals = _.get(this, 'state.currentVals');
						currentVals[input.value] = val;
						this.setState({currentVals}, () => {
							localStorage.setItem(`shr_${this.props.localStoragePrefix}_${input.value}`, `${input.defaultValue}`);
						});
					}
				}
			}
		}
		if (this.props.localStoragePrefix && this.props.cleanLocalStorage) {
			window.addEventListener('beforeunload', () => {
				for (let i in localStorage) {
					if (i.indexOf(`shr_${this.props.localStoragePrefix}_`) == 0) {
						localStorage.removeItem(i);
					}
				}
			});
		}
	}

	handleFormSubmit(e) {
		let inputValues = {};
		for (let v of this.keyValues) {
			let valToSet = this[v].current.value;
			if (_.isNil(valToSet) || (typeof valToSet == 'string' && valToSet.trim() == ''))
				continue;
			inputValues[v] = this[v].current.value;
		}
		if (Object.keys(inputValues).length < 1) {
			return this.setState({sending : false}, () => console.log("Nothing to send before beforeSend"));
		}
		if (this.props.submitUrl) {
			this.setState({sending : true});
			inputValues = this.props.beforeSend(inputValues) || {};
			if (Object.keys(inputValues).length < 1) {
				return this.setState({sending : false}, () => console.log("Nothing to send returned by beforeSend"));
			}
			const options = {withCredentials : !!this.props.withCredentials, headers : this.props.headers};
			const request = (this.props.withApi) ?
			api.post(this.props.submitUrl, inputValues, options)
			.then(result => {
				this.setState({sending : false, error : null}, () => {
					this.props.onSubmitSuccess(result);	
				})
			}) :
			Axios.post(this.props.submitUrl, inputValues, options)
			.then(response => {
				const data = response.data;
				const result = _.get(data, 'result');
				if (!data || (!_.isNil(data.success) && !data.success) || !result)
					throw response;
				this.setState({sending : false, error : null}, () => {
					this.props.onSubmitSuccess(result);	
				})
			});
			request.catch(error => {
				this.setState({sending : false, error}, () => {
					console.error('error', error);
					this.props.onSubmitError(error);	
				});
			});
		}
	}

	render() {
		let invalids = this.state.invalid || [];
		let hasInvalids = (Object.keys(invalids).filter(k => !!invalids[k])).length > 0;
		let inputsObject = this.props.inputs;
		let i = 0;
		let formFields = inputsObject.map(lineInputs => {
			if (!Array.isArray(lineInputs))
				lineInputs = [lineInputs];
			return (
				<div key={`clf-lineInput${++i}`} className='clf-lineInputsWithLabels'>
					{
						lineInputs.map(input => {
							let inputCheck = input.check ? (e => {
								let val = _.get(e, 'target.value', e);
								let invalid = _.get(this, 'state.invalid');
								if (val.trim() == '' && !!input.optional)
									invalid[input.value] = false;
								else {
									let error = input.check(val);
									if (error) {
										invalid[input.value] = error;
										(this.localStorageStocks[input.value])(false);
									}
									else
										invalid[input.value] = false;
								}
								this.setState({invalid});
							}) : e=>e;
							let inputReCheck = e => {
								let val = e.target.value;
								let transform = input.transform || (e => e);
								val = transform(val);
								if (val.trim() == '')
									val = '';
								let currentVals = _.get(this, 'state.currentVals');
								currentVals[input.value] = val;
								(this.localStorageStocks[input.value])(val);
								this.setState({currentVals}, () => {
									let invalid = _.get(this, 'state.invalid');
									if (!!invalid[input.value]) {
										inputCheck(val);
									}
								});
							};
							if (!_.isNil(input.value))
								return (
									<div key={input.value} className='clf-input'>
										<label htmlFor={input.value} errored={`${!!this.state.invalid[input.value]}`} errinfo={`${this.state.invalid[input.value]}`}>{input.label}</label>
										{
											(input.type == 'select') ?
											(
												<select
													value={this.state.currentVals[input.value] || input.defaultValue || ''}
													placeholder={input.placeholder || ''}
													disabled={input.disabled || this.state.sending}
													type={input.type || 'text'}
													ref={this[input.value]}
													className={'clf-'+input.value}
													onChange={inputReCheck}
													onBlur={inputCheck}
												>
													{input.options.map(opt => <option key={opt.value} value={opt.value}>{opt.name}</option>)}
												</select>
											) :
											<input
												placeholder={input.placeholder || ''}
												disabled={input.disabled || this.state.sending}
												type={input.type || 'text'}
												ref={this[input.value]}
												className={'clf-'+input.value}
												value={this.state.currentVals[input.value] || input.defaultValue || ''}
												onChange={inputReCheck}
												onBlur={inputCheck}
												autoComplete="new-password"
											/>
										}
									</div>
								)
							else if (input.content) {
								return (
									<div key={Math.random()} className='clf-input clf-content'>{input.content}</div>
								)
							}
						})
					}
				</div>
			)
		});
		return (
			<div className={`ClassicForm relw100 flex fdc ${this.props.className || ''}`}>
				<div className='clf-formFields'>
					{formFields}
				</div>
				<div>
				{
					!!this.props.withButton &&
					<GreenButton className='clf-button' disabled={this.state.sending || hasInvalids} onClick={this.handleFormSubmit.bind(this)}>
						<span>{this.state.sending ? this.props.waitingText : this.props.sendText}</span>
					</GreenButton>
				}
				</div>
			</div>
		);
	}
};
ClassicForm.defaultProps = {
	withApi : true,
	beforeSend : e => e,
	onSubmitSuccess : e => e,
	onSubmitError : e => e,
	waitingText : "Veuillez patienter...",
	sendText : "Envoyer",
	inputs : [
		{
			value : 'email',
			label : 'Adresse email',
			type : 'email'
		},
		[
			{
				value : 'fname',
				label : 'Prénom',
				type : 'text'
			},
			{
				value : 'lname',
				label : 'Nom',
				type : 'text'
			}
		],
		{
			value : 'psswd',
			label : 'Mot de passe',
			type : 'password'
		},
		{
			value : 'phone',
			label : 'Téléphone',
			type : 'text'
		}
	],
	submitUrl : null, //'https://example.api.com/do_the_thing'
	localStoragePrefix : false,
	cleanLocalStorage : false,
	withCredentials : true,
	headers : ZOGHEAD,
	withButton : true
};
export default ClassicForm;
