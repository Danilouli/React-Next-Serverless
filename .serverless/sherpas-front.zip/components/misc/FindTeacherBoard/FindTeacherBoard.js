import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import './FindTeacherBoard.scss';

const FindTeacherBoard = props => (
	<div className={`FindTeacherBoard relw100 bgwhite ${props.className || ''}`}>
		<h1 className='camphor cblue bold fs30 lh45 mob__fs20'>
			{props.h1}
		</h1>
		<h2 className='cblack camphor fs18 lh30 mart30'>
			{props.h2}
		</h2>
		<div className='ftb-search'>
			<div className='ftb-autocomplete'>
				<input
						placeholder={props.inputPlaceholder}
				/>
			</div>
			<GreenButton linkTo='/gallery' linkToAs='/professeurs'>
				{props.button}
			</GreenButton>
		</div>
	</div>
);
FindTeacherBoard.defaultProps = {
	h1 : <span>Des cours particuliers <span className='cgreen'>en ligne</span> qui vont faire progresser votre enfant</span>,
	h2 : <span>Soutien scolaire en ligne, individuel, adapté à votre enfant</span>,
	button : <span>Trouver un Sherpa &nbsp;<FontAwesomeIcon size='xs' icon={faArrowRight}/></span>,
	inputPlaceholder : 'essayez : Mathématiques, Histoire...'
};
export default FindTeacherBoard;