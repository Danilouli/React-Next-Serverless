import _ from 'lodash';
import './CardModal.scss';
import ClassicModal from "/components/misc/ClassicModal/ClassicModal.js"
import {Elements, StripeProvider} from 'react-stripe-elements';
import CheckoutForm from "/components/misc/CheckoutForm/CheckoutForm.js"
import {STRIPE_PUB_KEY} from '/static/tools/network.js';

class CardModal extends React.Component {
	constructor(props) {
		super(props);
		this.state = {stripe: null};
	}

	componentDidMount() {
		this.setState({stripe: window.Stripe(STRIPE_PUB_KEY)});
	}

	render() {
		return (
			<ClassicModal
				className={`CardModal ${this.props.className}`}
				title="Enregistrer un moyen de paiement"
				close={true}
				content={
					<div className='relw100'>
						<div className="relw100 flex fdc">
							<div className="relw100 flex fdr aic jcc marb25">
								<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/cards_logos/visa.svg" className="carm-cardLogo"/>
								<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/cards_logos/mastercard.svg" className="carm-cardLogo"/>
								<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/cards_logos/jcb.svg" className="carm-cardLogo"/>
							</div>
							<div className="relw100 flex fdr jcsb marb20">
								<div className="flex fdc aic">
									<img className='carm-banquePop' src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/banque-populaire%403x.png"/>
									<p className="fs16 bold carm-3DSecure">&nbsp;&nbsp;3D Secure</p>
								</div>
								<div className="flex fdc">
									<p className="fs30 camphor bold cgreen">Offert</p>
									<p className='mini_text cgrey'>Rendez-vous pédagogique</p>
								</div>
							</div>
						</div>
						<StripeProvider stripe={this.state.stripe}>
							<Elements>
								<CheckoutForm
									userId={this.props.userId}
									onSuccess={this.props.onSuccess}
								/>
							</Elements>
						</StripeProvider>
					</div>
				}
			/>
		);
	}
};
CardModal.defaultProps = {
	userId : '5ca2444a84b92024e4411dee',
	onSuccess : e=>e
};

export default CardModal;