import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faDesktop, faCreditCard, faLock} from '@fortawesome/free-solid-svg-icons';
import {faHeart, faThumbsUp} from '@fortawesome/free-regular-svg-icons';
import './IconCard.scss';

const icons = {
	desktop : <FontAwesomeIcon icon={faDesktop}/>,
	heart : <FontAwesomeIcon icon={faHeart}/>,
	card : <FontAwesomeIcon icon={faCreditCard}/>,
	lock : <FontAwesomeIcon icon={faLock}/>,
	thumbsUp : <FontAwesomeIcon icon={faThumbsUp}/>
}

const IconCard = props => (
	<div className="IconCard relw100 relh100 flex jcse fdc">
		<div className="cwi-icon brad_circle flex jcc aic marb25" color={props.color}>
			{icons[props.icon]}
		</div>
		<p className='cwi-title roboto fs20 cblue marb10'>
			{props.title}
		</p>
		<p className="cwi-text roboto light fs20 lh29 cblue">
			{props.text}
		</p>
	</div>
);
IconCard.defaultProps = {
	color : 'yellow',
	icon : 'desktop',
	title : "Donne cours où tu veux, quand tu veux.",
	text : "Pas besoin de te déplacer, c’est pratique et flexible. Stylé."
}
export default IconCard;