import { withStyles, makeStyles } from '@material-ui/core/styles';
import Slider from '@material-ui/lab/Slider';

const 	OurSlider = withStyles({
	root: {
	  color: 'var(--green)',
	  height: 8,
	},
	thumb: {
	  height: 24,
	  width: 24,
	  backgroundColor: '#fff',
	  border: '2px solid currentColor',
	  marginTop: -8,
	  marginLeft: -12,
	  '&:focus,&:hover,&$active': {
		boxShadow: 'inherit',
	  },
	},
	active: {},
	valueLabel: {
	  left: 'calc(-50% + 4px)',
	  opacity : 0.8
	},
	track: {
	  height: 8,
	  borderRadius: 4
	},
	rail: {
	  height: 8,
	  borderRadius: 4,
	},
})(Slider);

const MaterialSlider = props => {
	const handleOnChage = (e,v) => {
		return props.onValueChanged(v);
	}
	return(
		<div className={`MaterialSlider ${props.className || ''}`}>
			<OurSlider
				onChange={handleOnChage}
				defaultValue={props.defaultValue}
				getAriaValueText={props.valueText}
				aria-labelledby="discrete-slider"
				valueLabelDisplay="on"
				valueLabelFormat={props.valueLabelFormat}
				step={props.step}
				marks={props.marks}
				min={props.min}
				max={props.max}
			/>
		</div>
	)
};
export default MaterialSlider;