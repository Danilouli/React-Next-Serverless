import './ClassicButton.scss';
import Link from 'next/link';

class ClassicButton extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		if (this.props.linkTo)
			return (
				<Link href={this.props.linkTo} as={this.props.linkToAs || this.props.linkTo} passHref>
					<a disabled={this.props.disabled} onClick={this.props.onClick} onMouseOver={this.props.onMouseOver} onMouseLeave={this.props.onMouseLeave} className={`ClassicButton ${this.props.className || ''}`} type={this.props.type} defaultcss={`${!!this.props.defaultCss}`}>
						{this.props.children}
					</a>
				</Link>
			)
		else
			return (
				<div disabled={this.props.disabled} onClick={this.props.onClick} onMouseOver={this.props.onMouseOver} onMouseLeave={this.props.onMouseLeave} className={`ClassicButton ${this.props.className || ''}`} type={this.props.type} defaultcss={`${!!this.props.defaultCss}`}>
					{this.props.children}
				</div>
			)
	}
};
ClassicButton.defaultProps = {
	type : 'success',
	defaultCss : true
};
export default ClassicButton;