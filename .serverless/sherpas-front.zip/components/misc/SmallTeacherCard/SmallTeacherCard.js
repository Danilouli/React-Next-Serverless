import StarRatings from 'react-star-ratings';
import './SmallTeacherCard.scss';

const SmallTeacherCard = props => (
	<div className={`SmallTeacherCard flex jcsb aic ${props.className || ''}`}>
		<div className='stc-image'>
			<img src={props.image}></img>
		</div>
		<div className='stc-content flex jcc aifs fdc'>
			<div className='stc-title flex jcc aib'>
				<div className='stc-name'>{props.name}</div>
				<div className='stc-institution'>{props.institution}</div>
			</div>
			<div className='stc-stars'>
				<span className='stc-stars'>
					<span className='stc-grade'>
						{props.stars}
					</span>
					<StarRatings
						rating={props.stars}
						starRatedColor="#f1c40f"
						starDimension="15px"
						starSpacing="1px"
					/>
				</span>
			</div>
		</div>
	</div>
);
export default SmallTeacherCard;