import {useState, useEffect} from 'react';
import SimpleUpload from "/components/misc/SimpleUpload/SimpleUpload.js"
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import {purgeNonNumbers} from '/static/tools/misc.js';

const SubjectsAdders = props => {
	const {subjects, levels} = props;
	let [lines, setLines] = useState([{subject : 'maths', level : 'lycee', price : 2400, document : null, accepted : false}]);
	let max = props.max || 24;
	const setInLine = (value, line, i) => {
		return (e => {
			let val = e.target.value;
			if (value == 'price') {
				val = purgeNonNumbers(val);
				val = parseInt(val);
				if (isNaN(val))
					val = '';
				else {
					val *= 100;
				}
			}
			line[value] = val;
			let newLines = lines.slice();
			newLines[i] = line;
			setLines(newLines);
		})
	};

	const setDocumentInLine = (line, i) => {
		return ((fileUrl, file) => {
			line.document = fileUrl;
			let newLines = lines.slice();
			newLines[i] = line;
			setLines(newLines);	
		})
	};

	const setPriceToMin = (line, i) => {
		return (e => {
			let val = parseInt(e.target.value);
			if (isNaN(val))
				return;
			if (val < 12) {
				line.price = 1200;
				let newLines = lines.slice();
				newLines[i] = line;
				setLines(newLines);	
			}
			if (val > max) {
				line.price = 2400;
				let newLines = lines.slice();
				newLines[i] = line;
				setLines(newLines);	
			}
		});
	}

	useEffect(() => {
		props.inStorageName && localStorage.setItem(`shr_${props.inStorageName}`, JSON.stringify(lines))
	});

	return (
		<div className="SubjectsAdders relw100 flex fdc">
			{
				lines.map((line, i) => {
					return (
						<div className="suba-line relw100 flex fdc marb20" key={i}>
							<div className="relw100 flex fdr marb20 aic">
								<select className="marr20 mob__marr10" value={line.subject} onChange={setInLine('subject', line, i)}>
									{
										subjects.map((s,i) => <option value={s.value} key={i}>{s.name}</option>)
									}
								</select>
								<select value={line.level} onChange={setInLine('level', line, i)}>
									{
										levels.map((l,i) => <option value={l.value} key={i}>{l.name}</option>)
									}
								</select>
								<span className='marh15'><FontAwesomeIcon icon={faArrowRight}/></span>
								<input type="text" value={Math.floor(line.price/100)} onChange={setInLine('price', line, i)} onBlur={setPriceToMin(line, i)}/>
								<div className='marl10 fs12 cgrey'>€/heure</div>
							</div>
							<div className="relw100 flex fdr">
								<div className="relw30 marr20 mob__relw50 mob__marr5">
									<SimpleUpload
										onFileUploaded={setDocumentInLine(line, i)}
										firstStatus={!line.document ? 'normal' : 'success'}
										idSuffix={i}
									/>
								</div>
								<div className="relw70 fs10 light clink_blue">
									<p>Diplôme, certificat, relevé de note…</p>
									<p>Si plusieurs matières sont justifiées par un même document, le remettre à chaque fois.</p>
								</div>
							</div>
						</div>	
					)
				})
			}
			<div className='suba-adder mart25 classic_text light clink_blue cur_pointer' onClick={() => {
				let newLines = lines.slice();
				newLines.push({subject : 'maths', level : 'lycee', price : 2400, document : null, accepted : false});
				setLines(newLines);
			}}>+ Ajouter une autre matière</div>
		</div>
	)
};
SubjectsAdders.defaultProps = {
	inStorageName : null
};
export default SubjectsAdders;