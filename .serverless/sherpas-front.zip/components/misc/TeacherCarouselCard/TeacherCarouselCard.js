import PropTypes from 'prop-types';
import StarRatings from 'react-star-ratings';
import './TeacherCarouselCard.scss';

const TeacherCarouselCard = props => (
	<div className={`TeacherCarouselCard flex fdc jcse aic padh50 padv20 bsbb ${props.className || ''}`}>
		<div className='tcc-head flex asfs'>
			<div className='tcc-teacherPicture'>
				<img src={props.teacher.picture}></img>
			</div>
			<div className='tcc-teacherInfos flex fdc jcse'>
				<p className='tcc-teacherFname cr20'>{props.teacher.fname}</p>
				<p className='tcc-teacherTitle cr16 cgrey lh29'>{props.teacher.title}</p>
			</div>
		</div>
		<div className='tcc-body flex jcc aic'>
			<p className='tcc-review cr16 lh29'>
				{props.student.review}
			</p>
		</div>
		<div className='tcc-bottom relw100 flex jcsb aic'>
			<div className='tcc-student camphor bold fs16 cblue'>
				Avis de {props.student.fname} :
			</div>
			<div className='tcc-stars'>
				<StarRatings
					rating={props.student.stars}
					starRatedColor="#f1c40f"
					starDimension="15px"
					starSpacing="1px"
				/>
			</div>
		</div>
	</div>
);
TeacherCarouselCard.defaultProps = {
	teacher : {
		fname : 'Marie',
		picture : 'https://qkit.les-sherpas.co/uploads/files/5c1bb495721397360ef755f7/5c1ce5b4858a773747a8b984/v2th6fv1u.jpg',
		title : "Professeure de Physique-Chimie"
	},
	student : {
		fname : "Salomé",
		review : "Marie est une professeur géniale ! J’ai fait de gros progrès en quelques semaines grâce à ses cours, je la recommande !",
		stars : 4.8
	}
};
TeacherCarouselCard.propTypes = {
	teacher : PropTypes.object,
	student : PropTypes.object
};
export default TeacherCarouselCard;