import _ from 'lodash';
import './BigMeetingModal.scss';
import './react-datepicker.min.scss';
import DatePicker from "react-datepicker";
import {registerLocale} from  "react-datepicker";
import fr from 'date-fns/locale/fr';
import SmallAlert from "/components/misc/SmallAlert/SmallAlert.js"
import SmallLegend from "/components/misc/SmallLegend/SmallLegend.js";
import ClassicModal from "/components/misc/ClassicModal/ClassicModal.js";
import Bus from '/static/tools/bus.js';
import {TIMEGLOBS} from '/static/tools/tools.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faCalendarAlt, faStopwatch} from '@fortawesome/free-solid-svg-icons';
import {faBookmark} from '@fortawesome/free-regular-svg-icons';
import {api} from '/static/tools/network.js';
import {getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';
import {DEFAULTIMG} from '/static/tools/tools.js';

registerLocale('fr', fr);

let hours = [];
for (let i = 0; i <= 23; i++) {
	hours.push({
		textTime : `${i}:00`,
		mills : i*60*60*1000
	})
	for (let j = 10; j <= 50; j+=10) {
		hours.push({
			textTime : `${i}:${j}`,
			mills : i*60*60*1000 + j*60*1000
		})	
	}
};

class BigMeetingModal extends React.Component {
	constructor(props) {
		super(props);
		let firstDate = new Date();
		firstDate = firstDate.getTime() - firstDate.getHours()*60*60*1000 - firstDate.getMinutes()*60*1000 - firstDate.getSeconds()*1000;
		this.nowHourTs = Date.now() - firstDate;
		this.nowHours = hours.filter(hour => hour.mills >= this.nowHourTs);
		console.log('this.nowHours', this.nowHours);
		const basicHour0 = _.get(this, 'nowHours[0].mills', Date.now());
		const basicHour1 = _.get(this, 'nowHours[1].mills', Date.now());
		this.state = {
			hours : this.nowHours,
			date : new Date(firstDate),
			hour : _.get(this, 'nowHours[0].mills', basicHour0),
			endHour : _.get(this, 'nowHours[6].mills', basicHour1),
			sending : false
		};
		this.hasCard = !!_.get(props, 'user.devInfos.stripeCustomerId');
		this.type = _.get(props, 'user.type');
		this.destinedTo = _.get('props', 'meetWho', (this.type != 'teacher') ? 'teacher' : 'student');
		this.workspace = _.get(props, 'workspace');
		this.other = this.workspace[this.destinedTo];
		this.isTrial = (_.get(this.workspace, 'trialTime', 0) > 0);
		this.cannotSendReminder = ((this.type != 'teacher') && !this.hasCard);
		this.theTitle = `Proposer un RDV ${this.isTrial ? "Gratuit" : ""} à ${this.other.fname}`;
		this.buttonText = `Envoyer cette demande à ${this.other.fname}`;
	}

	handleButtonClick() {
		if (this.cannotSendReminder)
			return Bus.cast('show_card_modal', {workspace : this.workspace, other : this.other});
		this.setState({sending : true});
		let begin = this.state.hour;
		let end = this.state.endHour;
		const {user} = this.props;
		if (this.isTrial)
			end = begin + 20 * TIMEGLOBS.minute;
		let toSend = {
			auth : {
				loginCookie : user._id,
				cookey : _.get(user, 'devInfos.cookey')
			},
			workspace : this.workspace._id,
			title : "Rappel de cours",
			description : "Description",
			begin : this.getBeginTs(),
			duration : end - begin,
			destinedTo : this.destinedTo
		};
		console.log('toSend', toSend);
		api.post('tck_reminders/create', toSend).then(suc => {
			console.log('reminder created', suc);
			this.setState({sending : false});
			Bus.cast('context_refetch_all', {
				callback : () => getAlert("La demande de cours a bien été envoyée")
			});
		});
	}

	handleChangeDate(date) {
		console.log('new date', date);
		let mills = (new Date(date)).getTime();
		let isToday = (mills < Date.now());
		console.log('mills', mills, {isToday});
		try {
			this.setState({
				date,
				hours : isToday ? this.nowHours : hours
			});	
		}
		catch (err) {
			console.error("Cannot update state date", err);
		}
	}

	handleChangeHour(hour) {
		const newHour = parseInt(hour.target.value);
		let stateToSet = {hour : newHour}
		if (newHour >= this.state.endHour);
			stateToSet.endHour = (newHour + 10*TIMEGLOBS.minute);
		this.setState(stateToSet);
	}

	handleChangeEndHour(endHour) {
		this.setState({endHour : parseInt(endHour.target.value)});
	}

	getBeginTs() {
		return parseInt(this.state.date.getTime()) + this.state.hour;
	}

	getBeginStringDate() {
		let totalDate = new Date(this.getBeginTs());
		return 'Le ' + totalDate.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) + ' , à ' + totalDate.toLocaleTimeString('fr-FR').substring(0,5);
	}

	render() {
		if (!this.workspace)
			return <span></span>;
		return (
			<ClassicModal
				className={`BigMeetingModal ${this.props.className}`}
				title={this.theTitle}
				close={true}
				content={
					<div className='relw100 flex fdr'>
						<div className="bmm-date rel flex fdc padr20">
							<p className="mini_text marb25">Votre demande</p>
							<span className="mini_text light cgrey">Date</span>
							<DatePicker
								selected={this.state.date}
								onChange={this.handleChangeDate.bind(this)}
								locale="fr"
								dateFormat='dd/MM/yyyy'
								maxDate={new Date(Date.now() + 15*TIMEGLOBS.day)}
								minDate={new Date(Date.now())}
							/>
							<span className="mini_text light cgrey mart15">Heure de début</span>
							<select value={this.state.hour} onChange={this.handleChangeHour.bind(this)}>
								{
									this.state.hours.map(hour => <option value={hour.mills} key={hour.mills}>{hour.textTime}</option>)
								}
							</select>
							{	
								!this.isTrial &&
								<div className='mart15'>
									<span className="mini_text light cgrey">Heure de fin</span>
									<select value={this.state.endHour} onChange={this.handleChangeEndHour.bind(this)}>
										{
											this.state.hours.filter(hour => hour.mills > this.state.hour).map(hour => <option value={hour.mills} key={hour.mills}>{hour.textTime}</option>)
										}
									</select>
								</div>
							}
						</div>
						<div className='bmm-recap relw75 flex fdc jcse'>
							{
								this.cannotSendReminder && 
								<SmallAlert className='marb20'>
									<div className='flex fdc relw100'>
										Afin d’assurer le sérieux de votre demande, une carte de crédit doit être liée a votre compte.<br></br><a href='#' className='mart5' onClick={Bus.fcast('show_card_modal', {workspace : this.workspace, other : this.other})}>Cliquer ici pour lier une carte a votre compte.</a>
									</div>
								</SmallAlert>
							}
							{
								this.hasCard && this.isTrial && 
								<SmallAlert className='marb20' type='success'>
									<div className='flex fdc relw100'>
										La carte a bien été liée au compte. Il est désormais possible d'envoyer une demande de RDV Pédagogique.
									</div>
								</SmallAlert>
							}
							<p className='marb20 small_text cgrey'>Récapitulatif</p>
							<div className='bmm-lines relw100 flex fdc'>
								<div className="bmm-line bmm-who">
									<img className='square55 brad_circle marr30 objfit_cover' src={_.get(this.other , 'profile.picture', DEFAULTIMG)}/>
									<p className='small_text cgrey light'>{_.get(this.other, 'fname', '')}</p>
								</div>
								<div className="bmm-line">
									<span className="bmm-lineTitle"><span className="marr10"><FontAwesomeIcon icon={faBookmark}/></span>Prix</span>
									<span className="bmm-lineContent">
										{
											this.isTrial ?
											"0,00 €" :
											`${Math.max(0,Math.floor(this.workspace.price*((this.state.endHour - this.state.hour)/TIMEGLOBS.hour)))/100} €`
										}
									</span>
								</div>
								<div className="bmm-line">
									<span className="bmm-lineTitle"><span className="marr10"><FontAwesomeIcon icon={faCalendarAlt}/></span>Date</span>
									<span className="bmm-lineContent">{this.getBeginStringDate()}</span>
								</div>
								<div className="bmm-line">
									<span className="bmm-lineTitle"><span className="marr10"><FontAwesomeIcon icon={faStopwatch}/></span>Durée</span>
									<span className="bmm-lineContent">
									{
										this.isTrial ?
										"20 minutes" :
										`${Math.ceil(((this.state.endHour - this.state.hour)/TIMEGLOBS.minute))} minutes`
									}
									</span>
								</div>
							</div>
							<div onClick={this.handleButtonClick.bind(this)} className="bmm-button flex centerall relw100 bsbb padh40 padv15 mart15 mini_text brad_medium" disabled={this.cannotSendReminder || !!_.get(this, 'state.sending')}>
								{
									this.cannotSendReminder &&
									<SmallLegend direction='right'>
										<span className='bmm-trialLegend small_text flex fdc jcc cwhite bsbb pad20'> 
											<span className='marb25'>
												Vous devez <a href='#' onClick={Bus.fcast('show_card_modal', {workspace : this.workspace, other : this.other})}>lier une carte de crédit à votre compte</a> pour pouvoir proposer une date de cours à {this.other.fname}. 
											</span>
											<span>
												Votre carte ne sera pas débitée.
											</span>
										</span>
									</SmallLegend>
								}
								{this.buttonText}
							</div>
						</div>
					</div>
				}
			/>
		);
	}
};
BigMeetingModal.defaultProps = {
	title : "Proposez un Rendez-vous Gratuit à Marie-Antoinette"
};

export default BigMeetingModal;