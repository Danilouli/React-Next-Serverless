import './ClassicNotification.scss';
import ReactDOM from 'react-dom';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faTimes} from '@fortawesome/free-solid-svg-icons';

class ClassicNotification extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div className={`ClassicNotification ${this.props.className || ''}`} type={this.props.type}>
				<div>
					{this.props.content}
				</div>
				{this.props.close && <span className='cn-close' onClick={closeNotification}><FontAwesomeIcon icon={faTimes} /></span>}
			</div>
		)
	}
};
ClassicNotification.defaultProps = {
	content : 'Bonjour',
	close : true,
	type : 'warning'
}
export {ClassicNotification};
export default ClassicNotification;

const openNotification = (jsxElt, callback = (e=>e), container = '#__the_notification_container') => {
	closeNotification();
	let notifContainer = document.querySelector(container);
	ReactDOM.render(jsxElt, notifContainer, () => {
		callback();
	});
};
export {openNotification};

const closeNotification = (containerQs = '#__the_notification_container') => {
	let notifContainer = document.querySelector('#__the_notification_container');
	if (notifContainer) {
		ReactDOM.unmountComponentAtNode(notifContainer);
	}
};
export {closeNotification};