const ArticleThumbnail = props => (
	<div className={`ArticleThumbnail relw100 flex fdc jcse aic ${props.className || ''}`}>
		<div className="artt-image relw100">
			<img className='relw100 objf_cover' style={{height : '300px'}} src={props.imgUrl}/>
		</div>
		<div className="artt-text relw100 flex fdc jcse pad20 bsbb">
			<h3 className='camphor bold fs20 cblack marb20'>{props.h3}</h3>
			<p className='artt-preview roboto fs13 cblack marb20'>{props.preview}</p>
			<p className='artt-time roboto fs13 cblack'>{props.time}</p>
		</div>
	</div>
);
ArticleThumbnail.defaultProps = {
	imgUrl : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/bureau_visuel.jpg',
	h3 : "Les Mathématiques pour les nuls secrets et astuces de ceux qui ont réussi ! 🎉",
	preview : "Aujourd’hui on va parler des Mathématiques parce que c’est super important pour réussir ta vie et tes études, si tu suis nos conseils tu vas devenir un pro et ça, ça fait la différence ! ",
	time : "Le 28/09/19 - 3 min de lecture"
};
export default ArticleThumbnail;