import './StepsOnlineCourses.scss';

const Step = props => (
	<div className="stoc-step">
		<div className="stoc-stepImage">
			<img src={props.imgUrl}/>
		</div>
		<div className="stoc-stepText flex jcfe fdc">
			<h2 className='classic_text cblue marb15'>{props.h2}</h2>
			<p className='roboto light fs12 cgrey lh16'>{props.p}</p>
		</div>
	</div>
);

const StepsOnlineCourses = props => (
	<div className={`StepsOnlineCourses flex fdc jcsb relw100 aic ${props.className || ''}`}>
		<div className="stoc-steps relw100 flex jcsb aic mart150 marb100 mob__mart10 mob__marb40 mob__fdc">
			<Step
				imgUrl='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/1_big_blue.svg'
				h2={props.step1.h2}
				p={props.step1.p}
			/>
			<Step
				imgUrl='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/2_big_blue.svg'
				h2={props.step2.h2}
				p={props.step2.p}
			/>
			<Step
				imgUrl='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/3_big_blue.svg'
				h2={props.step3.h2}
				p={props.step3.p}
			/>
		</div>
	</div>
);
StepsOnlineCourses.defaultProps = {
	step1 : {
		h2 : "Trouvez un professeur",
		p : "Nous avons passé au peigne fin des centaines de profils de professeurs. Vous aller trouver votre bonheur !"
	},
	step2 : {
		h2 : "Prenez un rendez-vous gratuit",
		p : "Une fois que vous avez trouvé votre Sherpa, vous avez 20 min offertes pour déterminer s’il vous convient."
	},
	step3 : {
		h2: "Progressez à votre rythme",
		p: "Prenez cours en ligne, où vous voulez, quand vous voulez ! Vous payez à la minute et n’êtes pas engagé."
	}
}
export default StepsOnlineCourses;