import './LoadingScreen.scss';

const LoadingScreen = props => (
	<div className={`LoadingScreen ${props.className || ''}`}>
		<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/logo_horizontal.png'></img>
		<span>Chargement ...</span>
	</div>
);
export default LoadingScreen;