import './FormModal.scss';
import {ClassicModal} from '/components/misc/ClassicModal/ClassicModal.js';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import _ from 'lodash';
import Axios from 'axios';
import {ZOGHEAD, api} from '/static/tools/network.js';

class FormModal extends React.Component {
	constructor(props) {
		super(props);
		let keyValues = [];
		for (let lineInputs of props.inputs) {
			if (!Array.isArray(lineInputs))
				lineInputs = [lineInputs];
			for (let input of lineInputs) {
				keyValues.push(input.value);
				this[input.value] = React.createRef();
			}
		}
		this.keyValues = keyValues;
		this.state = {
			sending : false,
			error : null,
			invalid : {},
			currentVals : {}
		}
	}

	handleModalClick(e) {
		let inputValues = {};
		for (let v of this.keyValues) {
			inputValues[v] = this[v].current.value;
		}
		if (this.props.submitUrl) {
			this.setState({sending : true});
			inputValues = this.props.beforeSend(inputValues);
			const request = (this.props.withApi) ?
			api.post(this.props.submitUrl, inputValues, {withCredentials : !!this.props.withCredentials, headers : this.props.headers})
			.then(result => {
				this.setState({sending : false, error : null}, () => {
					this.props.onSubmitSuccess(result);	
				})
			}) :
			Axios.post(this.props.submitUrl, inputValues, {
				headers : this.props.headers,
				withCredentials : !!this.props.withCredentials
			})
			.then(response => {
				const data = response.data;
				const result = _.get(data, 'result');
				if (!data || (!_.isNil(data.success) && !data.success) || !result)
					throw response;
				this.setState({sending : false, error : null}, () => {
					this.props.onSubmitSuccess(result);	
				})
			});
			request.catch(error => {
				this.setState({sending : false, error}, () => {
					console.error('error', error);
					this.props.onSubmitError(error);	
				});
			});
		}
	}

	render() {
		let inputsObject = this.props.inputs;
		let i = 0;
		let modalContent = inputsObject.map(lineInputs => {
			if (!Array.isArray(lineInputs))
				lineInputs = [lineInputs];
			return (
				<div key={`fm-lineInput${++i}`} className='fm-lineInputsWithLabels'>
					{
						lineInputs.map(input => {
							let inputCheck = input.check ? (e => {
								let val = _.get(e, 'target.value', e);
								let invalid = _.get(this, 'state.invalid');
								let error = input.check(val);
								if (error) {
									invalid[input.value] = error;
								}
								else
									invalid[input.value] = false;
								this.setState({invalid});
							}) : e=>e;
							let inputReCheck = e => {
								let val = e.target.value;
								let transform = input.transform || (e => e);
								val = transform(val);
								let currentVals = _.get(this, 'state.currentVals');
								currentVals[input.value] = val;
								this.setState({currentVals}, () => {
									let invalid = _.get(this, 'state.invalid');
									if (!!invalid[input.value]) {
										inputCheck(val);
									}
								});
							}
							return (
								<div key={input.value} className='fm-input'>
									<label htmlFor={input.value} errored={`${!!this.state.invalid[input.value]}`} errinfo={`${this.state.invalid[input.value]}`}>{input.label}</label>
									<input
										disabled={input.disabled || this.state.sending}
										type={input.type || 'text'}
										ref={this[input.value]}
										className={'fm-'+input.value}
										placeholder={input.placeholder}
										value={this.state.currentVals[input.value] || input.defaultValue || ''}
										onChange={inputReCheck}
										onBlur={inputCheck}
										autoComplete="new-password"
									>
									</input>
								</div>
							)
						})
					}
				</div>
			)
		});
		return (
			<ClassicModal
				className={`FormModal ${this.props.className || ''}`}
				close={this.props.close}
				title={this.props.title}
				content={
					<div style={{
						display : 'flex',
						flexDirection : 'column',
						justifyContent : 'center',
						alignItems : 'center'
					}}>
						<div className='fm-modalContent'>
							{modalContent}
						</div>
						<GreenButton disabled={this.state.sending || Object.keys(this.state.invalid).find(k => !!this.state.invalid[k])} onClick={this.handleModalClick.bind(this)}>
							<span>{this.state.sending ? "Veuillez patienter..." : "Envoyer"}</span>
						</GreenButton>
					</div>
				}
			/>
		);
	}
};
FormModal.defaultProps = {
	withApi : true,
	beforeSend : e => e,
	onSubmitSuccess : e => e,
	onSubmitError : e => e,
	close : true,
	title : "Inscrivez-vous",
	inputs : [
		{
			value : 'email',
			label : 'Adresse email',
			type : 'email'
		},
		[
			{
				value : 'fname',
				label : 'Prénom',
				type : 'text'
			},
			{
				value : 'lname',
				label : 'Nom',
				type : 'text'
			}
		],
		{
			value : 'psswd',
			label : 'Mot de passe',
			type : 'password'
		},
		{
			value : 'phone',
			label : 'Téléphone',
			type : 'text'
		}
	],
	submitUrl : 'tck_users/signup',
	withCredentials : true,
	headers : ZOGHEAD
};
export default FormModal;