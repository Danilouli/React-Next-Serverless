import './SmallAlert.scss';

const SmallAlert = props => (
	<div className={`SmallAlert ${props.className || ''}`} type={props.type}>
		<div className='sma-circle'>
			!
		</div>
		<div className='sma-content'>
			{props.children}
		</div>
	</div>
);
SmallAlert.defaultProps = {
	type : 'warning'
};
export default SmallAlert;