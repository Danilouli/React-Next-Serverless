import './PaymentBullshit.scss';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faShieldAlt} from '@fortawesome/free-solid-svg-icons';

const PaymentBullshit = props => (
	<div className="PaymentBullshit relw100 flex fdc jcc aic txtac">
		<div className="payb-shield marb50"><FontAwesomeIcon icon={faShieldAlt}/></div>
		<h2 className='big_h2 marb20'>Nos paiements sont sécurisés et nous traitons avec les leaders du paiement en ligne</h2>
		<p className='big_text light cgrey marb40'>Nous acceptons toutes les principales cartes de paiement.</p>
		<div className="payb-images flex relw100 fdr jcc aic marb50">
			<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/cards_logos/mastercard.svg"/>
			<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/cards_logos/visa.svg"/>
			<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/cards_logos/jcb.svg"/>
			<img src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/cards_logos/dinerclub.svg"/>
		</div>
		<p className='big_text light cgrey'>Sécurisé en 3D Secure par la &nbsp;<img className='payb-banquePop' src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/banque-populaire%403x.png"/></p>
	</div>
);
export default PaymentBullshit;