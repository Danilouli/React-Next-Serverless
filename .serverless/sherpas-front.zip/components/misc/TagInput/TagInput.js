import { WithContext as ReactTags } from 'react-tag-input';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faTimes} from '@fortawesome/free-solid-svg-icons';

class RemoveComponent extends React.Component {
	render() {
		let newProps = Object.assign({}, this.props);
		delete newProps.removeComponent;
		return (
			<span {...newProps} className='ReactTags__custom_remove'><FontAwesomeIcon icon={faTimes}/></span>
		)
	}
 }

const KeyCodes = {
	comma: 188,
	enter: 13,
};

const delimiters = [KeyCodes.comma, KeyCodes.enter];

class TagInput extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			tags: props.tags || [],
			suggestions: props.suggestions || []
		};
		this.handleDelete = this.handleDelete.bind(this);
		this.handleAddition = this.handleAddition.bind(this);
	}

	handleDelete(i) {
		const {tags} = this.state;
		this.setState({
			tags: tags.filter((tag, index) => index !== i),
		}, () => {
			if (this.props.onChangeTags) {
				this.props.onChangeTags({state : this.state, tags : this.state.tags})
			}
		});
	}

	handleAddition(tag) {
		let maxNumber = Infinity;
		if (this.props.maxNumber)
			maxNumber = this.props.maxNumber;
		if (this.state.tags.length < maxNumber)
			this.setState(state => ({ tags: [...state.tags, tag] }), () => {
				if (this.props.onChangeTags) {
					this.props.onChangeTags({state : this.state, tags : this.state.tags})
				}
			});
	}

	handleInputChange(e) {
		if (e.length > 0) {
			let found = this.state.suggestions.find(elt => (elt.text.indexOf(e) >= 0));
			if (!found) {
				let suggestions = this.state.suggestions;
				let customIndex = suggestions.findIndex(elt => elt.custom);
				if (customIndex >= 0)
					suggestions[customIndex] = {id : e, text : e, custom : true};
				else
					suggestions.push({id : e, text : e, custom : true});
				this.setState({suggestions});
			}
		}
	}

	renderSuggestion({ text }, query) {
		let foundIndex = text.toLowerCase().indexOf(query);
		let foundPart = text.substring(foundIndex, foundIndex + query.length);
		let part1 = text.substring(0, foundIndex);
		let part2 = text.substring(foundIndex + query.length);
		return (
			<div>
				<span className='firstPart'>{part1}</span>
				<span className='foundPart'>{foundPart}</span>
				<span className='finalPart'>{part2}</span>
			</div>
		)
	};

	render() {
		const { tags, suggestions } = this.state;
		return (
			<div className={`TagInput ${this.props.className || ''}`}>
				<ReactTags
					removeComponent={RemoveComponent}
					tags={tags}
					suggestions={this.state.suggestions}
					handleDelete={this.handleDelete}
					handleAddition={this.handleAddition}
					delimiters={delimiters}
					allowDragDrop={false}
					handleInputChange={this.handleInputChange.bind(this)}
					allowDeleteFromEmptyInput={false}
					placeholder={this.props.placeholder}
					renderSuggestion = {this.renderSuggestion}
				/>
			</div>
		)
	}
};
export default TagInput;