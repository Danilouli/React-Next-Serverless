import './UploadButton.scss';

const UploadButton = props => (
	<div className={`UploadButton padv5 relw100 flex jcse aic boxs_light brad_light curs_ptr ${props.className}`} onClick={props.onClick} status={`${props.status || 'normal'}`}>
			<div className="relw15">
				<img className='relw100' src={props.icon}/>
			</div>
			<p className='fs12 txtac'>{props.buttonText}</p>
	</div>
);
UploadButton.defaultProps = {
	buttonText : "Télécharger une photo",
	onClick : e=>e,
	icon : "https://sherpas-uploads.s3.eu-west-3.amazonaws.com/upload_button.svg",
	status : 'normal'
};
export default UploadButton;