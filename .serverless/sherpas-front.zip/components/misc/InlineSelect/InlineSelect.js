import './InlineSelect.scss';

//Children in Inline Select can be toggled one each time, a click toggles one, and gives the children the css attribute active=true
class InlineSelect extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			value : props.value
		};
	}

	render() {
		const childrenWithProps = React.Children.map(this.props.children, child => {
			return React.cloneElement(child, {
				onClick : (e) => {
					const theValue = child.props.value || child.props.key;
					this.setState({value : theValue, selectedElt : e.target}, () => {
						this.props.onChange({value : theValue, state : this.state}); 
					});
				},
				active : child.props.active || (this.props.value == child.props.value).toString(),
				className : `${child.props.className} inls-selectOption`
			})
		});
		return (
			<div {...this.props} className={`InlineSelect ${this.props.className || ''}`}>
				{childrenWithProps}
			</div>
		)
	}
};
export default InlineSelect;