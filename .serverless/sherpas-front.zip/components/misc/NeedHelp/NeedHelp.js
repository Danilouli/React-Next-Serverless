const NeedHelp = props => (
	<div className="NeedHelp relw100 flex fdc jcc aic">
		<div className="nedh-image marb25" style={{width : 70, height : 70}}>
			<img className='sage_image badge_image' src="https://sherpas-uploads.s3.eu-west-3.amazonaws.com/logo120.png"/>
		</div>
		<p className="big_text cblack marb10">Besoin d'aide ?</p>
		<p className="small_text cgrey marb10">Parlez à notre équipe basée à Paris de 9h à 20h du Lundi au Vendredi</p>
		<a href="mailto:support@les-sherpas.co" className='fs20 light'>Nous contacter</a>
	</div>
);
export default NeedHelp;