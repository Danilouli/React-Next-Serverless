import './SmallCard.scss';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';

class SmallCard extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div without-bar={`${!!this.props.withoutBar}`} style={this.props.style} className={`SmallCard ${this.props.className || ''}`}>
				{!this.props.withoutBar && <div className='smca-greenBar'></div>}
				<h2 className='classic_h2'>{this.props.title}</h2>
				<p className='fs16 lh20 light cblue'>{this.props.text}</p>
				<GreenButton className='classic_text bold'>
					{this.props.buttonContent}
				</GreenButton>
			</div>
		)
	}
};
SmallCard.defaultProps = {
	withoutBar : false,
	title : "20 min gratuites pour commencer",
	text : "90% de nos utilisateurs commencent par un RDV Pédagogique gratuit",
	buttonContent : "Prendre un RDV Pédagogique"
};
export default SmallCard;