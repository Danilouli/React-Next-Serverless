import Link from 'next/link';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import Dynamic from 'next/dynamic';
import MediaQuerySSR from 'react-responsive';
const MediaQuery = Dynamic(() => Promise.resolve(MediaQuerySSR), {
	ssr: false
});

const TextAndImageSide = props => (
	<div className={`TextAndImageSide relw100 flex jcc aic mob__fdcr ${props.reverse ? 'fdrr' : 'fdr'} ${props.className || ''}`}>
		<div className='tais-image relw100'>
			<img className='relw100' src={props.imgUrl}></img>
		</div>
		<div className='tais-text relw100 bsbb padh40 mob__padh0'>
			<div className='tryptiq'>
				<h2 className='classic_h2'>
					{props.h2}
				</h2>
				<p className='rl16'>
					{props.p} 
				</p>
				{
					props.link &&
					<MediaQuery query="(min-width: 1200px)">
						<Link href="#">{props.link}</Link>
					</MediaQuery>
				}
			</div>
		</div>
	</div>
);
TextAndImageSide.defaultProps = {
	reverse : false,
	imgUrl : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/classroom_home.png',
	h2 : <span>… rencontrez-le pour <span className='cgreen'>un rendez-vous pédagogique</span> gratuit de 20 min.</span>,
	p : <span>Une fois que vous avez trouvé un professeur qui vous plaît, posez-lui toutes vos questions sur ses compétences et méthodes d’enseignement, et assurez-vous qu’il va bien s’entendre avec votre enfant. Comme tout est 100% en ligne, vous pouvez discuter à midi, puis rependre après le dîner, c’est comme vous voulez !</span>,
	link : false //<a>Essayez la salle de classe en ligne <FontAwesomeIcon size='xs' icon={faArrowRight}/></a>
};
export default TextAndImageSide;