import './SEOBullshit.scss';

const SEOBullshit = props => (
	<div className={`SEOBullshit relw100 flex fdc jcse aic ${props.className || ''}`}>
		<div className="relw50 marb100 mob__relw100 mob__marb40">
			<h2 className='big_h2 txtac mob__fs24 mob__lh30'>
				{props.h2}
			</h2>
		</div>
		<div className="sbs-bullshit relw70">
			{props.bullshit}
		</div>
	</div>
);
SEOBullshit.defaultProps = {
	bullshit : (
		<div>
			<h3>Lorem ipsum dolor sit amet</h3>
			consectetur adipiscing elit. Nulla sit amet vestibulum nunc. Sed faucibus egestas massa. Mauris et euismod libero. Nunc venenatis neque arcu, vel dapibus metus interdum eget. Fusce ullamcorper, ex in aliquam cursus, urna metus auctor sapien, non venenatis mauris odio sit amet augue. Curabitur rhoncus nisl massa, non mattis quam gravida a. Aliquam vel varius mauris. Nam ullamcorper tortor ac rutrum molestie. Integer pretium aliquam arcu, in posuere mauris dictum rutrum. Praesent pulvinar sed ipsum quis bibendum. Sed fermentum libero quis nisi suscipit, vel efficitur est suscipit. Cras dignissim metus eu mauris vestibulum, pulvinar feugiat quam varius. Aliquam bibendum nibh eu elit feugiat consectetur. In a diam scelerisque sem convallis dapibus vel sit amet nibh. Sed fringilla at dui eget ornare.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Nullam neque nisi, feugiat et quam sed, interdum ornare odio. Nulla pulvinar magna vehicula purus tincidunt, et hendrerit felis fringilla. Quisque vitae hendrerit erat. Proin convallis ante nulla, in bibendum turpis condimentum sed. Nulla eget felis orci. Aliquam tortor lorem, scelerisque in augue sit amet, laoreet dapibus odio. Phasellus vulputate turpis malesuada nunc vulputate condimentum eu vel dolor. Donec dapibus felis enim, pellentesque consequat libero placerat ut.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Sed fringilla at nisi vel rhoncus. Donec id nulla mauris. Praesent tempor, leo id maximus posuere, massa dui molestie felis, at tempor erat lacus eu nibh. Integer consectetur pretium sem, laoreet auctor diam aliquam vitae. Vestibulum porta ipsum vitae nunc tristique dignissim. Mauris tempor condimentum sodales. Nulla luctus sed diam sit amet sagittis.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Aenean consectetur velit porta tortor tincidunt iaculis. Phasellus a tortor et enim ultrices aliquam. Donec rutrum, augue ut elementum condimentum, purus libero faucibus nisl, eget vehicula nisl orci a sapien. Donec consectetur, arcu placerat porttitor cursus, elit justo euismod metus, ut dictum justo velit quis libero. Aliquam ut maximus felis. Donec vel massa nec augue ornare consequat ut vitae tortor. Donec arcu purus, auctor eget elit eget, elementum eleifend risus. Nullam sollicitudin nisl ut dui semper, quis malesuada arcu porta. Maecenas turpis risus, lacinia nec fringilla vitae, dignissim vel eros. Ut vel tincidunt nisl. Praesent mauris sem, efficitur nec velit nec, suscipit scelerisque sapien. Ut luctus, augue id volutpat maximus, turpis neque aliquam nulla, at pretium felis massa et massa. Morbi vitae eros a sapien feugiat tincidunt. Maecenas sem nibh, maximus vel mi ut, rhoncus ornare ipsum. Praesent gravida nibh quam, quis interdum dui tempor nec.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Integer augue elit, hendrerit quis felis sed, tincidunt rutrum nulla. Nullam et ullamcorper est. Nunc dui turpis, consequat id mauris at, porttitor luctus ipsum. Suspendisse nec massa faucibus, posuere ante in, euismod leo. Sed imperdiet mattis enim in pretium. Nulla eros metus, accumsan in venenatis eget, tempor quis nisi. Quisque id neque et ligula semper tincidunt. Vivamus sed vestibulum sem, vitae vestibulum sem. Proin posuere non nibh vitae sagittis. Donec ac fermentum felis.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Fusce bibendum, lorem quis semper scelerisque, felis augue maximus magna, ut porttitor mi tortor vel arcu. Aenean dapibus quis tellus ut gravida. Vivamus id justo nisi. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Suspendisse volutpat vel magna tristique mattis. Mauris eget iaculis diam. Integer ac eros sit amet augue vestibulum varius sed nec sem. Donec imperdiet tellus sit amet ipsum lacinia aliquet. Nam ex odio, imperdiet non venenatis ac, posuere sit amet enim. Curabitur vehicula mauris sit amet rutrum semper. Vestibulum rutrum euismod diam, vehicula volutpat lectus eleifend in. Donec in mauris arcu.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Donec id aliquam sem. Etiam quis orci sagittis, imperdiet ligula sit amet, rhoncus ligula. Sed diam tellus, accumsan at diam a, venenatis pretium ligula. Sed id tempor sapien, blandit porta purus. Etiam tristique turpis at massa congue, ut dictum ligula vulputate. Morbi quis laoreet ante. Quisque pellentesque porttitor nunc, a porta sem porttitor ut. Sed tellus tellus, maximus eu sem nec, viverra faucibus lectus. Nam elementum lectus orci. Integer auctor ligula ac sapien vulputate varius.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Sed interdum ex sit amet pretium venenatis. Ut vulputate dictum ipsum vitae ullamcorper. Cras tincidunt eros in lorem porta, non cursus nisl mollis. Sed vitae orci at augue malesuada gravida id id ligula. Nunc viverra cursus erat, eget eleifend diam. Proin placerat felis nec purus accumsan condimentum. Mauris porttitor nulla nec accumsan malesuada. Quisque pulvinar sapien nec libero molestie efficitur. Donec convallis, nunc vitae tempus volutpat, turpis nisi ullamcorper ligula, viverra tristique ex urna ut lectus. Integer lorem neque, pulvinar sed elit quis, lacinia rhoncus sapien. Interdum et malesuada fames ac ante ipsum primis in faucibus. Phasellus vulputate dui vel pharetra lacinia. Donec scelerisque porttitor ipsum, dictum sodales tellus porttitor ut.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Phasellus tincidunt vestibulum dictum. Nulla laoreet malesuada ante a dapibus. Vestibulum accumsan ut lorem ut tincidunt. Nulla sit amet suscipit massa. Donec ac risus nec velit sagittis posuere. In tempus quam sed massa dictum consequat. Quisque id aliquet odio. Aliquam scelerisque tincidunt ipsum in congue. In vitae elit sit amet mauris dictum aliquam at in ipsum. Pellentesque rutrum felis luctus, sodales magna eget, elementum turpis. Nullam tellus sem, tristique condimentum mollis eu, rhoncus vel libero.
			<h3>TUOQUROIQJUROIQJRIOf fq iojio qfjqw </h3>
			Sed vitae velit ut ante tristique pharetra quis eget nisl. Proin venenatis ipsum eu dolor tempor molestie. Suspendisse ipsum ante, sagittis convallis tortor nec, interdum dignissim quam. Nunc rutrum bibendum mi vel tempus. Nullam eget dolor sapien. Ut rutrum lectus diam, a fringilla orci sollicitudin vitae. Maecenas mi leo, ultricies in luctus id, consectetur finibus diam. Maecenas fermentum sodales venenatis. Nam eu neque ac libero finibus porta. 
		</div>
	),
	h2 : <span>Soutien en <span className='cgreen'>Mathématiques</span> avec un prof particulier : une aide parfois indispensable</span>
}
export default SEOBullshit;