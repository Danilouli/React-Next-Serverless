import Link from 'next/link';
import SmallTeacherCard from '/components/misc/SmallTeacherCard/SmallTeacherCard.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';

const FindATeacherSmallCards = props => (
	<div className={`FindATeacherSmallCards relw100 flex jcfe aic mob__fdc ${props.className || ''}`}>
		<div className='txtar mob__txtal mob__marb20'>
			<div className='tryptiq'>
				<h2 className='classic_h2'>
					{props.h2}
				</h2>
				<p className='rl16'>
					{props.p}
				</p>
				<Link href="/gallery" as="/professeurs" passHref>
					{props.link}
				</Link>
			</div>
		</div>
		<div className='relw50 flex fdc jcc aic mob__relw100 marl70 mob__mar0'>
			{props.teachers.map(teacher => (
				<SmallTeacherCard {...teacher} key={teacher.name + Math.random()}/>
			))}
		</div>
	</div>
);
const defaultTeacher = {
	image : 'https://qkit.les-sherpas.co/uploads/files/5c1bb495721397360ef755f7/5c1ce5b4858a773747a8b984/5ztjp843w.jpg',
	name : "Clémentine",
	institution : "Étudiante à HEC Paris",
	stars : 4.9
};
const teach1 = {
	image : 'https://qkit.les-sherpas.co/uploads/files/5c1bb495721397360ef755f7/5c1ce5b4858a773747a8b984/5ztjp843w.jpg',
	name : "Clémentine",
	institution : "Étudiante à HEC Paris",
	stars : 4.9
};
const teach2 = {
	image : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/EtienneHome.png',
	name : "Guillaume",
	institution : "Étudiant à Centrale Supélec",
	stars : 4.6
};
const teach3 = {
	image : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/BenjaminHome.png',
	name : "Thibaut",
	institution : "Étudiant à l'ESSEC",
	stars : 4.7
};
FindATeacherSmallCards.defaultProps = {
	h2 : <span>Trouvez <span className="cgreen">un Sherpa</span> avec les compétences dont vous avez besoin</span>,
	p : <span>Les cours en ligne résolvent les problèmes de géographie. Pas besoin de choisir Mathieu parce qu’il est à 15 min. Nos professeurs couvrent tous les niveaux et matières, grâce à nous, vous allez vraiment trouver la perle rare !</span>,
	link : <a>Trouvez un Sherpa <FontAwesomeIcon size='xs' icon={faArrowRight}/></a>,
	teachers : [teach1,teach2,teach3]
};
export default FindATeacherSmallCards;