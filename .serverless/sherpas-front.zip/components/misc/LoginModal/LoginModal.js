import {setLoginCookies} from '/static/tools/tools.js';
import FormModal from '/components/misc/FormModal/FormModal.js';

const LoginModal = props => (
	<FormModal
		className={`LoginModal ${props.className}`}
		{...
			{
				onSubmitSuccess : e => {
					setLoginCookies({
						loginCookie : e._id,
						cookey : _.get(e, 'devInfos.cookey')
					});
					window.location = '/home';
				},
				onSubmitError : e => {
					alert('Il y a eu une erreur, vérifiez bien vos identifiants');
				},
				title : "Connectez-vous",
				inputs : [
					{
						value : 'email',
						label : 'Adresse email',
						type : 'email',
						placeholder : 'albert.einstein@gmail.com'
					},
					{
						value : 'psswd',
						label : 'Mot de passe',
						type : 'password',
						placeholder : '******'
					}
				],
				submitUrl : 'tck_users/login',
				close : false
			}
		}
	>
	</FormModal>
);
export default LoginModal;