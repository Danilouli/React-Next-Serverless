import './GreenButton.scss';
import Link from 'next/link';

class GreenButton extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		if (this.props.linkTo)
			return (
				<Link href={this.props.linkTo} as={this.props.linkToAs} passHref>
					<a disabled={this.props.disabled} onClick={this.props.onClick} className={`GreenButton ${this.props.className || ''}`}>
						{this.props.children}
					</a>
				</Link>
			)
		else
			return (
				<div disabled={this.props.disabled} onClick={this.props.onClick} className={`GreenButton ${this.props.className || ''}`}>
					{this.props.children}
				</div>
			)
	}
};
export default GreenButton;