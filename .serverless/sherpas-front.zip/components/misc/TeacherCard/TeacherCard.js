import {useContext} from 'react';
import './TeacherCard.scss';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import StarRatings from 'react-star-ratings';
import _ from 'lodash';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import Dynamic from 'next/dynamic';
import MediaQuerySSR from 'react-responsive';
const MediaQuery = Dynamic(() => Promise.resolve(MediaQuerySSR), {
	ssr: false
});
import Link from 'next/link';

const TeacherCard = props => {
	const context = useContext(WebsiteContext);
	const {lang} = context;
	const {teacher} = props;
	const seoId = _.get(teacher, 'profile.seoId', 'professeur-maths-physique-espagnol-lycee-informatique-espagnol-prepa-scientifique-precieux-conseils-sen-sortir');
	let subjectsTaught = _.get(teacher, 'teacherInfos.subjectsTaught', []);
	const {level, subjects} = props.filters;
	subjectsTaught = _.pickBy(subjectsTaught, e => !!e[level]);
	let allSubjects = _.uniq([...subjects, ...Object.keys(subjectsTaught)]).map(e => ({
		value : e,
		name : _.get((lang.subjects.find(s => s.value == e)), 'name', e)
	})).slice(0,5);
	let prices = Object.keys(subjectsTaught).map(s => (_.get(subjectsTaught, `${s}.${level}.price`, Infinity)));
	let price = Math.min(...prices);
	price = Math.floor(price/100);
	return (
		<Link href={`/teacher_profile?seoId=${seoId}`} as={`/t/${seoId}`} passHref>
			<a className='relw100 marv10'>
				<div className={`TeacherCard ${props.className || ''}`}>
					<div className='tchc-teacherPhoto'>
						<img src={_.get(teacher, 'profile.picture')}>
						</img>
						<MediaQuery query="(min-width: 1200px)">
						{!!teacher.isOnline && <div className='tchc-onlineChip' isonline={`${teacher.isOnline}`}></div>}
						</MediaQuery>
					</div>
					<div className="tchc-rest">
						<MediaQuery query="(max-width: 1200px)">
							<Link href={`/teacher_profile?seoId=${seoId}`} as={`/t/${seoId}`} passHref>
								<span className='tchc-mobileLink'>Profil <FontAwesomeIcon icon={faArrowRight} size='xs'/></span>
							</Link>
						</MediaQuery>
						<div className='tchc-teacherText'>
							<div className='tchc-nameAndSchool'>
								<span className='tchc-name'>{_.get(teacher, 'fname')}</span>
								<span className='tchc-school'>{_.get(teacher, 'teacherInfos.institution')}</span>
							</div>
							<MediaQuery query="(min-width: 1200px)">
								<div className='tchc-description'>
									<h3 dangerouslySetInnerHTML={{__html : _.get(teacher, 'profile.description.title', '')}}></h3>
								</div>
								<div className='tchc-subjects'>
									{allSubjects.map(subject => <span className='tchc-subject' key={subject.value}>{subject.name}</span>)}
								</div>
							</MediaQuery>
						</div>
						<div className='tchc-teacherButtons'>
							<div className='tchc-price'>
								{`dès ${price}€`}
								<span className='tchc-perHour'>
									par heure
								</span>
							</div>
							{
								false && <div className='tchc-starsAndGrade'>
									<span className='tchc-stars'>
										<StarRatings
											rating={4.5}
											starRatedColor="#f1c40f"
											starDimension="15px"
											starSpacing="1px"
										/>
									</span>
									<span className='tchc-grade'>
										4.5
									</span>
									<span className='tchc-reviews'>
										125 avis
									</span>
								</div>
							}
							<MediaQuery query="(min-width: 1200px)">
								<GreenButton>
									<span className='cwhite calm_link'>Voir le profil</span>
								</GreenButton>
							</MediaQuery>
						</div>
					</div>
				</div>
			</a>
		</Link>
	)
};
export default TeacherCard;