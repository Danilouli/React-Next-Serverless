import './Calculator.scss';

class Calculator extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			hours: 5,
			perHour: 23
		};
	}
	render() {
		return (
			<div className='Calculator relw100 flex fdc jcse'>
				<label htmlFor="hours" className="roboto light fs12 cgrey">
					Combien d'heures de cours pourrais-tu donner chaque semaine ?
					</label>
				<select name="hours" value={this.state.hours} onChange={e => this.setState({ hours: parseFloat(e.target.value) })}>
					<option value="1.5">Entre 1 et 2 heures par semaine</option>
					<option value="3">Entre 2 et 4 heures par semaine</option>
					<option value="5">Entre 4 et 6 heures par semaine</option>
					<option value="8">Entre 6 et 10 heures par semaine</option>
				</select>
				<label htmlFor="perHour" className="roboto light fs12 cgrey">
					A quel niveau peux tu enseigner ?
					</label>
				<select name="perHour" value={this.state.perHour} onChange={e => this.setState({ perHour: parseFloat(e.target.value) })}>
					<option value="17">Collège</option>
					<option value="23">Lycée</option>
					<option value="31">Supérieur</option>
				</select>
				<div className="calc-result mart30">
					<span className='calc-number roboto bold fs30 cblack'>{this.state.hours * 4 * this.state.perHour}€</span>
					<span className='classic_text light cgrey'>&nbsp;/mois</span>
				</div>
			</div>
		);
	}
};
export default Calculator;
