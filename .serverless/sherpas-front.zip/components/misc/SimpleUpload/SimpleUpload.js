import UploadButton from "/components/misc/UploadButton/UploadButton.js";
import {useState} from 'react';
import {uploadToS3} from '/static/tools/network.js';

const SimpleUpload = props => {
	const [status, setStatus] = useState(props.firstStatus);
	const launchSimpleUpload = e => {
		let file = e.target.files[0];
		setStatus('sending');
		uploadToS3(file)
		.then(suc => {
			let {finalUrl} = suc;
			setStatus('success');
			props.onFileUploaded(finalUrl, file);
		})
		.catch(err => {
			console.error('err upload', err);
			props.onError(err, file);
			setStatus('normal');
		})
	};
	const theId = `simpleUploadFileInput_${props.idSuffix}`;
	return (
		<div className="SimpleUpload relw100">
			<input type="file" id={theId} onChange={launchSimpleUpload} style={{display : 'none'}}/>
			<UploadButton
				className='padh10 bsbb'
				onClick={() => {
					document.getElementById(theId).click();
				}}
				buttonText={props.statusTexts[status]}
				status={status}
				icon={props.statusIcons[status]}
			/>
		</div>
	)
};
SimpleUpload.defaultProps = {
	statusTexts : {
		normal : "Télécharger un Justificatif Nominatif",
		success : "Justificatif chargé !",
		sending : "Veuillez patienter ..."
	},
	statusIcons : {
		normal : "https://sherpas-uploads.s3.eu-west-3.amazonaws.com/upload_button.svg",
		success : "https://sherpas-uploads.s3.eu-west-3.amazonaws.com/little_check_modifications.svg",
		sending : "https://sherpas-uploads.s3.eu-west-3.amazonaws.com/upload_button.svg"
	},
	onClick : e=>e,
	onFileUploaded : e=>e,
	onError : e=>e,
	firstStatus : 'normal',
	idSuffix : Math.random()
};
export default SimpleUpload;