import './TeacherContactBox.scss';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import SmallAlert from '/components/misc/SmallAlert/SmallAlert.js';
import Bus from '/static/tools/bus.js';
import {ClassicModal, openModal} from '/components/misc/ClassicModal/ClassicModal.js';
import FormModal from '/components/misc/FormModal/FormModal.js';
import _ from 'lodash';
import {isMobile} from 'react-device-detect';
import {setCookie} from '/static/tools/tools.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {validateEmail, purgeNonLetters, isPhone} from '/static/tools/misc.js';
import Router from 'next/router';
import {api} from '/static/tools/network.js';
import {getConfirm, getAlert} from '/components/misc/SmallConfirmModal/SmallConfirmModal.js';

class TeacherContactBox extends React.Component {
	constructor(props, context) {
		super(props, context);
		this.state = {
			selectedPrice : 'placeholder',
			message : `Bonjour ${props.teacher.fname} ! Je cherche un professeur. Êtes-vous disponible pour un rendez-vous pédagogique de 20 min ? J’attends votre réponse !`
		}
		const {user} = context;
		if (user) {
			console.log('userr', user);
			console.log('teacher', this.props.teacher);
			const hasTeacher = !!((user.type == 'teacher') || (_.get(user, 'workspaces', []).find(w => _.get(w, 'teacher._id') == _.get(this, 'props.teacher._id'))));
			console.log('hasTeacher', hasTeacher);
			this.hasTeacher = hasTeacher;
		}
	}

	static contextType = WebsiteContext;

	handleTypeButtonClick(type) {
		return () => {
			localStorage.setItem('shr_type', type);
			Bus.cast('show_signup_modal');
		}
	}

	componentDidMount() {
		let locStorSubj = localStorage.getItem("shr_keep_gallery_subject");
		let locStorLevel = localStorage.getItem("shr_keep_gallery_level");
		let locStorExists = _.get(this, `props.subjectsTaught.${locStorSubj}.${locStorLevel}`); 
		console.log({locStorSubj, locStorLevel});
		if (!!locStorSubj && !!locStorLevel && !!locStorExists) {
			this.setState({
				selectedPrice : `${locStorSubj}___${locStorLevel}`,
				subject : locStorSubj,
				level : locStorLevel
			})
		}
		Bus.when('show_mobile_message_modal', () => {
			let messageModal = 
				<ClassicModal
					className='tcb-modal'
					close={true}
					title='Ecrivez votre message'
					content={
						<div className='flex fdc jcse aic'>
							<p className='tcb-modalText'>Écrivez le message à envoyer à {this.props.teacher.fname}.</p>
							<textarea
									className='tcb-modalTextarea'
									onChange={this.handleTextareaChange.bind(this)}
									placeholder={`Bonjour ${this.props.teacher.fname} ! Je cherche un professeur. Êtes-vous disponible pour un rendez-vous pédagogique de 20 min ? J’attends votre réponse !`}
							/>
							<div className='tcb-modalButtons'>
								<GreenButton onClick={Bus.fcast('show_type_modal')}>
									<span>Envoyer</span>
								</GreenButton>
							</div>
						</div>
					}
				/>;
			openModal(messageModal);
		});
		Bus.when('show_type_modal', () => {
			let typeModal = 
				<ClassicModal
					className='tcb-modal'
					close={true}
					title='Inscrivez-vous pour envoyer votre message'
					content={
						<div className='flex fdc jcse aic'>
							<p className='tcb-modalText'>Super ! Votre message est prêt à être envoyé ! Créez un compte gratuit pour recevoir une réponse.</p>
							<div className='tcb-modalButtons'>
								<GreenButton className='tcb-parentButton' onClick={this.handleTypeButtonClick('parent')}>
									<span>Je suis un Parent</span>
								</GreenButton>
								<GreenButton onClick={this.handleTypeButtonClick('student')}>
									<span>Je suis un Élève</span>
								</GreenButton>
							</div>
						</div>
					}
				/>;
			openModal(typeModal);
		});
		Bus.when('show_signup_modal', () => {
			const type = localStorage.getItem('shr_type');
			const title = (type == 'parent') ? "Inscrivez-vous pour envoyer un message" : "Inscris-toi pour envoyer un message";
			localStorage.setItem('shr_formTitle', title);
			let formModal =
			<FormModal
				title={title}
				inputs={[
					{
						value : 'email',
						label : 'Adresse email',
						type : 'email',
						check : e=>(!validateEmail(e) ? "Mail invalide" : false),
					},
					[
						{
							value : 'fname',
							label : 'Prénom',
							type : 'text',
							transform : purgeNonLetters
						},
						{
							value : 'lname',
							label : 'Nom',
							type : 'text',
							transform : purgeNonLetters
						}
					],
					{
						value : 'psswd',
						label : 'Mot de passe',
						type : 'password',
						check : v=>(v.length < 6 ? "Au moins 6 caractères" : false)
					},
					{
						value : 'phone',
						label : 'Téléphone',
						check : v=>(!isPhone(v) ? "Numéro invalide" : false),
						transform : v=>(isPhone(v) || v)
					}
				]}
				submitUrl='tck_users/signup'
				onSubmitSuccess={result => {
					localStorage.setItem('shr_user', JSON.stringify(result));
					let type = localStorage.getItem('shr_type');
					if (type == 'parent')
						Bus.cast('show_student_modal');
					else
						Bus.cast('show_sponsor_modal');
				}}
				onSubmitError={err => {
					getAlert("Une erreur est survenue, vérifiez que le mail n'est pas déja inscrit et que les informations sont valides");
				}}
				beforeSend={values => {
					values.type = localStorage.getItem('shr_type');
					values.selfSignedUp = true;
					let teacherId = _.get(this, 'props.teacher._id');
					if (teacherId) {
						values.viewedTeachers = [{
							ref_id : `usr_${teacherId}`,
							fname : _.get(this, 'props.teacher.fname')
						}]
					}
					return {update : values, query : {email : values.email}};
				}}
			/>;
			openModal(formModal);
		});
		Bus.when('show_sponsor_modal', () => {
			const formTitle = localStorage.getItem('shr_formTitle');
			let formModal = 
			<FormModal
				title={formTitle}
				inputs={[
					[
						{
							value : 'fname',
							label : "Prénom du parent",
							type : 'text',
							transform : purgeNonLetters
						},
						{
							value : 'lname',
							label : "Nom du parent",
							type : 'text',
							transform : purgeNonLetters
						}
					],
					{
						value : 'email',
						label : 'Email du parent',
						type : 'email',
						check : e=>(!validateEmail(e) ? "Mail invalide" : false),
					},
					{
						value : 'phone',
						label : 'Téléphone portable du parent',
						check : v=>(!isPhone(v) ? "Numéro invalide" : false),
						transform : v=>(isPhone(v) || v)
					}
				]}
				submitUrl='tck_users/signup_finish'
				withCredentials={true}
				beforeSend={
					values => (
						{
							otherInfos : _.set(values, 'type', 'parent'),
							user : JSON.parse(localStorage.getItem('shr_user')),
							teacherId : this.props.teacher._id,
							subject : this.state.subject,
							level : this.state.level,
							firstMessage : this.state.message,
							fromTeacher : this.props.fromTeacher
						}
					)
				}
				onSubmitSuccess={(suc) => {
					setCookie('loginCookie', suc._id);
					setCookie('cookey', _.get(suc, 'devInfos.cookey'));
					Bus.cast('show_success_modal_1');
				}}
				onSubmitError={err => {
					console.log('err', err);
					// getAlert("Une erreur est survenue, vérifiez que le mail n'est pas déja inscrit et que les informations sont valides");
				}}
			/>;
			openModal(formModal);
		});
		Bus.when('show_student_modal', () => {
			const formTitle = localStorage.getItem('shr_formTitle');
			let formModal = 
			<FormModal
				title={formTitle}
				inputs={[
					[
						{
							value : 'fname',
							label : "Prénom de l'élève",
							type : 'text',
							transform : purgeNonLetters
						},
						{
							value : 'lname',
							label : "Nom de l'élève",
							type : 'text',
							transform : purgeNonLetters
						}
					],
					{
						value : 'email',
						label : "Email de l'élève",
						type : 'email',
						check : e=>(!validateEmail(e) ? "Mail invalide" : false),
					},
					{
						value : 'phone',
						label : "Téléphone portable de l'élève",
						check : v=>(!isPhone(v) ? "Numéro invalide" : false),
						transform : v=>(isPhone(v) || v)
					}
				]}
				submitUrl='tck_users/signup_finish'
				withCredentials={true}
				beforeSend={
					values => (
						{
							otherInfos : _.set(values, 'type', 'student'),
							user : JSON.parse(localStorage.getItem('shr_user')),
							teacherId : this.props.teacher._id,
							subject : this.state.subject,
							level : this.state.level,
							firstMessage : this.state.message,
							fromTeacher : this.props.fromTeacher
						}
					)
				}
				onSubmitSuccess={(suc) => {
					console.log('suc', suc);
					setCookie('loginCookie', suc._id);
					setCookie('cookey', _.get(suc, 'devInfos.cookey'));
					Bus.cast('show_success_modal_1');
				}}
				onSubmitError={err => {
					getAlert("Une erreur est survenue, vérifiez que le mail n'est pas déja inscrit et que les informations sont valides");
				}}
			/>;
			openModal(formModal);
		});
		Bus.when('show_success_modal_1', () => {
			let successModal1 = 
			<ClassicModal
				className='tcb-modal'
				close={true}
				title="Message envoyé !"
				content={
					<div className='flex fdc jcse aic'>
						<div className='tcb-modalImage'>
							<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/Check(1).png'></img>
						</div>
						<p className='tcb-modalText'>Nous vous enverrons un mail et un sms quand {this.props.teacher.fname} aura répondu (si jamais, vérifiez vos spams)</p>
						<div className='tcb-modalButtons'>
							<GreenButton onClick={Bus.fcast('show_success_modal_2')}>
								<span>Suivant</span>
							</GreenButton>
						</div>
					</div>
				}
			/>
			openModal(successModal1);
		});
		Bus.when('show_success_modal_2', () => {
			let successModal2 = 
			<ClassicModal
				className='tcb-modal'
				close={true}
				title="Connectez vous et planifiez votre RDV pédagogique"
				content={
					<div className='flex fdc jcse aic'>
						<div className='tcb-modalImage'>
							<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/bonjour_cours_dessai.png'></img>
						</div>
						<p className='tcb-modalText'>{this.props.teacher.fname} répondra à toutes vos questions pendant les 20 min de votre RDV.</p>
						<div className='tcb-modalButtons'>
							<GreenButton onClick={Bus.fcast('show_success_modal_3')}>
								<span>Suivant</span>
							</GreenButton>
						</div>
					</div>
				}
			/>
			openModal(successModal2);
		});
		Bus.when('show_success_modal_3', () => {
			let successModal3 = 
			<ClassicModal
				className='tcb-modal'
				close={true}
				title="À l’heure prévue, rencontrez votre Sherpa !"
				content={
					<div className='flex fdc jcse aic'>
						<div className='tcb-modalImage'>
							<img src='https://sherpas-uploads.s3.eu-west-3.amazonaws.com/laptop_bonjour.png'></img>
						</div>
						<p className='tcb-modalText'>Le rendez-vous pédagogique aura lieu sur notre plateforme. Vous verrez, c’est très simple !</p>
						<div className='tcb-modalButtons'>
							<GreenButton onClick={() => (window.location = '/chat')}>
								<span>Suivant</span>
							</GreenButton>
						</div>
					</div>
				}
			/>
			openModal(successModal3);
		});
	}

	handleTextareaChange = e => {
		this.setState({message : e.target.value});
	};

	handleSelectChange = e => {
		let subjectLevel = e.target.value;
		let splitted = subjectLevel.split('___');
		let subject = splitted[0];
		let level = splitted[1];
		this.setState({
			selectedPrice : e.target.value,
			subject,
			level
		});
	}

	handleSendMessageButton = () => {
		const {user} = this.context;
		if (!user) {
			if (isMobile)
				Bus.cast('show_mobile_message_modal');
			else
				Bus.cast('show_type_modal');
		}
		else {
			if (this.hasTeacher) {
				Router.push({
					pathname: '/chat',
				})
			}
			else {
				getConfirm("Envoyer le message à ce professeur ?")
				.then(() => {
					api.post('tck_users/create_workspace', {
						auth : this.context.auth,
						teacherId : this.props.teacher._id,
						userId : user._id,
						firstMessage : this.state.message,
						subject : this.state.subject,
						level : this.state.level,
						fromTeacher : this.props.fromTeacher
					}).then(suc => {
						console.log('worjspace new', suc);
						Router.push({
							pathname: '/chat',
						});
					})
					.catch(err => {
						console.error('err', err);
						getAlert("Une erreur est survenue");
					});
				}).catch((err) => console.log('refuse', err));
			}			
		}
	}

	render() {
		let props = this.props;
		const {teacher} = props;
		return (
			<div className={`TeacherContactBox flex fdc jcse ${props.className || ''}`}>
				<div className='flex jcse aic mob__hide'>
					<div className='tcb-image'>
						<img src={teacher.profile.picture}></img>
					</div>
					<div className='tcb-smallInfo'>
						<p className='cb26'>
							Contactez {teacher.fname}
						</p>
						<div className='flex jcfs aic relw100'>
							{/* <span className='tcb-stars'>
								⭐️ 4.76
							</span>
							<span className='tcb-reviews'>(123 avis)</span> */}
							{/* <span className='tcb-love'></span> */}
						</div>
					</div>
				</div>
				<div className='tcb-smallAlert relw100 flex aic jcc mob__hide'>
					<SmallAlert type='warning'>
						{`Rencontrez ${teacher.fname} pour un Rdv gratuit. Demandez-lui juste en-dessous !`}
					</SmallAlert>
				</div>
				<div className='tcb-textarea relw100 flex aic jcc mob__hide'>
						<textarea 
							onChange={this.handleTextareaChange.bind(this)}
							placeholder={`Bonjour ${teacher.fname} ! Je cherche un professeur. Êtes-vous disponible pour un rendez-vous pédagogique de 20 min ? J’attends votre réponse !`}
						/>
				</div>
				<div className='tcb-select relw100 flex fdc aic jcc'>
					<select value={this.state.selectedPrice} onChange={this.handleSelectChange.bind(this)}>
						<option disabled key={'placeholder'+Math.random()} value='placeholder'>Choisissez une matière</option>
						{
							Object.keys(this.props.subjectsTaught).map(subject => {
								let s = this.props.subjectsTaught[subject];
								let subOptions = Object.keys(s).map(level => {
									if (level == '_realName')
										return ;
									let l = s[level];
									return (
										<option key={subject+level+Math.random()} value={`${subject}___${level}`}>{s._realName} - {l._realName} | {Math.floor(l.price/100)}€/h</option>
									)
								})
								return subOptions;
							})
						}
					</select>
				</div>
				<div className='tcb-button relw100 flex aic jcc'>
					<GreenButton disabled={_.isNil(this.state.selectedPrice) || this.state.selectedPrice == 'placeholder'} onClick={this.handleSendMessageButton.bind(this)}>
						Envoyer un message
					</GreenButton>
				</div>
			</div>
		)	
	}
};
TeacherContactBox.defaultProps = {
	fromTeacher : false
};
export default TeacherContactBox;