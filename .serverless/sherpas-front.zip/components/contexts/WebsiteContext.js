import React from 'react';

const WebsiteContext = React.createContext();

export default WebsiteContext;