import Axios from 'axios';
import io from 'socket.io-client';
import _ from 'lodash';
import {getInitLoginCookies, getCookie} from '/static/tools/tools.js';

const ZOGHEAD = {
	zoglobis: 'zaemAnervi3ZsbFAezQXcErd-EY7ygWQfrWmExrpeeBwHjcKk-GkPaFwK4CmZhaPhPgQcoQWin',
	maracas: 'DjfxZzVbZGZcPYPU3QdgJTNZ'
};
export {ZOGHEAD};

const IN_PROD = true;
export {IN_PROD};

const API_HOST = 
// 'http://localhost:3000';
// 'https://raph.sherpas.co';
'https://mariac.sherpas.co';
const PES_HOST =
// 'http://localhost:7777';
'https://casual-evolution-socker.sherpas.co';
const STRIPE_PUB_KEY =
// 'pk_test_Do3a1fdsXH5aYNXHwilUA4jI';
'pk_live_BekrXYy0ap4Bo5BNN71rN4XO';
const QKIT_HOST = 
// 'http://localhost:8083';
'https://qkit.les-sherpas.co';
export {API_HOST, PES_HOST, STRIPE_PUB_KEY, QKIT_HOST};

const getApiFinalEndpoint = endpoint => (endpoint[0] == '/') ? `${API_HOST}${endpoint}` : `${API_HOST}/${endpoint}`;

const apiDefaultOptions = {
	headers : ZOGHEAD,
	withCredentials : true
};
const api = {
	post : (endpoint, data = {}, options) => {
		options = Object.assign(apiDefaultOptions, options);
		return (new Promise((resolve, reject) => {
			Axios.post(getApiFinalEndpoint(endpoint), data, options)
			.then(suc => {
				let result = _.get(suc, 'data.result');
				let success = _.get(suc, 'data.success');
				if (result === undefined || !success)
					return reject(suc);
				return resolve(result);
			})
			.catch(reject)
		}));
	},
	get : (endpoint, options) => {
		options = Object.assign(apiDefaultOptions, options);
		return (new Promise((resolve, reject) => {
			Axios.get(getApiFinalEndpoint(endpoint), options)
			.then(suc => {
				let result = _.get(suc, 'data.result');
				let success = _.get(suc, 'data.success');
				if (result === undefined || !success)
					return reject(suc);
				return resolve(result);
			})
			.catch(reject)
		}));
	}
};
export {api};

const uploadToS3 = function(file, auth = {}, maxLimit = 5000000, acceptedTypes = ['image/gif', 'image/jpg', 'image/jpeg', 'image/png',
'application/pdf', 'video/webm', 'video/mp3', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']) {
	return (new Promise((resolve, reject) => {
		if (!file.size || file.size > maxLimit) {
			alert("Le fichier est trop gros, veuillez ne pas dépasser 5Mo");
			return reject('file_too_big');
		}
		if (!file.type || acceptedTypes.indexOf(file.type) <= 0) {
			alert("Le fichier n'est pas dans un format adéquat");
			return reject('file_not_with_good_type');
		}
		const fileData = _.pick(file, ['name', 'type', 'size']);
		// let uploadUrl = `https://61tjfwyrm5.execute-api.eu-west-3.amazonaws.com/production/uploads/gen_presigned_url`;
		let uploadUrl = `${API_HOST}/uploads/gen_presigned_url`;
		Axios.post(uploadUrl, {
			file : fileData, auth
		}, {headers : ZOGHEAD, withCredentials : true})
		.then(suc => {
			let data = suc.data;
			if (!data.success)
				return console.error('Problem', data.error);
			let url = data.result.presignedUrl;
			console.log('presigned', url);
			Axios.put(url, file, {headers : {'Content-Type' : file.type, 'Content-Disposition' : 'inline'}})
			.then(uploaded => {
				resolve({
					finalUrl : data.result.finalUrl,
					presignedUrl : url,
					awsResult : uploaded
				});
			})
			.catch(reject)
		})
		.catch(reject)
	}))
};
export {uploadToS3};

const zoglosok =  'WEtoUesM7PHhwXiTYDiYdBPF-NMYewXnZNVowGFhHFWZW9hUk-GuoKjRctaEYL7CoxigopZrLP';
const initWorkspaceSocket = (room, connectInfos) => {
	const {loginCookie, cookey} = connectInfos;
	let socketUrl = `${PES_HOST}/workspaces?room=${room}&zoglosok=${zoglosok}`;
	if (loginCookie)
		socketUrl += `&loginCookie=${loginCookie}`;
	if (cookey)
		socketUrl += `&cookey=${cookey}`;
	let socket = io(socketUrl, {
		autoConnect: false
	});
	socket.on('connect', () => {
		console.log("Je suis connecte au wks");
	});
	socket.on('disconnect', data => {
		console.log("Vire par les gens du wks", data);
	});
	socket.on('reconnect', data => {
		console.log('Je me recon..');
	})
	socket.on('ser_new_message', data => {
		console.log("On me dit des trucs de message", data);
	});
	socket.on('ser_new_quill_delta', data => {
		console.log("On me dit des trucs de quill_delta", data);
	});
	socket.on('ser_launch_course', data => {
		console.log("On me dit des trucs de launch_course", data);
	});
	socket.on('ser_new_file', data => {
		console.log("On me dit des trucs de file", data);
	});
	socket.on('ser_new_nsa', data => {
		console.log("On me dit des trucs de nsa", data);
	});
	socket.on('ser_wks_ready', (data) => {
		console.log("Workspace Ready", data);
		// socket.emit('cli_new_message', {content : "Bonjour Message https://bit.ly/2Jk58il", date : Date.now()});
		// socket.emit('cli_new_quill_delta', 'BONJOUR QUILL');
		// socket.emit('cli_launch_course', 'BONJOUR COURSE');
		// socket.emit('cli_new_file', {content : "Bonjour File", date : Date.now(), file : 'https://bit.ly/2Jk58il'});
	});
	return socket;
}
export {initWorkspaceSocket};

const initNotificationsSocket = (connectInfos) => {
	const {loginCookie, cookey} = connectInfos;
	let socketUrl = `${PES_HOST}/notifications?zoglosok=${zoglosok}`;
	if (loginCookie)
		socketUrl += `&loginCookie=${loginCookie}`;
	if (cookey)
		socketUrl += `&cookey=${cookey}`;
	let socket = io(socketUrl, {
		autoConnect: false
	});
	socket.on('connect', () => {
		console.log("Je suis connecte aux notifs");
	});
	socket.on('disconnect', data => {
		console.log("Vire par les gens des notifs", data);
	});
	socket.on('ser_notification_message_missed', data => {
		console.log("On me dit des trucs de message missed", data);
	});
	socket.on('ser_new_notification', data => {
		console.log("On me dit des trucs de new notification", data);
	});
	return socket;
}
export {initNotificationsSocket};

//To use in getINitialProps to have all the classic data of user and lang
const getDataWithCookiesDefaultOptions = {withChats : false, langCollections : ['subjects', 'levels', 'seo_levels']};
const getDataWithCookies = async (ctx, options) => {
	options = Object.assign(getDataWithCookiesDefaultOptions, options);
	const auth = getInitLoginCookies(ctx);
	let user = undefined;
	if (auth.loginCookie && auth.cookey) {
		user = await api.post(`tck_users/get_all_infos`, {
			auth,
			withChats : options.withChats
		}).catch(err => console.error('Error to get the user', err));
	}
	let lang = {};
	const {langCollections} = options;
	for (let coll of langCollections) {
		let collection = await api.post(
			`lang/get_docs_by_query`,
			{collection : coll}
		);
		lang[coll] = collection;
	}
	return {
		lang,
		user,
		auth
	};
};
export {getDataWithCookies};

const getParam = (ctx, param) => (_.get(ctx, `req.params.${param}`) || _.get(ctx, `query.${param}`));
export {getParam};

const getAuth = (user) => {
	let loginCookie = _.get(user, '_id');
	let cookey = _.get(user, 'devInfos.cookey');
	if (loginCookie && cookey) {
		return {loginCookie, cookey};
	}
	else {
		try {
			let auth = {
				loginCookie : getCookie('loginCookie', window['__sherpas_auth'].loginCookie),
				cookey : getCookie('cookey', window['__sherpas_auth'].cookey)
			}
			if (auth.loginCookie && auth.cookey)
				return auth;
			else
				return;
		}
		catch (e) {
			console.error('Error to get auth', e);
			return;
		}
	}
};
export {getAuth};