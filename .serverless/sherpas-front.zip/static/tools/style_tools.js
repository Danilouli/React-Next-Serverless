const getCSSProp = function(elt, cssProp) {
	return (window.getComputedStyle(elt, null).getPropertyValue(cssProp));
};

const getWidth = function(elt) {
	return (parseFloat(elt.getCSSProp("width")));
};

const getHeight = function(elt) {
	return (parseFloat(elt.getCSSProp("height")));
};

const getCSSNumProp = function(elt, cssProp) {
	return (parseFloat(window.getComputedStyle(elt, null).getPropertyValue(cssProp)));
};

const setCSSNumPropToUnit = function(elt, cssProp, unit = 'px') {
	let cssNumProp = elt.getCSSNumProp(cssProp);
	if (cssNumProp) {
		elt.style[cssProp] = cssNumProp + '' + unit;
	}
};

export {getCSSProp, getWidth, getHeight, getCSSNumProp, setCSSNumPropToUnit}