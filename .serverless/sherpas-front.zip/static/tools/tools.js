import * as JsonDiff from 'json-diff';
import _ from 'lodash';
import Bus from '/static/tools/bus.js';

const deepAssign = function(obj1, obj2) {
	for (let key in obj2) {
		if (!(typeof obj1[key] == 'object' && obj2[key] && typeof obj2[key] == 'object')) {
			obj1[key] = obj2[key];
		}
		else if (obj1[key] != null && obj2[key] != null)
			deepAssign(obj1[key], obj2[key]);
	}
	return obj1;
};
export {deepAssign};

const getCircularReplacer = () => {
	const seen = new WeakSet();
	return (key, value) => {
	  if (typeof value === "object" && value !== null) {
		if (seen.has(value)) {
		  return;
		}
		seen.add(value);
	  }
	  return value;
	};
};

const decircularize = obj => {
	return JSON.parse(JSON.stringify(obj, getCircularReplacer()));
};
export {decircularize};

const cleanDiff = function(oldObj, newObj) {
	const i1 = decircularize(oldObj);
	const i2 = decircularize(newObj);
	const diff = JsonDiff.diff(i1, i2);
	return diff;
};
export {cleanDiff};

const didPathChanged = function(diff, path) {
	if (!diff)
		return false;
	const newChange = _.get(diff, `${path}.__new`);
	if (newChange)
		return {changed : true, action : 'modified', value : newChange};
	let splittedPath = path.split('.');
	let research = diff;
	for (let i = 0; i < splittedPath.length; i++) {
		let s = splittedPath[i];
		if (!research[s]) {
			if (research[`${s}__added`]) {
				research = research[`${s}__added`] 
			}
			else if (research[`${s}__deleted`]) {
				return {changed : true, action : 'deleted'};
			}
			else
				return {changed : false}
		}
		else
			research = research[s];
	}
	return {changed : true, action : 'added', value : research};
};
export {didPathChanged};

const cleanEqual = function(a, b) {
	if (typeof a != typeof b)
		return false;
	if (typeof a == 'object') {
		const diff = cleanDiff(a, b);
		return !diff;
	}
	return _.isEqual(a, b);
};
export {cleanEqual}

let TIMEGLOBS = {
	second : 1000
};
TIMEGLOBS.minute = TIMEGLOBS.second*60;
TIMEGLOBS.hour = TIMEGLOBS.minute*60;
TIMEGLOBS.day = TIMEGLOBS.hour*24;
TIMEGLOBS.week = TIMEGLOBS.day*7;
TIMEGLOBS.month = TIMEGLOBS.week*4;
TIMEGLOBS.year = TIMEGLOBS.day*365;
export {TIMEGLOBS};

const DEFAULTIMG = 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/avatars/avatar-1.png';
export {DEFAULTIMG};

const ZOGHEAD = {
	zoglobis: 'zaemAnervi3ZsbFAezQXcErd-EY7ygWQfrWmExrpeeBwHjcKk-GkPaFwK4CmZhaPhPgQcoQWin',
	maracas: 'DjfxZzVbZGZcPYPU3QdgJTNZ'
};
export {ZOGHEAD};

const jsGet = (url, toGet) => {
	if (!url)
		return;
	let split1 = url.split('?');
	split1 = split1[1];
	if (!split1)
		return;
	split1 = split1.split('&');
	let finalSplit = split1.map(s => s.split('=')).find(s => s[0] == toGet);
	if (!finalSplit)
		return;
	return finalSplit[1];
};
export {jsGet};

const buildMessageJsx = (message, jsxProps = {onElementLoad : e=>e}) => {
	let fileUrl = _.get(message, 'file.url');
	if (fileUrl) {
		const fileType = _.get(message, 'file.type', '');
		const isImage = fileType.indexOf('image') >= 0 || fileUrl.match(/.jpg$|.png$|.gif$/g);
		const isVideo = fileType.indexOf('video') >= 0 || fileUrl.match(/.mp4$|.webm$/g);
		if (isImage) 
			return <a href={fileUrl} target='_blank'><img src={fileUrl} onLoad={jsxProps.onElementLoad}></img></a>;
		if (isVideo) 
			return <video controls src={fileUrl} type={fileType} onLoad={jsxProps.onElementLoad}></video>;
	}
	return <span dangerouslySetInnerHTML={{__html : message.content}}></span>
};
export {buildMessageJsx};

const concatMessages = function(pastMessages = [], futureMessages = []) {
	let concatenated = _.uniqBy([...futureMessages, ...pastMessages], e => e.date);
	concatenated.sort((e1, e2) => (e1.date - e2.date));
	return concatenated;
};
export {concatMessages};

const datify = function(ts, options) {
	if (!options)
		return `Le ${(new Date(ts).toLocaleString('fr-FR', {timeZone : 'Europe/Paris'}))}`;
	else {
		let date = (new Date(ts)).toLocaleDateString('fr-FR', {
			timeZone : 'Europe/Paris', ...options
		});
		if (!options.day && !!options.hour && !!options.minute) {
			let spl = date.split('à');
			return (spl[spl.length - 1] || '').trim();
		}
		else
			return date;
	}
};
export {datify};

const setCookie = (cname, cvalue, exdays = 365) => {
	if (_.isNil(cvalue))
		return;
	let d = new Date();
	d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
	let expires = "expires="+d.toUTCString();
	document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
};
export {setCookie};

const setLoginCookies = loginCookies => {
	if (!loginCookies)
		return;
	setCookie('loginCookie', loginCookies.loginCookie);
	setCookie('cookey', loginCookies.cookey);
	window['__sherpas_auth'] = loginCookies;
};
export {setLoginCookies};

const deleteCookie = cname => {
	let d = new Date();
	d.setTime(d.getTime() -  24 * 60 * 60 * 1000);
	let expires = "expires="+d.toUTCString();
	document.cookie = cname + "=;" + expires + ";path=/";
};
export {deleteCookie};

const deleteLoginCookies = () => {
	deleteCookie('loginCookie');
	deleteCookie('cookey');
};
export {deleteLoginCookies};

const getCookie = (cname, cookieString) => {
	if (!cname || !cookieString)
		return undefined;
	let name = cname + "=";
	let ca = cookieString.split(';');
	for(let i = 0; i < ca.length; i++) {
		let c = ca[i];
		while (c.charAt(0) == ' ') {
		c = c.substring(1);
		}
		if (c.indexOf(name) == 0) {
		return c.substring(name.length, c.length);
		}
	}
	return undefined;
};
export {getCookie};

const getInitCookie = (ctx = {}, cname = 'loginCookie') => {
	const {req} = ctx;
	if (req) {
		const cookieString = _.get(req, 'headers.cookie');
		return (getCookie(cname, cookieString) || jsGet(_.get(req, 'url'), cname));
	}
	else {
		return getCookie(cname, document.cookie) || jsGet(window.location.toString(), cname);
	}
};
export {getInitCookie};

const getInitLoginCookies = ctx => ({
	loginCookie : getInitCookie(ctx, 'loginCookie'),
	cookey : getInitCookie(ctx, 'cookey')
});
export {getInitLoginCookies};

const stringIdize = function(umid) {
	if (!umid)
		return undefined;
	if (typeof umid != 'string')
		return umid.toString();
	let umidArr = umid.split('_');
	let umidStr = umidArr[umidArr.length - 1];
	return umidSt
};
export {stringIdize};

let sameId = function(umid1, umid2) {
	if (!umid1 || !umid2)
		return false;
	return (stringIdize(umid1) == stringIdize(umid2));
};
export {sameId};

let refIdize = function(umid, refPrefix) {
	if (!umid || !refPrefix)
		return undefined;
	let stringUmid = stringIdize(umid);
	if (stringUmid)
		return (refPrefix + '_' + stringIdize(umid));
	return undefined;
};
export {refIdize};

let chatIdize = function(wksId, type = 'student') {
	let wksRefId = refIdize(wksId, 'wks');
	return `_${wksRefId}_${type}`;
};
export {chatIdize};

let typize = function(chatId) {
	let spl = chatId.split('_');
	let convType = spl[spl.length - 1];
	return convType;
};
export {typize};

const logErrF = (log, toRet) => {
	return (err => {
		console.error(log, "ERROR :", err);
		return toRet || err;
	})
};
export {logErrF};

const shuffleArray = function(arr) {
	for (let i = arr.length - 1; i > 0; i--) {
		let j = Math.floor(Math.random() * (i + 1));
		[arr[i], arr[j]] = [arr[j], arr[i]];
	}
	return arr;
};
export {shuffleArray};

const getLinksFromContext = (ctx) => {
	const subjects = _.get(ctx, 'lang.subjects');
	const seoLevels = _.get(ctx, 'lang.seo_levels');
	const onBoardSubjs = subjects.filter(s=>_.get(s, 'metadata.onBoard'));
	const subjectLinks = onBoardSubjs.map(s=>({
		name : s.name,
		as : `/cours/${s.value}`,
		url : `/course_seo_page?param1=${s.value}`
	}));
	subjectLinks.push({
		name : "Voir +",
		url : "/gallery",
		as : "/professeurs"
	});
	const levelLinks = seoLevels.map(s=>({
		name : s.name,
		as : `/cours/${s.value}`,
		url : `/course_seo_page?param1=${s.value}`
	}));
	levelLinks.push({
		name : "Voir +",
		url : "/gallery",
		as : "/professeurs"
	});
	return {
		subjectLinks,
		levelLinks
	};
};
export {getLinksFromContext};

const getClassicContext = (props, refetchAll = e=>e) => {
	let context = Object.assign({}, props);
	const getSubject = subject => context.lang.subjects.find(e => (e.value == subject));
	const getLevel = level => context.lang.levels.find(e => (e.value == level));
	context.getSubject = getSubject;
	context.getLevel = getLevel;
	context.refetchAll = async function(callback = e=>e) {
		try {
			await refetchAll(context);
			// console.log('new context', context);
			Bus.cast('context_refetched_all', {context, callback});
		}
		catch (err) {
			console.error("Impossible to refetch context", err);
		}
	};
	return context;
}
export {getClassicContext};

const reduceToWordsMaxCarac = (str, maxCarac) => {
	str = str.replace(/<[^>]*>?/gm, '');
	let spl = str.split(' ');
	let ret = '';
	for (let s of spl) {
		if (ret.length > maxCarac) {
			let spl2 = ret.split(' ');
			spl2.pop();
			ret = spl2.join(' ');
			break;
		}
		ret += `${s} `;
	}
	ret += '...';
	return ret;
}
export {reduceToWordsMaxCarac};

const buildTeacherTitleAndDescription = function(teacher) {
	let title = _.get(teacher, 'profile.description.title', '');
	let description = _.get(teacher, 'profile.description.methodology', '');
	const su = teacher.subjectsTaught;
	let minPrice = 20;
	if (su)
		minPrice = (Math.min(...(Object.keys(su).map(s=>(Math.min(...(Object.keys(su[s]).map(l=>su[s][l].price || Infinity))))))))/100;
	title = reduceToWordsMaxCarac(title, 33);
	description = reduceToWordsMaxCarac(description, 133);
	return {
		title : `${teacher.fname} - ${title} - Les Sherpas`,
		description : `${minPrice}€/h - ${description}`,
	};
};
export {buildTeacherTitleAndDescription};