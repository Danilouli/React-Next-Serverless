import _ from 'lodash';
import * as Tools from './tools.js';

let Bus = {};
Bus.when = function(eventName, cbFunc, options = {}, listener = window ) {
		if (!listener)
			listener = window;
		window.removeEventListener(eventName, cbFunc);
		window.addEventListener(eventName, cbFunc);
		return cbFunc;
	};
Bus.cast = function(eventName, detail, options = {}, caster = window) {
		if (!caster)
			caster = window;
		caster.dispatchEvent(new CustomEvent(eventName, {detail : detail}));
	};
Bus.fcast = function(eventName, detail, options = {}, caster) {
	return (() => Bus.cast(eventName, detail, options, caster));
}
Bus.stop = function(eventName, cbFunc, options = {}, listener = window) {
		if (!listener)
			listener = window;
		window.removeEventListener(eventName, cbFunc);
	};
Bus.bindEventHandlers = function(handlersObj) {
	let hKeys = Object.keys(handlersObj);
	for (let hKey of hKeys) {
		Bus.when(hKey, handlersObj[hKey]);
	}
};
Bus.unbindEventHandlers = function(handlersObj, options = {}, listener = window) {
	let hKeys = Object.keys(handlersObj);
	for (let hKey of hKeys) {
		Bus.stop(hKey, handlersObj[hKey], options, listener);
	}
};
Bus.trunk = {};
Bus.setTrunk = e=>e;
Object.defineProperty(Bus, 'trunk', {
	get : () => {
		try {
			return window['__react_bus_trunk'];
		}
		catch (e) {
			return {};
		}
	}
});
Bus.initTrunk = function() {
	if (!window['__react_bus_trunk']) {
		window['__react_bus_trunk'] = {};
		Bus.setTrunk = (upFunction, options = {cast : true, rerender : false, data : {}}) => {
			let opt = Object.assign({cast : true, rerender : false, data : {}}, options);
			if (typeof upFunction != 'function')
				Tools.deepAssign(window['__react_bus_trunk'], upFunction);
			else
				upFunction(window['__react_bus_trunk']);
			const {cast, data, rerender} = opt;
			if (cast) {
				let eventToCast = 'bus_trunk_updated';
				if (typeof cast  == 'string')
					eventToCast = cast;
				Bus.cast(eventToCast, {data : data, rerender : rerender});
				if (eventToCast != 'bus_trunk_updated')
					Bus.cast('bus_trunk_updated', {data : data, rerender : rerender});
			}
			return;
		}
		Bus.cast('bus_trunk_initialized');
	}
};
Bus.linkToTrunk = function(elt, options = {sendState : true, eltName : ''}) {
	let link = {};
	link.subscribe = function() {
		Bus.when('bus_trunk_updated', v => {
			if (v.detail.rerender) {
				elt.setState(s=>s);	
			}
		});
		if (options.sendState) {
			Bus.when('bus_trunk_initialized', () => {
				Bus.setTrunk(old => {
					old[options.eltName] = elt.state;
				});
			});	
		}
	};
	link.get = function(path) {
		return `${_.get(Bus, `trunk.${path}`, '')}`;
	};
	link.sendState = function(name) {
		Bus.setTrunk(old => {
			old[elt.constructor.name] = elt.state;
		});
		Bus.when('bus_trunk_initialized', () => {
			Bus.setTrunk(old => {
				old[options.eltName] = elt.state;
			});
		});	
	};
	link.sendChanges = function(prevProps, prevState, snapshot, opts) {
		const isSame = _.isEqual(prevState, elt.state);
		_.set(opts, 'data.fromElt', elt.constructor.name);
		if (!isSame && elt.state && prevState) {
			Bus.setTrunk(old => {
				old[elt.constructor.name] = elt.state;
			}, opts);
		}
	};
	return link;
};
Bus.whenWksIsReady = function(callback) {
	let wks = _.get(Bus.trunk, 'workspace');
	if (wks)
		callback({workspace : wks})
	else
		Bus.when('ser_wks_ready', data => callback(data.detail));
};
Bus.subscribeToContext = function(elt) {
	const refetchedCallback = data => {
		console.log('refetched', data);
		let {context, callback} = data.detail;
		elt.setState({context}, callback);
	};
	const refetchCallback = data => {
		let callback = _.get(data, 'detail.callback', e=>e);
		elt.state.context.refetchAll(callback);
	};
	Bus.when('context_refetched_all', refetchedCallback);
	Bus.when('context_refetch_all', refetchCallback);
	return ({
		stop : () => {
			Bus.stop('context_refetched_all', refetchedCallback);
			Bus.stop('context_refetch_all', refetchCallback);
		}
	})
};
export default Bus;