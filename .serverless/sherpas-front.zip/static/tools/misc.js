import _ from 'lodash';

const validateEmail = mail => {
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
		return (true)
	return (false)
};
export {validateEmail};

const isLetterString = string => {
	return !Array.from(string).find(e => !e.match(/À|È|Ì|Ò|Ù|à|è|ì|ò|ù|Á|É|Í|Ó|Ú|Ý|á|é|í|ó|ú|ý|Â|Ê|Î|Ô|Û|â|ê|ô|û|Ã|Ñ|Õ|ã|ñ|õ|Ä|Ë|Ï|Ö|Ü|ä|ë|ï|ö|ü|ç|Ç|[a-z]|[A-Z]|-/g))
};
export {isLetterString};

const isNumberString = string => {
	return !Array.from(string).find(e => !e.match(/[0-9]/g))
};
export {isNumberString};

const purgeNonLetters = string => {
	let arrFrom = Array.from(string);
	let filtered = arrFrom.filter(isLetterString);
	return filtered.join('', filtered);
};
export {purgeNonLetters};

const purgeNonNumbers = string => {
	let arrFrom = Array.from(string);
	let filtered = arrFrom.filter(isNumberString);
	return filtered.join('', filtered);
};
export {purgeNonNumbers};

const capitalize = string => {
	return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}
export {capitalize};

const isPhone = function(string) {
	let matches = string.replace(/\s+/g,'').match(/^((\+)33|0)[6-7](\d{2}){4}$/g);
	if (!matches)
		return false;
	let phone = matches[0];
	if (phone[0] != '+')
		phone = '+33'+phone.substring(1);
	return phone;
};
export {isPhone};

const getBrowser = () => {
	let isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
	let isFirefox = typeof InstallTrigger !== 'undefined';
	let isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));
	let isIE = /*@cc_on!@*/false || !!document.documentMode;
	let isEdge = !isIE && !!window.StyleMedia;
	let isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);
	let isBlink = (isChrome || isOpera) && !!window.CSS;
	return {
		opera : isOpera,
		firefox : isFirefox,
		safari : isSafari,
		ie : isIE,
		edge : isEdge,
		chrome : isChrome,
		blink : isBlink
	}
};
export {getBrowser};

const isChrome = () => {
	let browsers = getBrowser();
	return !!browsers.chrome;
};
export {isChrome};

const buildBullshit = contents => {
	if (!contents)
		return <span></span>;
	let txtAc = _.get(contents, 'txt_accroche.HTMLContent', '');
	let h3Txts = [];
	for (let i = 1; i <= 20; i++) {
		let h3 = _.get(contents, `h3_n${i}.HTMLContent`);
		let txt = _.get(contents, `txt_n${i}.HTMLContent`);
		if (!h3 || !txt)
			break;
		let jsx = (
			<div key={i}>
				<h3>{h3}</h3>
				<p dangerouslySetInnerHTML={{__html : txt}}></p>
			</div>
		);
		h3Txts.push(jsx);
	}
	let retJsx = (
		<div>
			<p>{txtAc}</p>
			{h3Txts}
		</div>
	);
	return retJsx;
};
export {buildBullshit};