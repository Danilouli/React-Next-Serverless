import {QKIT_HOST} from '/static/tools/network.js';

class Flow {

	throwError(message) {
		console.warn(message);
		return (false);
	}

	assignIframe() {
		let options = this.options;
		let container = document.querySelector(this.selector);
		let iframe  = document.createElement('iframe');
		let userId = this.userId;
		if (container && container.hasAttribute('hasFlow')) container.removeChild(container.getElementsByTagName('iframe')[0]);
		iframe.allow = 'camera; microphone';
		let iframeUrl = userId ? `${QKIT_HOST}/qkit/view/flows/${this.id}/user/${userId}` : `${QKIT_HOST}/qkit/view/flows/${this.id}`;
		setTimeout(() => (iframe.src = iframeUrl), 0);
		iframe.style = "border: none;";
		iframe.classList.add('qkit_iframe');
		if (!(container && container.hasAttribute('hasFlow'))) container.setAttribute('hasFlow', true);
		container.appendChild(iframe);
		let iframeDoc = (iframe.contentDocument || iframe.contentWindow);
		let assignOptions = this.assignOptions;
		if (iframeDoc.document) iframeDoc = iframeDoc.document;
		iframe.addEventListener('load', () => { 
			iframe.contentWindow.postMessage({qkit_action : 'iframe_init', options : options, userId : (this.userId || 'anon_' + Math.floor(Math.random() * 99999999999999))}, '*'); 
		});
		window.addEventListener('message', e => {
			const {data} = e;
			if (data) {
				const action = data['qkit_action'];
				if (action == 'redirect_on_finish') {
					window.location = data.urlOnFinish || '';
				}	
			}
		});
	}

	setUserCookie() {
		sessionStorage.setItem("qkitUserId", this.userId || 'anon_' + Math.floor(Math.random() * 99999999999999));
		this.assignIframe();
	}

	constructor(flow) {
		if (!flow) return ;
		let container = document.querySelector(flow.selector);
		if (!(flow.id)) return this.throwError('Please provide a flow ID.');
		if (!container) return this.throwError('Please provide a valid selector.');
		console.log(flow);
		this.userId = flow.userId || false;
		this.selector = flow.selector || 'flow-container';
		this.id = flow.id || false;
		this.options = flow.options || false;
		this.setUserCookie();
	}
}

export default Flow;
