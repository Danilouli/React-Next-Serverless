const studentReviews = [
	{
		teacher : {
			fname : 'Eliott',
			picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/elliot.png',
			title : "Prof de Français"
		},
		student : {
			fname : "Louis",
			review : "Je recommande Eliott : compétent, sympa et à l'écoute. C'est toujours un plaisir d'avoir cours et les progrès suivent.",
			stars : 4.5
		}
	},
	{
		teacher : {
			fname : 'Daniel',
			picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/agaga.JPG',
			title : "Prof de Mathématiques"
		},
		student : {
			fname : "Agnès",
			review : "Initialement un peu sceptique sur les cours en ligne, cela marche formidablement bien. Notre fils a décroché son Bac avec 19 en maths et a intégré la prépa de son choix.",
			stars : 5
		}
	},
	{
		teacher : {
			fname : 'William',
			picture : 'https://qkit.les-sherpas.co/uploads/files/5c1bb495721397360ef755f7/5c1ce5b4858a773747a8b984/v2th6fv1u.jpg',
			title : "Prof de Mathématiques"
		},
		student : {
			fname : "Thierry",
			review : "Je vous recommande d'essayer Les Sherpas, c'est très pratique et facile à utiliser, sans compter l'absence d'engagement et de frais de dossiers !",
			stars : 5
		}
	},
	{
		teacher : {
			fname : 'Lucie',
			picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Le%CC%81a.png',
			title : "Prof de Physique"
		},
		student : {
			fname : "Michelle",
			review : "Les professeurs sont de qualité, et les cours en lignes très pratiques pour trouver des disponibilités en semaine, comme en vacances. Je recommande :)",
			stars : 5
		}
	},
	{
		teacher : {
			fname : 'Mathilde',
			picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Marie.png',
			title : "Prof de Philosophie"
		},
		student : {
			fname : "Elsa",
			review : "Fleur m'a redonné confiance en mes capacités et j'ai progressé constamment grâce à ses conseils.",
			stars : 4.5
		}
	},
	{
		teacher : {
			fname : 'Clément',
			picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Vivien.png',
			title : "Prof d'Anglais"
		},
		student : {
			fname : "Jean-Luc",
			review : "Habitant dans une petite ville, les cours en ligne  permettent de trouver de bons professeurs !",
			stars : 4.5
		}
	},
	{
		teacher : {
			fname : 'Etienne',
			picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/steve.png',
			title : "Prof d'Économie"
		},
		student : {
			fname : "Théo",
			review : "Super flexibilité des horaires par rapport à l'emploi du temps de prépa, ajouté au fait d'avoir les cours chez soi sans perdre de temps dans les transports.",
			stars : 5
		}
	},
	{
		teacher : {
			fname : 'Antoine',
			picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Antoine+Mines.jpg',
			title : "Prof de Mathématiques"
		},
		student : {
			fname : "Marc",
			review : "Avoir un mentor pour ma fille a fait une énorme différence. Elle a gagné en méthodes mais surtout en confiance en elle : elle va rejoindre la Grande École dont elle rêvait ! Merci !",
			stars : 5
		}
	},
	{
		teacher : {
			fname : 'Floriane',
			picture : 'https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Floriane.png',
			title : "Prof d'Allemand"
		},
		student : {
			fname : "Charlotte",
			review : "J'aime les Sherpas parce que j'obtiens l'aide que je ne peux pas avoir dans une classe de 30 élèves.",
			stars : 5
		}
	},
	{
		teacher : {
			fname : 'Gaëlle',
			picture : "https://sherpas-uploads.s3.eu-west-3.amazonaws.com/teachers_carousel/Gae%CC%88lle.png",
			title : "Prof de Mathématiques"
		},
		student : {
			fname : "Léa",
			review : "Quand je prends des cours, je suis seule avec Gaëlle et je peux lui poser toutes mes questions, sans avoir peur de dire des bêtises.",
			stars : 5
		}
	}
];
export {studentReviews};