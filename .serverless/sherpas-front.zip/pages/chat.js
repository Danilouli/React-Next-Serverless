import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import {setLoginCookies, deepAssign, getClassicContext} from '/static/tools/tools.js';
import {getDataWithCookies, api} from '/static/tools/network.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import _ from 'lodash';
import Bus from '/static/tools/bus.js';
import Chat from '/components/mains/Chat/Chat.js';
import { getParam } from '../static/tools/network';

class App extends React.Component  {
	constructor(props) {
		super(props);
		const {auth} = props || {};
		let context = getClassicContext(props, async function(context) {
			let user = await api.post(`tck_users/get_all_infos`, {auth, withChats : 200});
			context.user = user;
		});
		context.page = 'chat';
		this.state = {context};
	}

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx, {withChats : 200});
		let chatId = getParam(ctx, 'chatId');
		console.log('chatId', chatId);
		if (chatId)
			initData.chatId = chatId;
		return initData;
	}

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		this.contextSubscribtion = Bus.subscribeToContext(this);
		let qs = document.querySelector('.LoadingScreen');
		if (qs)
			qs.setAttribute('hidden', true);	
	}

	componentWillUnmount() {
		this.contextSubscribtion.stop();
	}

	render() {
		// console.log('new context', this.state.context);
		return(
			<WebsiteContext.Provider value={this.state.context}>
				<LoadingScreen/>
				{
					this.props.user ? 
					<Layout noFooter={true} fixedNavbar={false}>
						<Chat/>
					</Layout> :
					<p>Page introuvable</p>
				}
			</WebsiteContext.Provider>
		)
	}
}
export default App;