import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import TeacherInscription from '/components/mains/TeacherInscription/TeacherInscription.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies, api} from '/static/tools/network.js';
import _ from 'lodash';
import Head from 'next/head';
import {IN_PROD} from '/static/tools/network.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		initData.page = 'teacher_inscription';
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		document.querySelector('body').scrollTo(0,0);
		let qs = document.querySelector('.LoadingScreen');
		if (qs)
			qs.setAttribute('hidden', true);	
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<Layout>
					<Head>
						{IN_PROD && <meta name="robots" content="index, follow"/>}
						<title>Inscription Professeur - Les Sherpas</title>
					</Head>
					<LoadingScreen/>
					<TeacherInscription/>
				</Layout>
			</WebsiteContext.Provider>
		)
	};
}
export default App;