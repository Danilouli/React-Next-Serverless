import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies, api} from '/static/tools/network.js';
import _ from 'lodash';
import Flow from '/static/tools/qkit.js';
import Head from 'next/head';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		let teacherId = _.get(ctx, 'req.params.teacherId') || _.get(ctx, 'query.teacherId') || _.get(initData, 'auth.loginCookie');
		console.log('teacherId', teacherId);
		let teacher = await api.post('tck_users/teachers/find_simple_user', {_id : teacherId}).catch(e=>console.error('Error to get the teacher', e));
		initData.teacher = teacher;
		initData.page = 'teacher_description';
		return initData;
	};

	async componentDidMount() {
		let auth = _.get(this, 'props.auth');
		let teacher = _.get(this, 'props.teacher');
		console.log('auth', auth);
		console.log('teacher', teacher);
		if (!teacher) {
			console.log('No good teach');
			window.location = '/landing';
			return;
		}
		setLoginCookies(auth);
		document.querySelector('body').scrollTo(0,0);
		document.querySelector('.LoadingScreen').remove();
		new Flow({
			"id": "5d52ee9eec1f4a13f0b23659",
			"selector": "#flowPreviewContainer",
			"userId" : teacher._id,
			"options" : {
				"fname" : teacher.fname
			}
		});
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<Head>
					<meta name="robots" content="noindex, nofollow"/>
					<title>Description Professeur - Les Sherpas</title>
				</Head>
				<LoadingScreen/>
				<div className='relw100vw relh100vh' id='flowPreviewContainer'></div>
			</WebsiteContext.Provider>
		)
	};
}
export default App;