import '/static/stylesheets/index.scss';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies} from '/static/tools/network.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import LandingLayout from '/components/layouts/LandingLayout/LandingLayout.js';
import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import Landing from '/components/mains/Landing/Landing.js';
import _ from 'lodash';
import Head from 'next/head';
import {IN_PROD} from '/static/tools/network.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		initData.page = 'landing';
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		if (this.props.user)
			window.location = '/home';
		else {
			document.querySelector('body').scrollTo(0,0);
			let qs = document.querySelector('.LoadingScreen');
			if (qs)
				qs.setAttribute('hidden', true);	
		}
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<LandingLayout>
					<Head>
						{IN_PROD && <meta name="robots" content="index, follow"/>}
						<title>Cours particuliers en ligne Les Sherpas - Trouvez le prof idéal !</title>
						<meta name="description" content="Trouvez les meilleurs profs en ligne à partir de 12€/h. Nos Sherpas sont issus des meilleures universités françaises. Essayez gratuitement aujourd’hui !"/>
					</Head>
					<LoadingScreen/>
					<Landing/>
				</LandingLayout>
			</WebsiteContext.Provider>
		)
	};
};
export default App;