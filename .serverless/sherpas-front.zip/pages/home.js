import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import {setLoginCookies, logErrF, deepAssign, getClassicContext, TIMEGLOBS} from '/static/tools/tools.js';
import {getDataWithCookies, api} from '/static/tools/network.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import _ from 'lodash';
import Home from '/components/mains/Home/Home.js';
import Bus from '/static/tools/bus.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
		const {auth} = props || {};
		let context = getClassicContext(props, async function(context) {
			//Refetch All
			let user = await api.post(`tck_users/get_all_infos`, {auth, withChats : false});
			const {workspaces} = user;
			let toFindRem = {
				auth : props.auth,
				"acceptation.status" : {$ne : 'canceled'},
				begin : {$gte : Date.now() - TIMEGLOBS.hour*5},
				'workspace.ref_id' : {$in : workspaces.map(w=>w.ref_id)}
			};
			let reminders = await api.post('tck_reminders/find/all', toFindRem);
			context.user = user;
			context.reminders = reminders;
		});
		context.page = 'home';
		this.state = {context};
	}

	static async getInitialProps(ctx) {
		try {
			let initData = await getDataWithCookies(ctx);
			let workspaces = _.get(initData,'user.workspaces', []);
			let toFind = {
				auth : initData.auth,
				"acceptation.status" : {$ne : 'canceled'},
				'workspace.ref_id' : {$in : workspaces.map(w=>w.ref_id)},
				begin : {$gte : Date.now() - TIMEGLOBS.hour*5}
			};
			let reminders = await api.post('tck_reminders/find/all', toFind)
			.catch(logErrF("Error to get reminder", []));
			initData.reminders = reminders;
			return initData;
		}
		catch (err) {
			console.error('err', err);
			return {};
		}
	}

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		this.contextSubscribtion = Bus.subscribeToContext(this);
		// document.querySelector('body').scrollTo(0,0);
		// document.querySelector('.LoadingScreen').remove();
		// {headers : {zoglobis : 'zaemAnervi3ZsbFAezQXcErd-EY7ygWQfrWmExrpeeBwHjcKk-GkPaFwK4CmZhaPhPgQcoQWin'}, withCredentials : true}).then(loginus => console.log('loginus', loginus));
	}

	componentWillUnmount() {
		this.contextSubscribtion.stop();
	}

	render() {
		return(
			<WebsiteContext.Provider value={this.state.context}>
				{/* <LoadingScreen/> */}
				{
					this.props.user ? 
					<Layout noFooter={true}>
						<Home/>
					</Layout> :
					<p>Page introuvable</p>
				}
			</WebsiteContext.Provider>
		)
	}

}

export default App;