// import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies} from '/static/tools/network.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import _ from 'lodash';
import Login from '/components/mains/Login/Login.js';
import Head from 'next/head';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		initData.page = 'login';
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		if (this.context.user) {
			window.location = '/home';
		}
		else {
			document.querySelector('body').scrollTo(0,0);
			// document.querySelector('.LoadingScreen').remove();
		}
	};

	render() {
		let context = Object.assign({},this.props);
		const getSubject = subject => context.lang.subjects.find(e => (e.value == subject));
		const getLevel = level => context.lang.levels.find(e => (e.value == level));
		context.getSubject = getSubject;
		context.getLevel = getLevel;
		return(
			<WebsiteContext.Provider value={context}>
				<Head>
					<title>Connexion - Les Sherpas</title>
				</Head>
				{/* <LoadingScreen/> */}
				{
					<Layout noFooter={true}>
						<Login/>
					</Layout>
				}
			</WebsiteContext.Provider>
		)
	};
};
export default App;