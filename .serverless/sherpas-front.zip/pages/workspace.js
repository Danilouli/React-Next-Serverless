import Workspace from '/components/mains/Workspace/Workspace.js';
import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {api, getDataWithCookies, initWorkspaceSocket} from '/static/tools/network.js';
import _ from 'lodash';

class App extends React.Component  {

	constructor(props) {
		super(props);
		let socket = initWorkspaceSocket(props.room, props.auth);
		this.socket = socket;
		this.tokenTwilio = props.tokenTwilio;
		let contextVal = Object.assign({}, props);
		const getSubject = subject => contextVal.lang.subjects.find(e => (e.value == subject));
		const getLevel = level => contextVal.lang.levels.find(e => (e.value == level));
		contextVal.getSubject = getSubject;
		contextVal.getLevel = getLevel;
		contextVal.setVals = (valueObject = {'to.set' : 'something'}) => {
			let contextVal = this.state.contextVal;
			for (let k of Object.keys(valueObject)) {
				_.set(contextVal, k, valueObject[k]);
			}
			this.setState({contextVal});
		};
		contextVal.socket = this.socket;
		this.state = {contextVal};
	}

	static async getInitialProps(ctx) {
		const room = _.get(ctx, 'req.params.room') || _.get(ctx, 'query.room') || _.get(ctx, 'query.workspace');
		let initData = await getDataWithCookies(ctx);
		const tokenTwilio = await api.post('tck_workspaces/generate_twilio_token', {workspaceId : room, auth : initData.auth})
		initData.room = room;
		initData.tokenTwilio = tokenTwilio;
		initData.page = 'workspace';
		return initData;
	}

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		document.querySelector('body').scrollTo(0,0);
		document.querySelector('.LoadingScreen').remove();
	}

	render() {
		let ctx = this.state.contextVal;
		return(
			<WebsiteContext.Provider value={ctx}>
				<style>{`
					body { 
						overflow-y: hidden;
					}
    			`}</style>
				<div>
					<LoadingScreen/>
					<Workspace socket={this.socket}/>
				</div>
			</WebsiteContext.Provider>
		)
	}

}

export default App
