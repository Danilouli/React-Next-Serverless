import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import HowItWorks from '/components/mains/HowItWorks/HowItWorks.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies} from '/static/tools/network.js';
import Head from 'next/head';
import {IN_PROD} from '/static/tools/network.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		initData.page = 'how_it_works';
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		if (this.props.user)
			window.location = '/home';
		else {
			document.querySelector('body').scrollTo(0,0);
			let qs = document.querySelector('.LoadingScreen');
			if (qs)
				qs.setAttribute('hidden', true);	
		}
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<Layout>
					<Head>
						{IN_PROD && <meta name="robots" content="index, follow"/>}
						<title>Comment marchent les cours particuliers en ligne ? - Les Sherpas</title>
						<meta name="description" content="Trouvez un professeur puis programmez un RDV pédagogique de 20min. Progressez ensuite à votre rythme en prenant cours où vous voulez, quand vous voulez !"/>
					</Head>
					<LoadingScreen/>
					<HowItWorks/>
				</Layout>
			</WebsiteContext.Provider>
		)
	};
};
export default App;
