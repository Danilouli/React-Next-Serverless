import '/static/stylesheets/index.scss';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import Layout from '/components/layouts/Layout/Layout.js';
import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import BecomeTeacher from '/components/mains/BecomeTeacher/BecomeTeacher.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies, api, getParam} from '/static/tools/network.js';
import _ from 'lodash';
import Head from 'next/head';
import {IN_PROD} from '/static/tools/network.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		const {levels, subjects} = initData.lang;
		let param1 = getParam(ctx, 'param1');
		let param2 = getParam(ctx, 'param2');
		let contentUrl = 'www.les-sherpas.co/donner-cours-particuliers';
		if (!!param1)
			contentUrl += `/${param1}`;
		if (!!param2)
			contentUrl += `/${param2}`;
		let contentsArr = await api.post('lang/get_docs_by_query', {collection : 'contents', query : {url : contentUrl}}).catch(e=>[]);
		let contents = {};
		for (let c of contentsArr)
			contents[c.keyId] = c;
		let canonical = _.get(contents, 'canonical_url_export.metadata.canonicalUrl');
		if (!!canonical && canonical.trim() != '')
			initData.canonicalUrl = canonical;
		Object.assign(initData, {param1, param2, contents});
		initData.page = 'become_teacher';
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		if (this.props.user)
			window.location = '/home';
		else {
			document.querySelector('body').scrollTo(0,0);
			let qs = document.querySelector('.LoadingScreen');
			if (qs)
				qs.setAttribute('hidden', true);	
		}
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<LoadingScreen/>
				<Layout>
					<Head>
						{IN_PROD && <meta name="robots" content="index, follow"/>}
						{this.props.canonicalUrl &&  <link rel="canonical" href={this.props.canonicalUrl}/>}
						<title>Donner cours particuliers - Trouver des élèves - Les Sherpas</title>
						<meta name="description" content="▷ La plus grande communauté de profs particuliers en ligne ✓ Cours individuels ✓ Tous niveaux ✓ Job gratifiant et flexible ✓ Gagne jusqu’à 60€/h"/>
					</Head>
					<BecomeTeacher/>
				</Layout>
			</WebsiteContext.Provider>
		)
	};
};
export default App;