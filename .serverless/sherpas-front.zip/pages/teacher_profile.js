import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import TeacherProfile from '/components/mains/TeacherProfile/TeacherProfile.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {setLoginCookies, buildTeacherTitleAndDescription} from '/static/tools/tools.js';
import {getDataWithCookies, api} from '/static/tools/network.js';
import _ from 'lodash';
import Head from 'next/head';
import {IN_PROD} from '/static/tools/network.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		const seoId = _.get(ctx, 'req.params.seoId') || _.get(ctx, 'query.seoId');
		let initData = await getDataWithCookies(ctx);
		let teacher = await api.get(`public/teacher/${seoId}`);
		initData.teacher = teacher;
		let metaDesc = buildTeacherTitleAndDescription(teacher);
		initData.metaDesc = metaDesc;
		initData.page = 'teacher_profile';
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		document.querySelector('body').scrollTo(0,0);
		let qs = document.querySelector('.LoadingScreen');
		if (qs)
			qs.setAttribute('hidden', true);	
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<Layout>
					<Head>
						{IN_PROD && <meta name="robots" content="index, follow"/>}
						<title>{_.get(this, 'props.metaDesc.title')}</title>
						<meta name="description" content={_.get(this, 'props.metaDesc.description')}/>
					</Head>
					<LoadingScreen/>
					<TeacherProfile/>
				</Layout>
			</WebsiteContext.Provider>
		)
	};
}
export default App;