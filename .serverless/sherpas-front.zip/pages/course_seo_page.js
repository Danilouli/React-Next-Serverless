import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import _ from 'lodash';
import CourseSEOPage from '/components/mains/CourseSEOPage/CourseSEOPage.js';
import {setLoginCookies, shuffleArray} from '/static/tools/tools.js';
import {getDataWithCookies, api, getParam} from '/static/tools/network.js';
import Head from 'next/head';

class App extends React.Component  {

	constructor(props) {
		super(props);
	}

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		const {levels, subjects} = initData.lang;
		let param1 = getParam(ctx, 'param1');
		let param2 = getParam(ctx, 'param2');
		console.log('param1', param1);
		let subject, level;
		if (levels.find(l => l.value == param1))
			level = param1;
		else if (levels.find(l => l.value == param2))
			level = param2;
		if (subjects.find(s => s.value == param1))
			subject = param1;
		else if (subjects.find(s => s.value == param2))
			subject = param2;
		if (!subject)
			subject = 'maths';
		if (!level)
			level = 'lycee';
		console.log('subject', subject);
		console.log('level', level);
		let teachQuery = {subjects : [subject], level};
		console.log('teachQuery', teachQuery);
		let teachers = await api.post('public/teachers/search', teachQuery).catch(e => {
			console.error('Error to get teachers', e);
			return [];
		});
		teachers = shuffleArray(teachers).slice(0,20);
		let contentUrl = 'www.les-sherpas.co/cours';
		if (!!param1)
			contentUrl += `/${param1}`;
		if (!!param2)
			contentUrl += `/${param2}`;
		console.log('contents url', contentUrl);
		let contentsArr = await api.post('lang/get_docs_by_query', {collection : 'contents', query : {url : contentUrl}}).catch(e => {
			console.error("Error to get contents", e);
			return [];
		});
		let contents = {};
		for (let c of contentsArr) {
			contents[c.keyId] = c;
		}
		let canonical = _.get(contents, 'canonical_url_export');
		Object.assign(initData, {subject, level, teachers, contents});
		initData.page = 'course_seo_id';
		return initData;
	}

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		if (this.props.user)
			window.location = '/home';
		else {
			document.querySelector('body').scrollTo(0,0);
			let qs = document.querySelector('.LoadingScreen');
			if (qs)
				qs.setAttribute('hidden', true);	
		}
	}

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<Head>
					<meta name="robots" content="index, follow"/>
					<title>{this.props.contents.meta_title.HTMLContent}</title>
					<meta name="description" content={this.props.contents.meta_description.HTMLContent} />
				</Head>
				<LoadingScreen/>
				<Layout>
					<CourseSEOPage/>
				</Layout>
			</WebsiteContext.Provider>
		)
	}

}

export default App;