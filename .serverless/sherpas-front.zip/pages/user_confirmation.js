// import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import UserConfirmation from '/components/mains/UserConfirmation/UserConfirmation.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {api, getParam} from '/static/tools/network.js';
import _ from 'lodash';
import Head from 'next/head';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = {};
		const slug = getParam(ctx, 'slug');
		const userId = getParam(ctx, 'userId');
		let user = await api.post('tck_users/find_user_to_confirm', {_id : userId, slug}).catch(e=>console.error('Error to get the user', e));
		initData.user = user;
		initData.slug = slug;
		initData.page = 'user_confirmation';
		return initData;
	};

	async componentDidMount() {
		// setLoginCookies(this.props.auth);
		document.querySelector('body').scrollTo(0,0);
		if (!_.get(this, 'props.user._id'))
			window.location = '/';
		// document.querySelector('.LoadingScreen').remove();
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<Layout>
					<Head>
						<title>Confirmation de compte - Les Sherpas</title>
					</Head>
					{/* <LoadingScreen/> */}
					{
						(!!_.get(this, 'props.user._id')) ?
						<UserConfirmation/> : <span>Page introuvable</span>
					}
				</Layout>
			</WebsiteContext.Provider>
		)
	};
}
export default App;