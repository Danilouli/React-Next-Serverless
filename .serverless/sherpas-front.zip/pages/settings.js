// import ReactDom from 'react-dom';
// import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import _ from 'lodash';
import Settings from '/components/mains/Settings/Settings.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies, api} from '/static/tools/network.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		let {user} = initData;
		if (user.type == 'teacher') {
			let teacherGrade = (await api.post(
				`lang/get_docs_by_query`,
				{collection : 'teacher_grades', query : {level : _.get(user, 'teacherInfos.teacherGrade', 0)}}
			))[0];
			initData.teacherGrade = teacherGrade;
		}
		initData.page = 'settings';
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		if (!this.props.user)
			window.location = '/landing';
		// else {
		// 	document.querySelector('body').scrollTo(0,0);
		// 	const loadingScreen = document.querySelector('.LoadingScreen');
		// 	if (loadingScreen) {
		// 		ReactDom.unmountComponentAtNode(loadingScreen);
		// 		loadingScreen.remove();
		// 	}
		// }
	};

	render() {
		let context = Object.assign({},this.props);
		const getSubject = subject => context.lang.subjects.find(e => (e.value == subject));
		const getLevel = level => context.lang.levels.find(e => (e.value == level));
		context.getSubject = getSubject;
		context.getLevel = getLevel;
		return(
			<WebsiteContext.Provider value={context}>
				{/* <LoadingScreen/> */}
				{
					this.props.user ? 
					<Layout noFooter={true}>
						<Settings/>
					</Layout> :
					<p>Page introuvable</p>
				}
			</WebsiteContext.Provider>
		)
	};
}

export default App;