import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import GreenButton from '/components/misc/GreenButton/GreenButton.js';
import WhiteButton from '/components/misc/WhiteButton/WhiteButton.js';
import ClassicModal from '/components/misc/ClassicModal/ClassicModal.js';
import SmallCard from '/components/misc/SmallCard/SmallCard.js';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faArrowRight} from '@fortawesome/free-solid-svg-icons';
import MaterialSelect from '/components/misc/MaterialSelect/MaterialSelect.js';
import MaterialSlider from '/components/misc/MaterialSlider/MaterialSlider.js';
import TagInput from '/components/misc/TagInput/TagInput.js';
import CardModal from "/components/misc/CardModal/CardModal.js"

class App extends React.Component  {

	constructor(props) {
		super(props);
		this.state = {
			selectValue : 2
		};
	}

	static async getInitialProps(ctx) {
		return {};
	}

	updateSelect(event) {
		this.setState({selectValue : event.target.value});
	}

	render() {
		return(
			<div style={{
				position: 'relative',
				width : '100vw',
				height : '100vh',
				overflow : 'scroll'
			}}>
				{/* <LoadingScreen/> */}
				<div className='componentContainer relw25'>
					<CardModal/>
				</div>
				{/* <div className='componentContainer'>
					<GreenButton>
						<span>Trouver un Sherpa &nbsp;</span><FontAwesomeIcon icon={faArrowRight}/>
					</GreenButton>
				</div>
				<div className='componentContainer'>
					<WhiteButton>
						<span>Trouver un Sherpa &nbsp;</span><FontAwesomeIcon icon={faArrowRight}/>
					</WhiteButton>
				</div>
				<div className='componentContainer'>
					<SmallCard 
						title='20 min gratuites pour commencer'
						text='90% de nos utilisateurs commencent par un RDV pédagogique gratuit'
						buttonContent='Prendre un RDV Pédagogique'
					/>
				</div>
				<div className='componentContainer'>
					<SmallCard 
						title='16 - 50€/h de cours'
						text='En fonction du niveau
						et du professeur choisi'
						withoutBar={true}
					/>
				</div>
				<div className='componentContainer'>
					<ClassicModal
						close={true}
						title='Inscrivez-vous pour contacter Machin Truc'
						content={
							<div style={{
								display : 'flex',
								flexDirection : 'column',
								justifyContent : 'center',
								alignItems : 'center'
							}}>
								<div>Bonjour</div>
								<GreenButton>
									<span>Trouver un Sherpa &nbsp;</span><FontAwesomeIcon icon={faArrowRight}/>
								</GreenButton>
							</div>
						}
					/>
				</div>
				<div className='componentContainer'>
					<MaterialSelect
						selectedValue={this.state.selectValue}
						onChange={this.updateSelect.bind(this)}
						items={[
							{value : 1, name : 'One'},
							{value : 2, name : 'Two'},
							{value : 3, name : 'Three'}
						]}
					/>
				</div>
				<div className='componentContainer'>
					<TagInput/>
				</div>
				<div className='componentContainer'>
					<MaterialSlider/>
				</div> */}
			</div>
		)
	}

}

export default App