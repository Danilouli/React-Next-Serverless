import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import LandingLayout from '/components/layouts/LandingLayout/LandingLayout.js';
import Prices from '/components/mains/Prices/Prices.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies} from '/static/tools/network.js';
import Head from 'next/head';
import {IN_PROD} from '/static/tools/network.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		initData.page = 'prices';
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		if (this.props.user)
			window.location = '/home';
		else {
			document.querySelector('body').scrollTo(0,0);
			let qs = document.querySelector('.LoadingScreen');
			if (qs)
				qs.setAttribute('hidden', true);	
		}
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<LandingLayout>
					<Head>
						{IN_PROD && <meta name="robots" content="index, follow"/>}
						<title>Les Sherpas : Tarifs Cours Particuliers - Abordables et de Qualité</title>
						<meta name="description" content="Les tarifs de nos professeurs varient en fonction de leur expertise. Leurs cours sont à partir de 12€/h, et 80% de nos Sherpas sont dans la fourchette 12-25€/h."/>
					</Head>
					<LoadingScreen/>
					<Prices/>
				</LandingLayout>
			</WebsiteContext.Provider>
		)
	};
}
export default App;