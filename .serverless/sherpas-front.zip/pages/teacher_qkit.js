import LoadingScreen from '/components/misc/LoadingScreen/LoadingScreen.js';
import '/static/stylesheets/index.scss';
import Layout from '/components/layouts/Layout/Layout.js';
import WebsiteContext from '/components/contexts/WebsiteContext.js';
import {setLoginCookies} from '/static/tools/tools.js';
import {getDataWithCookies, api} from '/static/tools/network.js';
import _ from 'lodash';
import Flow from '/static/tools/qkit.js';

class App extends React.Component  {
	constructor(props) {
		super(props);
	};

	static async getInitialProps(ctx) {
		let initData = await getDataWithCookies(ctx);
		return initData;
	};

	async componentDidMount() {
		setLoginCookies(this.props.auth);
		document.querySelector('body').scrollTo(0,0);
		document.querySelector('.LoadingScreen').remove();
		new Flow({
			"id": "5c2ce049d2b34d5ddd01ac46",
			"selector": "#flowPreviewContainer",
			"userId" : "5d4d64fdf62934e24cb04243",
			"options" : {
				"fname" : "Danielix",
				"lname" : "Saadioulix"
			}
		});
	};

	render() {
		return(
			<WebsiteContext.Provider value={this.props}>
				<LoadingScreen/>
				<div className='relw100vw relh100vh' id='flowPreviewContainer'></div>
			</WebsiteContext.Provider>
		)
	};
}
export default App;