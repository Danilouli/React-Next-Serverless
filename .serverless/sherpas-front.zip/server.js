"use strict";

// require('dotenv').config();
// const Express = require('express');
// const Next = require('next');
// const Cookies	= require('cookie-parser');
// const ExpressIp = require('express-ip');

console.log('ABRUTI !');
// let stage = 'dev';
// let stageInd = process.argv.indexOf('--stage');
// if (stageInd >= 0) {
// 	if (process.argv[stageInd + 1])
// 		stage = process.argv[stageInd + 1];
// }
// const prod = (process.env.DEV_ENV === 'production' || stage == 'production');
// if (prod)
// 	stage = 'production';
// const dev = (stage == 'dev');
// const App = Next({ dev });
// const Handle = App.getRequestHandler();
// const Server = Express();
// const Sls = require('serverless-http');

// let pageNames = ['','landing','login','index'];

// const getPage = page => require(`./.next/serverless/pages/${page}.js`);

// let setServer = function(server) {
// 	server.use(Cookies(process.env.COOKIE_SIGNER));
// 	server.use(ExpressIp().getIpInfoMiddleware);
// 	server.use('/static', Express.static(__dirname + '/static'));
// 	server.get('/gallery', (req, res) => getPage('gallery').render(req, res));
// 	server.get('/teacher_profile', getPage('teacher_profile').render);
// 	server.get('/workspace', getPage('workspace').render);
// 	server.get('/cours/:subject/:city', (req,res) => {
// 		const queryParams = req.params;
// 		getPage('course_seo_page').render(req,res, queryParams);
// 	});
// 	server.get('*', (req, res) => {
// 		return Handle(req, res);
// 	});
// }

// if (stage == 'dev') {
// 	console.log('in dev');
// 	App.prepare().then(() => {
// 		console.log('app prepared');
// 		setServer(Server);
// 		Server.listen(3001, err => {
// 			if (err) throw err;
// 			console.log('> Ready on http://localhost:3001');
// 		})
// 	})
// 	.catch(ex => {
// 		console.error('Exception', ex.stack);
// 		process.exit(1);
// 	});
// }
// else {
// 	console.log('not dev');
// 	setServer(Server);
// 	module.exports.handler = Sls(Server);
// }